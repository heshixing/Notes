## 事先准备

> SQL语句

```sql
create DATABASE ssm_db
use ssm_db;
/*
 Navicat MySQL Data Transfer

 Source Server         : localhost
 Source Server Type    : MySQL
 Source Server Version : 80023
 Source Host           : localhost:3306
 Source Schema         : springboot_db

 Target Server Type    : MySQL
 Target Server Version : 80023
 File Encoding         : 65001

 Date: 20/01/2022 11:50:34
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for tbl_book
-- ----------------------------
DROP TABLE IF EXISTS `tbl_book`;
CREATE TABLE `tbl_book`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `description` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of tbl_book
-- ----------------------------
INSERT INTO `tbl_book` VALUES (1, '三体', '科幻', '大刘的巅峰之作，将中国科幻推向世界舞台。总共分为三部曲：《地球往事》、《黑暗森林》、《死神永生》。');
INSERT INTO `tbl_book` VALUES (2, '格林童话', '童话', '睡前故事。');
INSERT INTO `tbl_book` VALUES (3, 'Spring 5设计模式', '计算机理论', '深入Spring源码剖析Spring源码中蕴含的10大设计模式');
INSERT INTO `tbl_book` VALUES (4, 'Spring MVC+ MyBatis开发从入门到项目实战', '计算机理论', '全方位解析面向Web应用的轻量级框架,带你成为Spring MVC开发高手');
INSERT INTO `tbl_book` VALUES (5, '轻量级Java Web企业应用实战', '计算机理论', '源码级剖析Spring框架,适合已掌握Java基础的读者');
INSERT INTO `tbl_book` VALUES (6, 'Java核心技术卷|基础知识(原书第11版)', '计算机理论', 'Core Java第11版，Jolt大奖获奖作品，针对Java SE9、10、 11全面更新');
INSERT INTO `tbl_book` VALUES (7, '深入理解Java虚拟机', '计算机理论', '5个维度全面剖析JVM,面试知识点全覆盖');
INSERT INTO `tbl_book` VALUES (8, 'Java编程思想(第4版)', '计算机理论', 'Java学习必读经典殿堂级著作!赢得了全球程序员的广泛赞誉');
INSERT INTO `tbl_book` VALUES (9, '零基础学Java (全彩版)', '计算机理论', '零基础自学编程的入门]图书，由浅入深，详解Java语言的编程思想和核心技术');
INSERT INTO `tbl_book` VALUES (10, '直播就该这么做:主播高效沟通实战指南', '市场营销', '李子柒、李佳琦、薇娅成长为网红的秘密都在书中');
INSERT INTO `tbl_book` VALUES (11, '直播销讲实战一本通', '市场营销', '和秋叶一起学系列网络营销书籍');
INSERT INTO `tbl_book` VALUES (12, '直播带货:淘宝、天猫直播从新手到高手', '市场营销', '一本教你如何玩转直播的书， 10堂课轻松实现带货月入3W+');
INSERT INTO `tbl_book` VALUES (13, 'Spring实战第5版', '计算机理论', 'Spring入门经典教程,深入理解Spring原理技术内幕');
INSERT INTO `tbl_book` VALUES (14, 'Spring 5核心原理与30个类手写实战', '计算机理论', '十年沉淀之作，写Spring精华思想');

SET FOREIGN_KEY_CHECKS = 1;
```

## 工程打包与运行

### 打包

打开"D:\IDEACode\HM\springboot\two\springboot_08_ssmp"项目，先看右边有没有target文件，有的话先clean再package，没有的话直接package。

![截图](b3c8b49721b16878289c0dde925d392e.png)

右键target下的jar文件在资源管理器中打开，打开终端，输入 java -jar .....jar，回车

![截图](092e314e3e2c402857596af9bcf63a52.png)

访问`http://localhost/pages/books.html`

查看终端

![截图](643eaf4719d16b24ab6d82024ce0dbec.png)

> ctrl+c关闭

## 打包插件

```sh
#查询端口
netstat -ano
#查询指定端口
netstat -ano | findstr "端口号"
#根据进程PID查询进程名称
tasklist | findstr "进程PID号"
#根据PID杀死任务
taskkill /F /PID "进程PID号"
#根据进程名称杀死任务
taskkill -f -t -im "进程名称"
```

![截图](60605491ad9d199171ec900f67bd48fe.png)

### Boot工程快速启动

使用FinalShell连接虚拟机(名称为springboot)，连接好输入指令

```sh
cd /
ll
cd usr
cd local
mkdir app
cd app
```

使用菜单方式上传到app文件夹下

![截图](5677336823cbe5992c3c18ee60deb8a4.png)

使用Navicat连接虚拟机，导入下面的SQL文件

```sql
create DATABASE ssm_db;
use ssm_db;
DROP TABLE IF EXISTS `tbl_book`;
CREATE TABLE `tbl_book`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `description` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

INSERT INTO `tbl_book` VALUES (1, '三体', '科幻', '大刘的巅峰之作，将中国科幻推向世界舞台。总共分为三部曲：《地球往事》、《黑暗森林》、《死神永生》。');
INSERT INTO `tbl_book` VALUES (2, '格林童话', '童话', '睡前故事。');
INSERT INTO `tbl_book` VALUES (3, 'Spring 5设计模式', '计算机理论', '深入Spring源码剖析Spring源码中蕴含的10大设计模式');
INSERT INTO `tbl_book` VALUES (4, 'Spring MVC+ MyBatis开发从入门到项目实战', '计算机理论', '全方位解析面向Web应用的轻量级框架,带你成为Spring MVC开发高手');
INSERT INTO `tbl_book` VALUES (5, '轻量级Java Web企业应用实战', '计算机理论', '源码级剖析Spring框架,适合已掌握Java基础的读者');
INSERT INTO `tbl_book` VALUES (6, 'Java核心技术卷|基础知识(原书第11版)', '计算机理论', 'Core Java第11版，Jolt大奖获奖作品，针对Java SE9、10、 11全面更新');
INSERT INTO `tbl_book` VALUES (7, '深入理解Java虚拟机', '计算机理论', '5个维度全面剖析JVM,面试知识点全覆盖');
INSERT INTO `tbl_book` VALUES (8, 'Java编程思想(第4版)', '计算机理论', 'Java学习必读经典殿堂级著作!赢得了全球程序员的广泛赞誉');
INSERT INTO `tbl_book` VALUES (9, '零基础学Java (全彩版)', '计算机理论', '零基础自学编程的入门]图书，由浅入深，详解Java语言的编程思想和核心技术');
INSERT INTO `tbl_book` VALUES (10, '直播就该这么做:主播高效沟通实战指南', '市场营销', '李子柒、李佳琦、薇娅成长为网红的秘密都在书中');
INSERT INTO `tbl_book` VALUES (11, '直播销讲实战一本通', '市场营销', '和秋叶一起学系列网络营销书籍');
INSERT INTO `tbl_book` VALUES (12, '直播带货:淘宝、天猫直播从新手到高手', '市场营销', '一本教你如何玩转直播的书， 10堂课轻松实现带货月入3W+');
INSERT INTO `tbl_book` VALUES (13, 'Spring实战第5版', '计算机理论', 'Spring入门经典教程,深入理解Spring原理技术内幕');
INSERT INTO `tbl_book` VALUES (14, 'Spring 5核心原理与30个类手写实战', '计算机理论', '十年沉淀之作，写Spring精华思想');

SET FOREIGN_KEY_CHECKS = 1;
```

先关闭防火墙

```sh
systemctl stop firewalld
```

运行jar包

```sh
 java -jar springboot_08_ssmp-0.0.1-SNAPSHOT.jar 
```

![截图](3c96d484ebefd949bb61fa339b63799d.png)

访问`192.168.220.133/pages/books.html`

![截图](6da024a51310c5394e9e7355cf31a459.png)

这种方式Linux控制台都是日志，下面是后台运行

```sh
nohup java -jar springboot_08_ssmp-0.0.1-SNAPSHOT.jar > server.log 2>&1 &
```

![截图](ca6959f60816229a88e02718ad922351.png)

刷新浏览器，能查询到数据，就是运行成功了

停止运行

```sh
ps -ef | grep "java -jar"
kill 端口号
```

![截图](1193aa63eeb988403cd54affb209aadc.png)

刷新浏览器，显示连接失败

查看日志

```sh
cat server.log
```

![截图](0ea2f5d65bc760302a721bce2fb2f85f.png)

## 环境配置

### 临时属性

输入指令，临时修改端口号（application.yml里面是80）

```
java -jar .\springboot_08_ssmp-0.0.1-SNAPSHOT.jar --server.port=8080
```

访问`http://localhost:8080/pages/books.html`

![截图](716f7dccce4835789097576170f2e3ff.png)

修改多个临时属性

```sh
 java -jar .\springboot_08_ssmp-0.0.1-SNAPSHOT.jar --server.port=8080 --spring.dabasource.druid.password=123
```

查看浏览器

按理说运行不报错，但是浏览器查询不出来数据，但是我的可以查询

<br/>

临时配置优先级

```java
https://docs.spring.io/spring-boot/docs/current/reference/html/features.html#features.external-config
```

### 外部化配置

```textile
Spring 引导允许您外部化配置，以便您可以在不同的环境中使用相同的应用程序代码。 您可以使用各种外部配置源，包括 Java 属性文件、YAML 文件、环境变量和命令行参数。

属性值可以使用注释直接注入到您的 bean 中，通过 Spring 的抽象访问，或者通过 .@ValueEnvironment@ConfigurationProperties

```

>  Spring Boot 使用非常特殊的顺序，旨在允许合理地覆盖值。 后面的属性源可以覆盖前面的属性源中定义的值。 按以下顺序考虑来源：PropertySource

1. 默认属性（由设置 指定）。SpringApplication.setDefaultProperties
2. **@PropertySource**类的注释。 请注意，在刷新应用程序上下文之前，不会将此类属性源添加到 中。 配置某些属性（如 和 在刷新开始之前读取的属性）为时已晚。@ConfigurationEnvironmentlogging.*spring.main.*
3. 配置数据（如文件）。application.properties
4. 仅在 中具有属性的 。RandomValuePropertySourcerandom.*
5. 操作系统环境变量。
6. Java 系统属性 （）。System.getProperties()
7. 来自 的 JNDI 属性。java:comp/env
8. ServletContext初始化参数。
9. ServletConfig初始化参数。
10. 属性来自（嵌入在环境变量或系统属性中的内联 JSON）。SPRING_APPLICATION_JSON
11. 命令行参数。
12. properties测试的属性。 在@SpringBootTest和测试注释中可用，用于测试应用程序的特定切片。
13. 在测试中@DynamicPropertySource注释。
14. **@TestPropertySource**测试上的注释。
15. 当 devtools 处于活动状态时，目录中的 Devtools 全局设置属性。$HOME/.config/spring-boot

> 配置数据文件按以下顺序考虑：

1. 打包在 jar 中的应用程序属性（ 和 YAML 变体）。`application.properties`
2. 打包在 jar 中的特定于配置文件的应用程序属性（ 和 YAML 变体）。`application-{profile}.properties`
3. 打包的 jar（ 和 YAML 变体）之外的应用程序属性。`application.properties`
4. 打包的 jar（ 和 YAML 变体）之外的特定于配置文件的应用程序属性。`application-{profile}.properties`

### 临时属性（开发环境）

![截图](028cfb22d0e3f95be670776118f3fa6d.png)

运行程序：

![截图](4d9dedc58b52c720cde1d1e32094a547.png)

查看浏览器

![截图](e8448604758693b0383b030634d13329.png)

- 通过编程形式带参数启动SpringBoot程序，为程序添加运行参数
  ```java
  public static void main(String[] args){
    String[] arg = new String[1];
    arg[0] = "--server.port=8080";
    SpringApplication.run(SSMPApplication.class,arg);
  }
  ```

- 不携带参数启动SpringBoot程序

```java
public static void main(String[]args){
  SpringApplication.run(SSMPApplication.class);
}
```

以后就可以测试参数了

### 配置文件4级分类

SpringBoot中4级配置文件

```textile
1级：file:config/application.yml    【最高】
2级：file:application.yml
3级：classpath:config/application.yml
4级：classpath:application.yml      【最低】
```

![截图](4380dbef156069bc2217517b26e27f49.png)

作用

```textile
1级与2级留做系统打包后设置通用属性，1级常用于运维经理进行线上整体项目部署方案调控
3级与4级用于系统开发阶段设置通用属性，3级常用于项目经理进行整体项目属性调控
```

### 自定义配置文件

创建model名称为springnoot_09_config（选spring web）

> 方法1：设置程序参数，指定文件名（不包含后缀），如：--spring.config.name=ebank

![截图](685cf3a2c120242a9fc128dfe83d6157.png)

> 方法2：指定配置文件的路径，如：--spring.config.location=classpath:/ebank.yml

![截图](26e846a9f178dc4ed53ac31c75da9e0a.png)

> 方法3：还可以指定多个配置文件，如：--spring.config.location=classpath:/ebank.yml,classpath:/ebank-server.yml

![截图](cbd291213a6b5e181cef93c030ec5291.png)

**ebank.yml和ebank-server.yml文件就配置两个不同的端口号即可测试。**

###  多环境配置

复制09项目，修改名称为springboot_10_profiles

编写配置文件`application.yml`

```yaml
# 应用环境
# 公共配置
spring:
  profiles:
    active: dev  #决定调用哪一个环境名
---
# 生产环境
spring:
  config:
    activate:
      on-profile: pro
server:
  port: 80
---
spring:
  config:
    activate:
      on-profile: dev  #调用这一个
server:
  port: 8080
---
# 测试环境
spring:
  config:
    activate:
      on-profile: test
server:
  port: 8888
```

运行程序发现使用的是dev的8080端口。

**优化：**

把application.yml放入redources下的simple文件夹下

`application.yml`

```yaml
# 应用环境
# 公共配置
spring:
  profiles:
    active: dev
```

`application-pro.yml`

```yaml
server:
  port: 80
```

`application-dev.yml`

```yaml
server:
  port: 8080
```

`application-test.yml`

```yaml
server:
  port: 8888
```

- 主配置文件中设置公共配置（全局）
- 环境分类配置文件中常用于设置冲突属性（局部)

**yml和properties相同，但是properties没有整体版的，只有多个文件的**

### 多环境分组管理

把上面的配置放入resources下的mul文件夹下

编写application.yml

```yaml
spring:
  profiles:
    active: dev
    include: devDB, devMVC
```

application-dev.yml

```yaml
server:
  port: 80
```

application-devDB.yml

```
server:
  port: 81
```

application-devMVC.yml

```yaml
server:
  servlet:
    context-path: /ebank
  port: 82
```

![截图](e48fb2b09000b35572cb44904758c8eb.png)

**当主环境dev与其他环境有相同属性时，主环境属性生效；其他环境中有相同属性时，最后加载的环境属性生效**

使用group属性定义多种主环境与子环境的包含关系

```yaml
#spring:
#  profiles:
#    active: dev
#    include: devDB, devMVC

spring:
  profiles:
    active: dev
    group:
      "dev": devDB, devMVC
      "pro": proDB, proMVC
      "test": testDB, TestMVC
```

观察启动日志，配置文件加载的顺序为 : The following profiles are active: dev,devDB,devMVC

**当主环境dev与其他环境有相同属性时，主环境属性生效；其他环境中有相同属性时，最先加载的环境属性生效**

**多环境开发使用group.属性设置配置文件分组，便于线上维护管理**

### 多环境开发控制

配置pom.xml文件

```xml
<!--设置多环境-->
    <profiles>
        <profile>
            <id>env_dev</id>
            <properties>
                <profile.active>dev</profile.active>
            </properties>
            <activation>
                <activeByDefault>true</activeByDefault>
            </activation>
        </profile>
        <profile>
            <id>env_pro</id>
            <properties>
                <profile.active>pro</profile.active>
            </properties>

        </profile>
        <profile>
            <id>env_test</id>
            <properties>
                <profile.active>test</profile.active>
            </properties>
            <activation>
                <activeByDefault>true</activeByDefault>
            </activation>
        </profile>
    </profiles>
```

修改`application.yml`文件

```yaml
spring:
  profiles:
    active: @profile.active@
    group:
      "dev": devDB, devMVC
      "pro": proDB, proMVC
```

打包，在资源管理器打开target文件

![截图](2af05aa36d28d46bbd2b42535d602e56.png)

![截图](2a8816273156e1310fe9829c222a7d8a.png)

1. 当Maven与SpringBoot同时对多环境进行控制时，以Mavn为主，
SpringBoot使用@..@占位符读取Maven.对应的配置属性值
2. 基于SpringBoot读取Maven配置属性的前提下，如果在Idea下测试
工程时pom.xml每次更新需要手动compile方可生效

## 日志操作

### 日志基础操作

日志的级别

- TRACE：运行堆栈信息，使用率低
- D5BUG：程序员调试代码使用
- INFO：记录运维过程数据
- WARN：记录运维过程报警数据
- ERROR：记录错误堆栈信息
- FATAL：灾难信息，合并计入ERROR

使用

![截图](fed3f7604e35033baef79c6a97d31751.png)

设置日志输出级别

默认是info级别的，在application.yml文件中添加配置`debug=true`，重新运行

![截图](140989450fd3bccc6bd8863b87a648f5.png)

修改`application.yml`文件的配置

```yaml
# debug: true
logging:
  level:
    root: error
    # 设置某个包的日志级别
    com.itheima.controller: debug
```

**root表示根节点，即整体应用日志级别，只展示error级别之上的日志，但是包下的设置有优先级更高**

修改`application.yml`文件的配置

```yaml
logging:
  # 设置分组
  group:
    ebank: com.itheima.controller,com.itheima.service,com.itheima.dao
    iservice: com.alibaba
  level:
    root: info
    # 设置分组，对某个组设置日志级别
    ebank: warn
```

**设置日志组，控制指定包对应的日志输出级别，也可以直接控制指定包对应的日志输出级别**

> 使用lombok提供的注解@Sf4j简化开发，减少日志对象的声明操作

![截图](dcf00bf921f61fc5296b7e0931c31296.png)

### 日志输出格式控制

![截图](f671bb39a1f133d22f76531d31bcd3d1.png)

设置日志输出格式

```yaml
logging:
  pattern:
    console:  "%d %5p - %m%n"
```

- %d：日期
- %p：日志级别  5p是因为格式对齐（warn、debug...）
- %m：消息
- %n：换行

```yaml
pattern:
  console:"%d %m %n"
```

![截图](ed81d4e8ae3832d4abf05b655b0714d4.png)

```yaml
pattern:
  console:"%d %c1r(%5p) --- [%t] %n"
```

![截图](03165053575e60b3ed44179f94226931.png)

```yaml
pattern:
  console:"%d %c1r(%5p) --- [%16t] %n"
```

![截图](04fd1fde469bc483badc0db05141d940.png)

```yaml
pattern:
  console:"%d %c1r(%5p) --- [%16t] %c %n"
```

![截图](b9344a86ca98c655429ce983b93c3b8a.png)

```
pattern:
  console:"%d %c1r(%5p) --- [%16t] %40c %n"
```

![截图](acaf73ce5e196bae013dc9e66523b1b9.png)

这里是没对齐的，

```yaml
pattern:
  console:"%d %c1r(%5p) --- [%16t] %-40.40c %n"
```

![截图](8829e72662ade12b057e44d4a64c8aa1.png)

设置自定义颜色

```yaml
pattern:
  console: "%d %clr(%5p) --- [%16t] %clr(-40.40c){cyan} : %m %n"
```

![截图](ca6ba331ea533e0fd9219d178c951f9d.png)

### 设置日志文件

```yaml
  file:
    name: server.log
```

整体配置文件

```yaml
logging:
  # 设置分组
  group:
    ebank: com.itheima.controller,com.itheima.service,com.itheima.dao
    iservice: com.alibaba
  level:
    root: info
    # 设置分组，对某个组设置日志级别
    ebank: warn
  pattern:
    console: "%d %clr(%5p) --- [%16t] %clr(%-40.40c){cyan} : %m %n"

  file:
    name: server.log
```

![截图](f362234e2bfeb7dda24d5657fc3988be.png)

刷新浏览器，关闭程序，出现server.log文件

![截图](81653b5970053920652116f5a816c20f.png)

在资源管理器打开

![截图](ce00c451b48a1a218f10a25ca9b37365.png)

打开log文件，日志没有颜色

![截图](cf4873c9399b07d5ce9e2d852ff95796.png)

```yaml
logging:
  # 设置分组
  group:
    ebank: com.itheima.controller,com.itheima.service,com.itheima.dao
    iservice: com.alibaba
  level:
    root: info
    # 设置分组，对某个组设置日志级别
    ebank: warn
  pattern:
    console: "%d %clr(%5p) --- [%16t] %clr(%-40.40c){cyan} : %m %n"

  file:
    name: server.log
  logback:
    rolling policy:
      max-file-size: 4KB
      file-name-pattern: server.%d{yyyy-mm--dd}.%i.log
```

刷新浏览器，关闭程序，打开管理器

![截图](e52efdc81913c9f8e0cd02d67c038444.png)

刷新的次数一多，就会生成新文件。

## 热部署

创建项目springboot_12_hot_deploy，和8相同，删除controller层的2和serviceImpl层的2。

### 手动热部署

添加配置

```xml
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-devtools</artifactId>
</dependency>
```

激活热部署Ctrl + F9

**热部署**

- 重启(Restart):自定义开发代码，包含类、页面、配置文件等，加载位置restart类加载器
- 重载（ReLoad):jar包，加载位置base类加载器

**热部署只有Restart没有reload功能**

### 自动热部署

![截图](1a5b4db44c9dc00c26439b23a8130cc3.png)

> Ctrl + Shitf _Alt + /

![截图](3669848e7a9cbed65a343004cbd20138.png)

如果没有按照下面的

![截图](36971d3e5ac89f9fd41d0d46f87d3f55.png)

### 热部署范围设置

在`application.yml`文件中添加配置

```yaml
spring:
# 设置不参与热部署的文件
  devtools:
    restart:
      exclude: static/**,public/**,config/application.yml
      #是否可用
      enabled: false
```

### 关闭热部署

```java
System.setProperty("spring.devtools.restart.enabled", "false");
```

![截图](642e9f04c0c6a33495ecd63c265969df.png)

![截图](a2fefc2fd5509c67bfd456f2bdc59bd1.png)

### yaml语法规则

![截图](9cf176edbab9ec197b4a00fbbf53886a.png)
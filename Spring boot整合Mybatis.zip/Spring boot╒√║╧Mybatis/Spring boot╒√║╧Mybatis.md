![screen-capture](a671f1517997d2372b8370cc71180a7c.png)

![screen-capture](53d712a4164299cf71c5dec51f436015.png)

自定义配置源![screen-capture](9fe69b2071b78cc9ab5918f242050a92.png)

生成配置信息

![screen-capture](a5bcd8983f39293ba2a20f0ed72a472d.png)

创建配置类，注入配置信息

![screen-capture](d6be4a582479640ea0a8e821b46ff913.png)

注解发开![screen-capture](988ebdd1abb731eb63af5ed5887ad45c.png)

动态sql,sql拼接,使用XML拼接

在resource文件夹下创建相应domain类的mappers文件夹,在下面创建mapper的XML文件。模板搜mybatisXML模板。![screen-capture](97ddbff0f176d16c34cbec7eedd90bee.png)

<br/>

首先,使用namespace属性指定mapper接口和XML文件的映射

![screen-capture](53047b10ec0086ff242c4d2fda769ef1.png)

然后编译增删改查与接口的方法名称对应。

![screen-capture](c185a18b3acf0a1ae82598bfbb3ba40b.png)

编译测试类测试方法,测试类上方要写@SpringBototTest,方法写@Test。

![screen-capture](850f66e429dda646f132e1cd5789ba87.png)

报错，因为前面XML文件配置的findArticleById返回值不是Article类型,所以要自定义一个返回值类型来接受。

自定义映射如下：

![screen-capture](907be5ca423e7b7b18ed98dd515ea58e.png)

创建好自定义规则,在XML中使用

![screen-capture](d290e11f5eecc2bccfc7a08bf148aba0.png)

最后,在配置文件配置mybatis的XML文件的位置,要不然spring容器找不到

![screen-capture](d610261b3c0047676f2aa224c2a78b86.png)

注意！倒数第三行的驼峰配置不适用于mapper的xml配置文件

![screen-capture](261583d24806f0054ab1056310b57860.png)

两种解决方案: 1在sqlMapConfig中加入这句话，

					  2在mapper的xml中写autoMapping=true 。

![screen-capture](a004139a60b24317e5b84304095ba6dd.png)

更新语句

![screen-capture](6062dcbe6e907a5b1798034e8fc9be48.png)

如果传入的content为空或者没传，这条语句都会报错,所以要使用动态sql语句，如下所示：注意 " , " 。 

![screen-capture](24da1cd7744cef74a8b5f24a3e6d260b.png)

插入评论信息

![screen-capture](2f5bebe9c5b05c8c203da830136b3b04.png)

<br/>

<br/>

总结：

![screen-capture](0412837b38f89a754b35e1fa8cfef0b1.png)

优化1：

正常情况每一个mapper都要加mapper注解，如下：

![screen-capture](4f2fb71ac36c96cc421abcecb2e5e03e.png)

可以都去掉，在主程序启动类加@mapperScan扫描mapper文件名

![screen-capture](44edda92bc19aea476debf92f2eda4a5.png)

此时,测试类自动装配mapper文件会报错,因为测试类是在源代码进行编译的,而主程序的mapper扫描是在运行时开始扫描的。选中syntax忽略语法检验,就不报错了。

![screen-capture](15b3adb4308bce6fe400b1bd6dbe8a2b.png)

<br/>

优化2：

result-type和parameter-type太复杂,可以简化配置文件的编写

![screen-capture](611d14a4ef24b2187ab76f7dc972c34b.png)

在核心配置文件编写配置语句,指定XML文件中的实体类路径名即前缀：

![screen-capture](24264ec758e820e91f2150454a010172.png)

<br/>

优化3:

驼峰映射

1.在核心配置文件中开启驼峰映射的规则,

![screen-capture](cba34be3433b41e201d111ecdfb18cf3.png)

2.在需要使用字段映射的语句上手动开启驼峰映射。下面是动态sql使用XML文件时，手动开启的步骤。直接写(直接写mapper文件,不使用mapper的XML的文件)的不用开启。

![screen-capture](8d85453647038d62c2aa641ddab74740.png)
Spring Data JPA是Spring的ORM框架，JPA的规范基础上做了封装形成一个新的框架，提供了对数据库的增删改查常见的操作，非常好扩展。

```text
Spring Data JPA在SpringBoot中的开发步骤：
1.在项目中导入Spring Data JPA的依赖启动器(starter)。
2.在数据库中表映射到va的一个pojo。需要通过注解进行配置。
3.来使用PA完成数据库的操作：需要实现PARepository接口（定义增删改查的操作方法）。
```

<br/>

<br/>

1.导入JPA依赖启动器

![screen-capture](ced13eda35243dcbea7d3f0e1fadbd97.png)

2.创建新的评论实体类(Discuss)和Mybatis的article区分开。![screen-capture](460b643936715abb1f5f4cf85a706a69.png)

JPA注解,使实体类映射到数据库的表中。

![screen-capture](fd44394f9df22d9abfb80e9a53b77f4f.png)

<br/>

这里报错,因为实体类的属性无法和数据库表的属性对应。

![screen-capture](5f517ff6f05e4b3ae85ea0a57d77e4de.png)

属性相同可以不写。注意主键的自增设置和映射。

3.创建一个接口，实现JPAResponsitory接口,完成增删改查。

![screen-capture](7ac060828014b5539ba73f31b05bc723.png)

<br/>

看一下JPAResponsitory接口

![screen-capture](f34c04be96c57a740042a92fbd88f6d5.png)

具体使用如下：

![screen-capture](23d99102c4500669943352aa92af6d78.png)

findBy  ( )  NotNull  括号里的是属性，其他的固定不变。

<br/>

在使用Spring Data JPA进行数据操作时，可以有多种实现方式，主要方式如下。
(1)如果自定义接口继承了JpaRepository接口，则默认包含了一些常用的CRUD方法(findAll...)。
(2)自定义Repository:接口中，可以直接使用方法名关键字进行查询操作。
其中，Spring Data JPA中支持的方法名关键字及对应的SQL片段说明，如下表所示。
(3)自定义Repository接口中，可以使用@Query注解配合SQL语句进行数据的查、改、删操作。

1.使用方法名关键字进行数据操作：

![screen-capture](8666d24813798a6e9d0cf5eeb08658ee.png)

<br/>

输出数据如下：

![screen-capture](f44cdbb615f4046e70569df51c529a01.png)

<br/>

（2）的表：

![screen-capture](94e5fa97cccfb1df69674a98127b9dc1.png)

![screen-capture](85dddb047f23cf1d03e2fdb992637146.png)

![screen-capture](e25e8a12c4248c7a3553c219f91d33bf.png)

2.调用JPA接口内部方法进行数据操作:

findById返回值类型是optional,要进行转换。

3.自定义方法配合@Query注解进行sql的增删改查：

根据文章id进行分页查询。这个pageable是JPA提供的分页插件。

参数中的Pageable是org.springframework.data,domain的。

1 是指?代表参数中的第一个占位符。

![screen-capture](57fdeb610428eea56c4c71f040628db1.png)

这里有个问题：如果写成select * from ...会报错，

![screen-capture](e91ef9fe6c11bce21ca94ce5128bcf98.png)

对此进行处理：

![screen-capture](5a8475d10930b4a2ecca8f4fa7868b87.png)

创建测试方法：

![screen-capture](528bb90434a2d0b36ef03f9069d0eb6e.png)

<br/>

 再来一个案例：注意！JPA的增删改查要强制开启事务。

![screen-capture](7b65957dd71112946220845f289279c6.png)

<br/>

创建测试方法：

![screen-capture](8bdd7c1aac2670a0deccf0cf564f416b.png)
[镜像](http://archive.apache.org/dist/zookeeper)

## Zookeeper安装与配置

### 1. JDK配置（已配置jdk18）

### 2. Zookeeper配置

> 下载压缩包，我下的3.80，选择第一个tar.gz

```textile
http://archive.apache.org/dist/zookeeper/
```

> 上传到Linux的opt文件夹下并解压

```textile
tar -zxvf apache-zookeeper-3.8.0-bin.tar.gz
```

> 重命名

```textile
mv apache-zookeeper-3.8.0-bin zookeeper
```

> 在/opt/zookeeper目录下创建zkData和zkLog目录

```textile
[rootelocalhost opt ]#icd zookeeper
[rootelocalhost zookeeper]#mkdir zkData
[rootelocalhost zookeeper]#mkdir zkLog
```

> 进入/op/zookeeper/conf路径，复制zoo_sample.cfg文件并重命名为zoo.cfg

```textile
[rootelocalhost zookeeper]#cd conf
[rootelocalhost conf]#cp zoo_sample.cfg zoo.cfg
```

***

> Linux克隆虚拟机

```textile
https://blog.csdn.net/mango_ZZY/article/details/109958585
```

第一个克隆机我放在了D:VMKeLong/zk_vm/zk01下

配置网卡问题看下面的链接视频

> Xshell配置静态ip

```textile
https://www.bilibili.com/video/BV1Gh411j7SS?p=21&vd_source=a5cd22c70b1ac85cdc2d76e8e650e9e7
```

![截图](91790e76cb950045c1e99be2337c97b7.png)

***

启动Zookeeper

```textile
cd /opt/zookeeper/bin
./zkServer.sh start
```

> 提示如下：

```textile
Using config: /opt/zookeeper/bin/../conf/zoo.cfg
Starting zookeeper ... STARTED
```

查看是否启动：

```textile
jsp
```

> 提示如下：有QuorumPeerMain就是成功

```textile
3272 Jps
3179 QuorumPeerMain
```

> QuorumPeerMain:Zookeeper对应的启动路口类，表示配置启动线程处于运行的状态

查看状态：

```textile
./zkServer.sh status
```

> 结果如下：

```textile
ZooKeeper JMX enabled by default
Using config: /opt/zookeeper/bin/../conf/zoo.cfg
Client port found: 2181. Client address: localhost. Client SSL: false.
Mode: standalone

```

> 说明：
> 
> 1.Zookeeper默认访问端口2181
> 
> 2.localhost表示Zookeeper安装在本台主机上
> 
> 3.standalone表示采用非集群的方式启动（表示孤独的意思）

启动Zookeeper的客户端：

```textile
./zkCli.sh
```

退出Zookeeper的客户端：

```textile
quit
```

停止Zookeeper的服务：

```textile
./zkServer.sh stop
```

结果如下：

```textile
ZooKeeper JMX enabled by default
Using config: /opt/zookeeper/bin/../conf/zoo.cfg
Stopping zookeeper ... STOPPED
```

查看状态（./zkServer.sh status），结果如下：

```textile
ZooKeeper JMX enabled by default
Using config: /opt/zookeeper/bin/../conf/zoo.cfg
Client port found: 2181. Client address: localhost. Client SSL: false.
Error contacting service. It is probably not running.
```

### 3. Zookeeper配置文件的解析

> 执行如下指令：

```textile
zoo.cfgvim /opt/zookeeper/conf/zoo.cfg
```

> 大致代码如下：

```textile
# The number of milliseconds of each tick
tickTime=2000
# The number of ticks that the initial 
# synchronization phase can take
initLimit=10
# The number of ticks that can pass between 
# sending a request and getting an acknowledgement
syncLimit=5
# the directory where the snapshot is stored.
# do not use /tmp for storage, /tmp here is just 
# example sakes.
dataDir=/opt/zookeeper/zkData
dataLogDir=/opt/zookeeper/zkLog
# the port at which the clients will connect
clientPort=2181
# the maximum number of client connections.
# increase this if you need to handle more clients
#maxClientCnxns=60
```

> 参数解析：

|参数|描述|
|--|--|
|tickTime=2000|通信心跳数，Zookeeper服务器与客户端心跳时间，单位毫秒。Zookeepert使用的基 本时间，服务器之间或客户端与服务器之间维持心跳的时间间隔，也就是每个tickTime 时间就会发送一个心跳，时间单位为毫秒|
|initLimit=10|LF初始通信时限。集群中的Follower跟随者服务器与Leader领导者服务器之间，启动 时能容忍的最多心跳数。10*2000(10个心跳时间)如果领导和跟随者没有发出心跳 通信，就视为失效的连接，领导和跟随者彻底断开。|
|syncLimit=5|LF同步通信时限。集群启动后，Leader与Follower之间的最大响应时间单位，假如响 应超过syncLimit*tickTime=1O秒，Leader就认为Follweri已经死掉，会将Follwer从服 务器列表中删除。|
|dataDir|数据文件目录+数据持久化路径|
|dataLogDir|日志文件目录|
|clientPort=2181|客户端连接端口。监听客户端连接的端口|

> Zookeeper服务的默认端口是8080,修改如下（zoo.cfg配置文件加入）：

```textile
admin.serverPort=8082
```

### 4. Zookeeper内部原理

### 4.1 Zookeeper的选举策略

半数机制：在集群环境中半数以上的机器存活，这个集群开可用。所以在设计Zookeeper集群系统时，通常会选择奇数台服务器来搭建Zookeeper的集群。

在配置文件中即便不去配置任何关于主节点和从节点的内容。Zookeeper集群启动成功后，仍然会选择出主节点和从节点，Zookeeper:是有临时选举策略的。

![screen-capture](58b34028ad7c46512a6d8392debf64e4.png)

1. Server1先投票，投给自己，自己为1票，没有超过半数，根本无法成为leader,顺水推舟将票数投给了id比自己大的Server2。
2. Server2也把自己的票数投给了自己，再加上Server1给的票数，总票数为2票，没有超过半数，也无法成为leader,也学习Server1,顺水推舟，将自己所有的票数给了id比自己大的Server3。
3. Server:3得到了Server1和Server2的两票，再加上自己投给自己的一票。3票超过半数，顺利成为leader。
4. Server4和Server5都投给自己，但是无法改变Server.3的票数，只好听天由命，承认Server3是leader。

### 4.2 节点类型

**1.持久型**

1. 特点：客户端如果和Zookeeper断开了连接，对应的节点上数据依旧持久保存着。
2. 创建ZNodel时按照顺序来进行标识节点，ZNode名称后面追加一个数字的值，例如：Znode001、Znode002、Znode003.顺序号是一个单调递增的数字来进行标记。

**2.短暂型**

1. 特点：客户端和Zookeeperl断开连接之后，该节点会被自动的回收
(自动的删除)
2. 创建ZNode节点的时候，ZNode名称会追加一个数字的值，顺序编号是一个单调递增的数字：例如：Znode001、Znode002、Znode003.

### 4.3 监听器原理

1. 在main方法中创建Zookeeper?客户端的同时就会创建两个线程，一个负责网络连接通信，一个负责监听。
2. 监听事件就会通过网络通信发送给Zookeeper。
3. Zookeeper获得注册的监听事件后，立刻将监听事件添加到监听列表里。
4. Zookeeper监听到数据变化或路径变化，就会将这个消息发送给监听线程。
   
   常见的监听：
   - 监听节点数据的变化：get path[watch]
   - 监听子节点增减的变化：is path[watch]

5. 监听线程就会在内部调用process0方法（需要开发者实现process(0方法的内容）。

![screen-capture](3a836379f9e3299b16156b6824c7336c.png)

### 4.4 写数据流程解析

1. Client想向ZooKeeper的Server1据，必须得先发送-个写的请求
2. 如果Server1不是Leader,.那么Server1会把接收到f请进一转发GLeader。
3. 这个Leader?会将写婧求广擂拾各个Server,各个Server3写成功后就会通知Leader。
4. 当LeaderL收到半数以上的Server数据写成功了，那么就说明数据写成功了。
5. 随后，Leader会告诉Server1数据写成功了。
6. Server1会反馈通知Client数据写成功了，整个流程结束。

![screen-capture](1ffd998ad7f7d6abcd1dd446093c6acd.png)

## 5. Zookeeper集群搭建

### 5.1 分布式环境安装部署

Zookeeper?集群环境搭建：需要使用3 CentOS系统，分别在这三台系统安装Zookeeper,并配置Zookeeper的相关配置。这三台服务器就构成了一个集群的环境。

#### 5.1.1 配置服务的id（编号）

每台操作系统都有一个ip。

1.Zookeeper要求必须在dataDir=/opt/zookeeper/zkData属性所指向的目录下创建一个文件myid作为文件。这个文件中的数字就代表当前Zookeeper编号。zookeeper1-1...

```textile
/opt/zookeeper/zkData/myid
1
```

#### 5.1.2 配置集群IP

1.zoo.cfg文件维护了Zookeeper的IP集群配置。

```sh
# server.A=B:C:D
server.1=192.168.1.4:2888:3888
server.2=192.168.1.5:2888:3888
server.3=192.168.1.6:2888:3888
```

2.配置参数解读server.A+B:C:D。

|参数|描述|
|--|--|
|A|一个数字，表示第几号服务器。集群模式下配置的/opt/zookeeper/zkData/myid文件里面的数据就是 A的值|
|B|服务器的IP地址|
|C|与集群中Leader服务器交换信息的端口|
|D|选举时专用端口，万一集群中的Leader服务器挂了，需要一个端口来重新进行选举，选出一个新的 Leader,而这个端口就是用来执行选举时服务器相互通信的端口|

<br/>

<br/>

![screen-capture](6048af356d992f18107017c2cd189a35.png)

***

准备创建三个克隆机

```textile
192.168.1.4  1
192.168.1.5  2
192.168.1.6  3
```

> 在第一个克隆机上配置id为1

```textile
vim /opt/zookeeper/zkData/myid
```

> 在第一个克隆机上配置集群ip

```sh
vim /opt/zookeeper/conf/zoo.cfg
```

> 配置集群环境

```textile
server.1=192.168.1.4:2888:3888
server.2=192.168.1.5:2888:3888
server.3=192.168.1.6:2888:3888
```

#### 5.1.3配置其他两台服务器

以zk01为克隆对象，克隆出zk02。

> 切换root

```textile
su
```

> 配置id

```textile
vim /opt/zookeeper/zkData/myid
2
```

> 生成uuid

```textile
uuidgen
```

> 复制生成的UUID,进入网卡配置

```textile
cd /etc/sysconfig/network-scripts/
vim ifcfg-ens33
```

> 配置如下

```textile
UUID="新的UUID"

IPADDR=192.168.1.5
GATEWAY=192.168.1.2
NETMAzkSK=255.255.255.0
DNS=114.114.114.114
```

> 重启网卡，显示OK即可

```textile
service network restart
```

> 选中zk02->右键设置->网络适配器->高级->生成新的Mac地址

> zk03同上

#### 5.1.4 集群操作

1.关闭集群中的每一个节点的防火墙。

```textile
systemctl stop firewalld.service #停止防火墙，临时停止，如果服务器重启，则防火墙自动开启
systemctl disable firewalld #禁止防火墙开机自启动
```

2.查看当前防火墙的状态：（active-运行、dead-关闭）

```textile
systemctl status firewalld
```

3.启动Zookeeper服务（先进入/opt/zookeeper/bin）

```textile
./zkServer.sh start
```

4.查看Zookeeper状态

```textile
./zkServer.sh status
```

> 说明：
Model:follower:表示该Zookeeperl服务是一个从节点
Mode:leader:表示该Zookeeper服务是一个主节点

### 5.2 Zookeeper客户端命令

#### 5.2.1 客户端命令

1.启动Zookeeper的客户端，bin目录下的ckCli.sh

```textile
./zkCli.sh
```

2.查看Zookeeper提供的常见命令

```textile
help
```

3.查看当前节点下ZNode中包含的内容。默认有一个zookeeper的节点

```textile
ls /
#[zookeeper]
```

4.查看当前节点详情数据

```textile
ls -s /
#结果如下
[zookeeper]
cZxid = 0x0
ctime = Wed Dec 31 16:00:00 PST 1969
mZxid = 0x0
mtime = Wed Dec 31 16:00:00 PST 1969
pZxid = 0x0
cversion = -1
dataVersion = 0
aclVersion = 0
ephemeralOwner = 0x0
dataLength = 0
numChildren = 1

```

节点的参数信息

|参数名|描述|
|--|--|
|cZxid|创建节点的事务。每次修改ZooKeeper状态都会收到一个zxid形式的时间戳，也就是 ZooKeeper3事务ID。事务ID是ZooKeepert中所有修改总的次序。每个修改都有唯一的 zxid,如果zxid1小于zxid2,那么zxid1在zxid2之前发生。|
|ctime|被创建的毫秒数（从1970开始）|
|mZxid|最后更新的事务zxid|
|mtime|最后修改的毫秒数（从1970开始）|
|pZxid|最后更新的子节点zxid|
|cversion|创建版本号，子节点修改次数|
|dataVersion|数据变化版本号|
|aclVersion|权限版本号|
|ephemeralOwner|如果是临时节点，这个是znode拥有者的session id。如果不是临时节点则是0|
|dataLength|数据长度|
|numChildren|子节点数|

#### 5.2.2 节点操作

1.在根节点下创建（create）两个节点（/）

```textile
create /cn
create /us
```

2.在创建节点的时候，同时向节点中保存数据

```textile
create /rus 'pujing'
```

3.获取节点中的数据

```textile
get /rus
```

4.多级节点的创建。如果父节点不存在，会报错。

```textile
create /jp/Toyen 'hot'
```

5.创建短暂节点。在客户端断开连接后，这个节点就会被回收

```textile
create -e /uk
```

6.创建带序号的节点

- 在cn节点下，创建三个城市节点
- 如果创建的节点期望顺序编号，需要指定一个参数 -s
- 如果在指定节点下，已经存在了一个节点，所创建出来的新节点编号从1开始取值（默认从0开始取值）

7.修改节点中的数据

```textile
create /jp/Tokyo 'hoy'
set /jp/Tokyo 'too hot'
get /jp/Tokyo #too hot
```

8.删除节点

```textile
delete /jp/Tokyo
```

9.通过递归的方式来删除指定节点及该节点下所有的子节点

```textile
deleteall /cn
```

10.监听指定节点的值改变或者子节点的变化（路径发生变化）

（1）在zk03节点上注册一个事件监听（通过节点的名称来确定要监听谁）

```
addWatch /us
```

（2）在zk01节点上修改了us节点的数据内容

```
set /us 'meiguo'
```

（3）在zk03节点上，提示监听到us的事件，事件被触发了

```textile
WATCHER::

WatchedEvent state:SyncConnected type:NodeDataChanged path:/us

```

（4）在zk01节点上，给us节点添加了子节点

```textile
create /us/NewYork
```

（5）查看zk03节点，监听到了目标节点子节的改变

```textile
WATCHER::

WatchedEvent state:SyncConnected type:NodeCreated path:/us/NewYork

```

## 5. Zookeeper实战

### 5.1 Zookeeper的API应用

目的通过Zookeeper提供剁ava的APl技术，来操作和访问Zookeeper?集群。例如，向集群中插入节点，或者获取集群中某个节点的数据内容，例如删除集群中某个节点。

#### 5.1.1 项目环境搭建

1.创建一个项目：test_zookeeper。项目类型Maven类型

2.添加依赖

```xml
 <dependency>
      <groupId>junit</groupId>
      <artifactId>junit</artifactId>
      <version>4.13.2</version>
      <scope>test</scope>
    </dependency>
    <!--最新的zookeeper的jar版本是3.8,0。推荐项目zookeeper依赖和zookeeper安装包版本一致-->
    <dependency>
      <groupId>org.apache.zookeeper</groupId>
      <artifactId>zookeeper</artifactId>
      <version>3.8.0</version>
    </dependency>
    <dependency>
      <groupId>org.apache.logging.log4j</groupId>
      <artifactId>log4j-core</artifactId>
      <version>2.20.0</version>
    </dependency>
```

3.在resources目录下创建一个log4j.properties

```properties
log4j.rootLogger=INF0, stdout
log4j.appender.stdout=org.apache.log4j.ConsoleAppender
log4j.appender.stdout.layout=org.apache.log4j.PatternLayout
log4j.appender.stdout.layout.ConversionPattern=%d %p [%c] - %m%n


log4j.appender.logfile=org.apache.log4j.FileAppender
log4j.appender.logfile.File=target/zk.Log
log4j.appender.logfile.layout=org.apache.log4j.PatternLayout
log4j.appender.logfile.layout.ConversionPattern=%d %p [%c] - %m%n
```

#### 5.1.2 创建Zookeeper客户端

在项目测试包下进行测试：ZookeeperTests测试类

```textile
/**
 * Zookeeper客户端
 * */
public class ZookeeperTests {

    //集群的IP地址，集群的IP使用"，"分隔，同时需要指定客户端通过那一个端口连接集群(2181)
    private String connectionStr =
            "192.168.1.4:2181,192.168.1.5:2181, 192.168.1.6:2181";

    //创建Zookeeper客户端对象，通过该对象来节点Zookeeper
    private ZooKeeper zooKeeperClient;

    //单位是毫秒
    //sessionTimeout属性：在指定的时间内来尝试连接Zookeeper集群，如果超出该指定的时间，此群如果来没有连接上，不会再去尝试
    private int sessionTimeout = 60 * 1000;//如果超出了60秒还没有连接上集群，会报错

    //连接Zookeeper集群前的初始化工作准备
    // @Test
    @Before //在其他测试方法之前被调用
    public void init() throws IOException {  //Zookeeper三台服务器是处于正常运行状态
        //Zookeeper集群是可以创建监听器，主要监听节点数据变化或者子节点变化
        Watcher watcher = new Watcher() {
            @Override
            public void process(WatchedEvent watchedEvent) {
                System.out.println("监听事件执行.，，.");
            }
        };
        //初始化Zookeeper对象
        zooKeeperClient = new ZooKeeper(connectionStr, sessionTimeout, watcher);

    }
}
```

<br/>

<br/>

#### 5.1.3 创建节点

**1. ACL对象介绍**

一个ACL对象就是一个ld和permission对

- 表示哪个/哪些范围的Id(Who)在通过了怎样的鉴权(How)之后，就允许进行那些操作(What)。即 Who How What
- permission(What)就是一个int表示的位码，每一位代表一个对应操作的允许状态
- 类似Liux的文件权限，不同的是共有S种操作：CREATE、READ、VRITE、DELETE、ADMIN(对应更改ACL的权限)。

|参数|描述|
|--|--|
|OPEN_ACL_UNSAFE|创建开放节点，允许任意操作（用的最多，其余的权限用的很少）|
|READ_ACL_UNSAFE|创建只读节点|
|CREATOR_ALL_ACL|创建者才有的全部权限|

**2. 创建节点实现**

通过Zookeeper对象来创建节点

```textile
 //创建节点
    @Test
    public void createNode() throws InterruptedException, KeeperException {
        /**create()方法：表示在指定的节点下创建一个新的节点。create()方法会将创建成功的节点名称作为方法的返回值
        *参数1：表示创建的节点名称，需要指定完整的父节点
        *参数2：表示在创建该节点的同时，初始化的节点数据
        *参数3：节点权限
        *参数4：节点的类型
        */
        String nodeCreate=zooKeeperClient.create("/yuanxin",
                "袁老师".getBytes(),
                ZooDefs.Ids.OPEN_ACL_UNSAFE,
                CreateMode.PERSISTENT);

        System.out.println("nodeCreate="+nodeCreate);
    }
```

运行结果如下：

```textile
监听事件执行.，，.
22:24:21.964 [main-SendThread(192.168.1.4:2181)] DEBUG org.apache.zookeeper.ClientCnxn - Reading reply session id: 0x100002097520001, packet:: clientPath:null serverPath:null finished:false header:: 1,4  replyHeader:: 1,4294967323,0  request:: '/yuanxin,F  response:: #ffffffe8ffffffa2ffffff81ffffffe8ffffff80ffffff81ffffffe5ffffffb8ffffff88,s{4294967321,4294967321,1689775460561,1689775460561,0,0,0,0,9,0,4294967321} 
nodeCreate=/yuanxin
```

**3.Session超时异常**

在运行createNode(O方法的时候抛出一个异常：ClientCnxn$SesssionTimeoutException异常

解决方案：

- 防火墙没有关闭：systemctl stop firewalled
- 检查客户端P集群定义的字符串是否正确
- 增加sessionTimeout?变量的取值（等待时间加大--50*1000）

#### 5.1.3 查询节点的值

getSData()方法查询节点的数据

```textile
 @Test
    public void find() throws InterruptedException, KeeperException {
        /**参数1：表示被查询的节点名称（完整节点路径）
        *参数2：是一个boolean:类型的取值(false不需要)
        *参数3：接收一个Stat类型的对象，直接new实例化一个Stat对象
        */
        byte[] data = zooKeeperClient.getData("/yuanxin",false,new Stat());
        //把字节码数组转化成一个字符串
        String content = new String(data);
        System.out.println(content);
    }
```

运行结果如下：

```textile
监听事件执行.，，.
22:24:21.964 [main-SendThread(192.168.1.4:2181)] DEBUG org.apache.zookeeper.ClientCnxn - Reading reply session id: 0x100002097520001, packet:: clientPath:null serverPath:null finished:false header:: 1,4  replyHeader:: 1,4294967323,0  request:: '/yuanxin,F  response:: #ffffffe8ffffffa2ffffff81ffffffe8ffffff80ffffff81ffffffe5ffffffb8ffffff88,s{4294967321,4294967321,1689775460561,1689775460561,0,0,0,0,9,0,4294967321} 
content=袁老师

```

#### 5.1.3 修改节点的值

setData()方法

```textile
//节点更新
@Test
    public void update()throws InterruptedException,KeeperException {

        /**参数1：表示被修改的节点名称（即对那一个节点的数据进行修改操作）
         *参数2：被修改的新数据（需要转化成字节数组）
         *参数3：dataVersion=0属性的取值为0，数据变化版本号(0-n)
         */
        Stat stat
                = zooKeeperClient.setData("/yuanxin", "".getBytes(), 0);
        //表示是当前操作的节点元数据，输出的这个节点详情信息
        //stat=4294967321,4294967326,1689775460561,1689777350528,1,0,0,0,0,0,4294967321
        System.out.println("stat=" + stat);

    }
```

测试结果如下

```textile
监听事件执行.，，.
22:35:52.670 [main-SendThread(192.168.1.5:2181)] DEBUG org.apache.zookeeper.ClientCnxn - Reading reply session id: 0x2000016d83f0002, packet:: clientPath:null serverPath:null finished:false header:: 1,5  replyHeader:: 1,4294967326,0  request:: '/yuanxin,,0  response:: s{4294967321,4294967326,1689775460561,1689777350528,1,0,0,0,0,0,4294967321} 
stat=4294967321,4294967326,1689775460561,1689777350528,1,0,0,0,0,0,4294967321
```

#### 5.1.4 删除节点的值

delete()方法用来删除指定的节点

```
 @Test
    public void delete()throws InterruptedException,KeeperException{
    /**
     *参数1：表示根据节点名来删除指定的节点
     *参数2：表示增删改的操作都需要指定一个版本号dataVersion=1
     */
    zooKeeperClient.delete("/yuanxin",2);//setdata() 1 -0  2 -1...
    System.out.println("删除成功！");
    }
```

#### 5.1.5 判断节点是否存在

exists()方法用来判断指定的节点是否存在

```textile
 //判断节点是否存在 
 @Test
    public void exist()throws InterruptedException,KeeperException{
        //如果stat返回值为uLL表示指定的节点不存在
        Stat stat =zooKeeperClient.exists("/yuanxin",false);
        System.out.println("stat="+stat);
        String flag=stat==null?"该节点不存在":"该节点存在";
        System.out.println("flag="+flag);
    }
```

#### 5.1.6 获取子节点

> 提前准备

```textile
[zk: localhost:2181(CONNECTED) 23] create /cn
Created /cn
[zk: localhost:2181(CONNECTED) 24] create /cn/shannxi
Created /cn/shannxi
[zk: localhost:2181(CONNECTED) 25] create /cn/zhejiang
Created /cn/zhejiang
[zk: localhost:2181(CONNECTED) 26] create /cn/hunan
Created /cn/hunan
[zk: localhost:2181(CONNECTED) 27] get /cn
null

```

getChildren()方法用来获取指定节点的所有子节点

```textile
//获取指定节点的所有子节点
    @Test
    public void getChildrenNodes() throws InterruptedException, KeeperException {
        //根据指定的节点名称来获取该节点下所有的子节点
        List<String> childNodes = zooKeeperClient.getChildren("/cn", false);
        for (String node : childNodes) {
            System.out.println(node);
        }
    }
```

#### 5.1.7 监听节点的变化

watch是一个boolean类型的变量，表示是否开启对应的节点监听，true表示开启这个节点的监听

```
 //监听节点
 @Test
    public void listenChildNodes()throws InterruptedException,KeeperException,IOException{

        /**参数1：表示指定要获取那一个节点下所有的子节点
         * 参数2：true表示注册监听器
         */

        //List<string>getchildren(String path,boolean watch)
        //只要根结点结构发生改变，watch对象中的process()方法就会被执行（自动被回调）
        List<String>child
        Nodes =zooKeeperClient.getChildren("/",true);
        for (String node :childNodes){
            System.out.println(node);
        }
        //让线程不停止，等待监听器的响应
        System.in.read();//线程在当前代码处处于等待的状态，不会在往后执行了
    }
```

### 5.2 模拟美团商家上下线

### 5.2.1 分析需求

1.模拟一个美团的服务平台，完成商家营业状态和打烊状态的通知和监控

2.创建一个/meituan节点

```textile
create /meituan
```

### 5.2.2 项目环境搭建

1.创建一个Maven类型的项目，项目名称设置为：zk_meituan

2.添加依赖

```xml
 <dependency>
        <groupId>junit</groupId>
        <artifactId>junit</artifactId>
        <version>4.13.2</version>
        <scope>test</scope>
      </dependency>
      <!--最新的zookeeper的jar版本是3.8,0。推荐项目zookeeper依赖和zookeeper安装包版本一致-->
      <dependency>
        <groupId>org.apache.zookeeper</groupId>
        <artifactId>zookeeper</artifactId>
        <version>3.8.0</version>
      </dependency>
      <dependency>
        <groupId>org.apache.logging.log4j</groupId>
        <artifactId>log4j-core</artifactId>
        <version>2.20.0</version>
      </dependency>

```

3.在项目的resources目录下创建log4j.properties文件、

```properties
log4j.rootLogger=INF0, stdout
log4j.appender.stdout=org.apache.log4j.ConsoleAppender
log4j.appender.stdout.layout=org.apache.log4j.PatternLayout
log4j.appender.stdout.layout.ConversionPattern=%d %p [%c] - %m%n


log4j.appender.logfile=org.apache.log4j.FileAppender
log4j.appender.logfile.File=target/zk.Log
log4j.appender.logfile.layout=org.apache.log4j.PatternLayout
log4j.appender.logfile.layout.ConversionPattern=%d %p [%c] - %m%n
```

### 5.2.3 商家服务类

商家服务类名称： MerchantServer 定义业务功能

```java
/**
 * 商家类
 * */
public class MerchantServer {

    //zk集群IP
    private static String connectionString =
            "192.168.1.4,192.168.1.5,192.168.1.6";

    //zk连接等待时间
    private static int sessionTimeout = 60 * 1000;

    //zk客户端对象
    private ZooKeeper zooKeeperClient = null;

    //封装一个方法，创建Zookeeper集群的客户端连接对象
    public void getConnection() throws IOException {
        zooKeeperClient =
                new ZooKeeper(connectionString, sessionTimeout, new Watcher() {
                    @Override
                    public void process(WatchedEvent watchedEvent) {
                        //监听器会被回调的方法
                    }
                });

    }


    //注册到集群(/meituan,/新哥刀削面、/meituan/杨哥蛋炒饭)

    /**
     * 0x000000-新哥刀削面
     * 0x000001-杨哥蛋炒饭
     * <p>
     * create-s/cn/city-->连续执行了3遍
     * city0x000000000
     * city0x000000001
     * city0x000000002
     * city0x000800003
     */
    public void register(String merchantName) throws KeeperException, InterruptedException {
        //EPHEMERAL_SEQUENTIAL表示当前所创建的节点是一个短暂型节点，并且是是有序型的
        //返回的字符串名称就是被创建的商家节点名称(merchant0x080080081)
        String create = zooKeeperClient.create(
                "/meituan/merchant",
                merchantName.getBytes(),
                ZooDefs.Ids.OPEN_ACL_UNSAFE,
                CreateMode.EPHEMERAL_SEQUENTIAL);
        System.out.println(merchantName + "开始营业" + create);
    }

    //业务功能
    public void business(String merchantName) throws IOException {

        System.out.println(merchantName + ":正在营业中..，.");

        //耗时操作
        System.in.read();

    }

    //生命周期main
    public static void main(String[] args) throws IOException, InterruptedException, KeeperException {//KFC

        //1.创建商家服务对象
        MerchantServer merchantServer = new MerchantServer();
        //2.连接Zookeeper服务集群（和美团平台取得连接）
        merchantServer.getConnection();
        //了.将商家入住美团（将服务器节点节点进行注册）
        merchantServer.register(args[0]);
        //4.业务逻辑处理（做生意）
        merchantServer.business(args[0]);
        
    }
}

```

### 5.2.4 客户端

客户端类的名称：Customers

```java
/**
 * 客户端类
 * */
public class Customers {

    //zk集群IP
    private static String connectionString =
            "192.168.1.4,192.168.1.5,192.168.1.6";

    //zk连接等待时间
    private static int sessionTimeout = 60 * 1000;

    //zk客户端对象
    private ZooKeeper zooKeeperClient = null;


    //创建Zookeeper的客户端连接
    public void getConnection() throws IOException {
        zooKeeperClient = new ZooKeeper(connectionString,sessionTimeout,new Watcher(){
            //回调方法：当监听的节点发生改变的时候，此方法会被自动的回调
            @Override
            public void process(WatchedEvent watchedEvent) {
                //一旦/meituan节点下的子节点发生改变，需要将最新的节点在客户端进行重新请求获取最新的节点列表
                //获取最新的商家列表
                try {
                    getMerchantList();
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                } catch (KeeperException e) {
                    throw new RuntimeException(e);
                }
            }}
        );
    }



    //获取服务器商家列表信息（如果要获取某个节点下所有的子节点：getChildren()方法完成）
    public void getMerchantList() throws InterruptedException, KeeperException {
        //1.获取了商家的列表（处于运营状态的商家列表）
        //true表示开启对/meituan监听(merchant8x0808001)
        List<String> merchants =zooKeeperClient.getChildren("/meituan",true);
        //2.根据节点的名称来获取该节点对应的数据信息。可以言D5%等串集合来存储所有节点的数据
        List<String>merchantDataList = new ArrayList<>();
        //3.通过遍历节点的名称来获取节点的数据，再把获取的数据保存到merchantDataList:集合中
        for (String merchant : merchants) {
            byte[] data = zooKeeperClient.getData("/meituan/" + merchant, false, new Stat());
            merchantDataList.add(new String(data));
        }

        //4.打印服务器商家最新的列表信息
        System.out.println(merchantDataList);

    }

    //业务功能
    public void business()throws IOException{
        System.out.println("客户正在浏览外卖商家的店，，.");
        System.in.read();
    }
    public static void main(String[]args)throws IOException,InterruptedException,KeeperException{

        //1.创建Zookeeper连接（客户打开了美团APP)
        Customers client = new Customers();
        //2.连接平台
        client.getConnection();
        //3.获取/meituan节点下所有的子节点（从美团平台上获取商家的列表信息）
        client.getMerchantList();
        //4.业务进行调用（浏览外卖点，对比商家、点餐）
        client.business();

    }
    
}

```

#### 5.2.5 功能测试

运行客户端类main方法如下：

```textile
[]
客户正在浏览外卖商家的店，，.
09:46:12.540 [main-SendThread(192.168.1.6:2181)] DEBUG org.apache.zookeeper.ClientCnxn - Reading reply session id: 0x3000016871d0003, packet:: clientPath:null serverPath:null finished:false header:: 2,8  replyHeader:: 2,4294967355,0  request:: '/meituan,T  response:: v{} 
[]
```

在虚拟机上（三选一）运行每行代码， ==》是客户端控制台输出的结果

```textile
create /meituan/KFC 'FKC'  ==》 [FKC]
create /meituan/discos 'discos' ==》 [FKC, discos]
create /meituan/McDonalds 'McDonals' ==》  [FKC, discos, McDonals]
ls /meituan
```

运行商家类的main方法，结果如下

```textile
Exception in thread "main" java.lang.ArrayIndexOutOfBoundsException: 0
	at com.cy.meituan.MerchantServer.main(MerchantServer.java:75)
```

因为没有参数，配置Configurations，传入“新哥外卖” apply

![截图](297464c4057a2df56492bdaabfc16262.png)

<br/>

重新运行main方法，结果如下

```textile
新哥外卖开始营业/meituan/merchant0000000003
新哥外卖:正在营业中..，.

```

观察客户端类控制台输出如下（证明实时监控）

```textile
[FKC, discos, 新哥外卖, McDonals]
```

<br/>

### 5.3 案例-分布式锁商品秒杀

锁：我们在多线程中接触过，作用就是让当前的资源不会被其他线程访问。

- 我的日记本，不可以被别人看到。所以要锁在保险柜中。
- 当我打开锁，将日记本拿走了，别人才能使用这个保险柜。

在Zookeeperr中使用传统的锁会引发的“羊群效应”。1000个人创建节点，只有一个人能成功，999人需要等待。
羊群是一种很散乱的组织，平时在一起也是盲目地左冲右撞，但一旦有一只头羊动起来，其他的羊也会不假思
索地一哄而上，全然不顾旁边可能有的狼和不远处更好的草。羊群效应就是比喻人都有一种从众心理，从众心
理很容易导致盲从，而盲从往往会陷入骗局或遭到失败。

![screen-capture](2de97d0b7912a92a9b05369c128849c1.png)

为了避免“羊群效应"的产生，Zookeeper采用分布式锁来解决“羊群效应"的问题。

![screen-capture](e09b1419c367deae90992ff9c4623388.png)

1.所有请求进来，
在/lock下创建临时顺序节点，Zookeeper?会帮你编号排痉。
2判断自己是不ocK吓最小的节点。

- 是，获得锁（创建节点）
- 否，对前面小我一级的节点进行监听

3.获得锁请求，处理完业务逻辑，释放锁（删除节点），后一个节点得到通知。
4.重复上面的步骤二。

#### 5.3.2 数据准备

1.创建一个商品表，保存5件优惠商品。创建一个订单表。放在一个指定的库

```sqlserver
CREATE DATABASE zk_db CHARSET utf8;
USE zk_db;

CREATE TABLE product(
id INT PRIMARY KEY AUTO_INCREMENT COMMENT "商品编号",
product_name VARCHAR(20) NOT NULL COMMENT"商品名称",
stock INT NOT NULL COMMENT "库存",
VERSION INT NOT NULL COMMENT "版本"
);

INSERT INTO product(product NAME,stock,VERSION)VALUES('锦鲤-清空购物车-大奖',5,0);

CREATE TABLE `order`(
id VARCHAR(l00) PRIMARY KEY COMMENT "订单编号",
pid INT NOT NULL COMMENT "商品编号",
userid INT NOT NULL COMMENT "用户编号"
);
```

### 5.3.3 搭建工程

1.搭建一个Maven类型的项目，项目的名称：zk_product

2.手动创建webapp目录，自动生成WEB_INF/web.xml

3.使用SSM架构来搭建项目的后台（SSM框架的整合）

```xml
<project xmlns="http://maven.apache.org/POM/4.0.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
  xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 http://maven.apache.org/maven-v4_0_0.xsd">
  <modelVersion>4.0.0</modelVersion>
  <groupId>com.cy</groupId>
  <artifactId>zk_product</artifactId>
  <packaging>war</packaging>
  <version>1.0-SNAPSHOT</version>
  <name>zk_product Maven Webapp</name>
  <url>http://maven.apache.org</url>
  <properties>
    <!--定义一个变量：spring.version -->
    <spring.version>5.2.7.RELEASE</spring.version>
  </properties>
  <dependencies>
    <!--spring-->
    <dependency>
      <groupId>org.springframework</groupId>
      <artifactId>spring-context</artifactId>
      <version>${spring.version}</version>
    </dependency>
    <dependency>
      <groupId>org.springframework</groupId>
      <artifactId>spring-beans</artifactId>
      <version>${spring.version}</version>
    </dependency>
    <dependency>
      <groupId>org.springframework</groupId>
      <artifactId>spring-webmvc</artifactId>
      <version>${spring.version}</version>
    </dependency>
    <dependency>
    <groupId>org.springframework</groupId>
    <artifactId>spring-jdbc</artifactId>
    <version>${spring.version}</version>
    </dependency>

    <!--MyBatis-->
    <dependency>
      <groupId>org.mybatis</groupId>
      <artifactId>mybatis</artifactId>
      <version>3.5.5</version>
    </dependency>
    <dependency>
      <groupId>org.mybatis</groupId>
      <artifactId>mybatis-spring</artifactId>
      <version>2.0.5</version>
    </dependency>
    <!--连接池-->
    <dependency>
      <groupId>com.alibaba</groupId>
      <artifactId>druid</artifactId>
      <version>1.1.10</version>
    </dependency>
    <!--数据库-->
    <dependency>
      <groupId>mysql</groupId>
      <artifactId>mysql-connector-java</artifactId>
      <version>8.0.20</version>
    </dependency>
    <!--junit-->
    <dependency>
      <groupId>junit</groupId>
      <artifactId>junit</artifactId>
      <version>4.12</version>
      <scope>test</scope>
    </dependency>
    <dependency>
      <groupId>org.apache.curator</groupId>
      <artifactId>curator-recipes</artifactId>
      <version>4.2.0</version>
    </dependency>
  </dependencies>
  <build>
    <finalName>zk_product</finalName>
  </build>
</project>

```

5.添加了项目的内嵌Tomcat插件，通过plugin标签进行的配置

```xml
<build>
    <finalName>zk_product</finalName>
    <plugins>
      <!--Maven内嵌的Tomcat插件-->
      <plugin>
        <groupId>org.apache.tomcat.maven</groupId>
        <!--目前Apache只提供Tomcat6和Tomcat7两个插件-->
        <artifactId>tomcat-maven-plugin</artifactId>
        <version>2.2</version>
        <configuration>
          <port>8081</port>
          <path>/</path>
        </configuration>
        <executions>
          <execution>
            <!--打包完成后，运行服务-->
            <phase>package</phase>
            <goals>
              <goal>run</goal>
            </goals>
          </execution>
        </executions>
      </plugin>
    </plugins>
  </build>
```

### 5.3.4 搭建SSM环境

1.创建一个文件夹mybatis,.在该文件夹下配置mybatis-config.xml

```xml
<?xml version="1.0" encoding="UTF-8" ?>
<!DOCTYPE configuration
        PUBLIC "-//mybatis.org//DTD Config 3.0//EN"
        "http://mybatis.org/dtd/mybatis-3-config.dtd">
<configuration>

    <settings>
      <!--后台的日志输出，针对开发者，SQL操作的语句打印在控制台-->
      <setting name="logImpl" value="STDOUT_LOGGING"/>
      <!--开启驼峰映射-->
      <setting name="mapUnderscoreToCamelCase" value="true"/>
      <!--开启二级缓存-->
      <setting name="cacheEnabled" value="true"/>
    </settings>

</configuration>
```

2.创建spring文件夹，Spring框架的核心配置文件spring.xml(配置Spring框架和SpringMVC框架）

```xml
<?xml version="1.0" encoding="UTF-8"?>
<beans xmlns="http://www.springframework.org/schema/beans"
       xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
       xmlns:context="http://www.springframework.org/schema/context"
       xmlns:tx="http://www.springframework.org/schema/tx"
       xsi:schemaLocation="http://www.springframework.org/schema/beans
       http://www.springframework.org/schema/beans/spring-beans.xsd
       http://www.springframework.org/schema/context
       https://www.springframework.org/schema/context/spring-context.xsd
       http://www.springframework.org/schema/tool
       http://www.springframework.org/schema/tool/spring-tool.xsd">


    <!--1.扫描包的结构：com.cy.product -->
    <context:component-scan base-package="com.cy.product"/>

    <!--2.配置连接池-->
    <bean id="dataSource" class="com.alibaba.druid.pool.DruidDataSource" destroy-method="close">
        <property name="driverClassName" value="com.mysql.cj.jdbc.Driver"/>
        <property name="url" value="jdbc:mysql://localhost:3306/zk_db?serverTimezone=GMT"/>
        <property name="username" value="root"/>
        <property name="password" value="hsxsdm"/>
        <property name="maxActive" value="10"/>
        <property name="minIdle" value="5"/>
    </bean>

    <!--3.创建SqlSessionFactory对象，引入dataSource数据源对象-->
    <bean id="sessionFactory" class="org.mybatis.spring.SqlSessionFactoryBean">
        <!--指定数据源-->
        <property name="dataSource" ref="dataSource"/>
        <!--指定MyBatis核心配置文件的位置-->
        <property name="configLocation" value="classpath:mybatis/mybatis-config.xml"/>
    </bean>

    <!--4.告诉Spring容器，持久层操作的Mapper接口包结构位置，开始一个Mapper扫描-->
    <bean class="org.mybatis.spring.mapper.MapperScannerConfigurer">
        <property name="basePackage" value="com.cy.product.mapper"/>
    </bean>

    <!--5.将数据源管理指定的事物管理器-->

    <bean id="transactionManager" class="org.springframework.jdbc.datasource.DataSourceTransactionManager">
        <!--将当前的事物管理器作用到指定的数据源对象上-->
        <property name="dataSource" ref="dataSource"/>
    </bean>

    <!--6.开启事务-->
    <tx:annotation-driven/>
</beans>
```

> 报错1 tomcat-maven-plugin 2.2 找不到

```textile
先改错2.1，Lifestyle->clean->install 
不行就清除缓存 重启
不行就把本地仓库的org.apache.tomcat包删除
不行就把Maven镜像删除(备份一下settings.xml文件，以后用阿里仓库，在IDEA配置Maven(settings->Build->Build Tools
->Maven->修改setting.xml为备份的，即阿里镜像的)，删除就是直接用Maven官网的)
```

> 报错2 org.springframework.jdbc.datasource.DataSourceTransactionManager 找不到 导入依赖

```xml
  <dependency>
    <groupId>org.springframework</groupId>
    <artifactId>spring-jdbc</artifactId>
    <version>${spring.version}</version>
  <dependency/>
```

> 报错 3 <tx:annotation-driven/> 报错

默认给的是

```textile
xmlns:tx="http://www.springframework.org/schema/tool"
```

修改成下面的

```textile
xmlns:tx="http://www.springframework.org/schema/tx"
```

<br/>

3.配置前端控制器：DispatcherServlet处理请求(spring核心配置文件的位置、编码)

```xml
<!DOCTYPE web-app PUBLIC
 "-//Sun Microsystems, Inc.//DTD Web Application 2.3//EN"
 "http://java.sun.com/dtd/web-app_2_3.dtd" >

<web-app>
  <display-name>Archetype Created Web Application</display-name>
  <servlet>
    <servlet-name>springMVC</servlet-name>
    <servlet-class>org.springframework.web.servlet.DispatcherServlet</servlet-class>
    <!--在Servlet启动时，同时去加载Spring框架的核心文件-->
    <init-param>
      <param-name>contextConfigLocation</param-name>
      <param-value>classpath:spring/spring.xml</param-value>
    </init-param>
    <!--配置一个启动的顺序，第一个被启动的servlet-->
    <load-on-startup>1</load-on-startup>
  </servlet>
  <servlet-mapping>
    <servlet-name>springMVC</servlet-name>
    <!--"/"当前前端控制器可以处理所有请求-->
    <url-pattern>/</url-pattern>
  </servlet-mapping>
</web-app>

```

### 5.3.5 功能开发

**1.需求分析：**

1.模拟一个抢购功能

```textile
update from product set stock = stock - 1
```

2.某个用户下单成功

```textile
insert into `order` (id,pid,userid) values(?,?,?)
```

**2.创建pojo实体类：**

1.创建Product实体类

```java
/**
 * 商品表的实体类
 * */
@Data  //toString get set equals
public class Product implements Serializable {

    private int id;
    private String productName;
    private int stock;
    private int version;

}

```

2.创建Order实体类

```java
/**
 * 订单实体类
 * */
@Data
public class Order implements Serializable {

    private String id;
    private int pid;
    private int userid;

}

```

**3.Mapper层开发：**

1.创建ProductMapper接口

```java
@Mapper //通过MyBatis提供的代理类，实现接口
@Component //将该类对象交给spring框架管理
public interface ProductMapper {

    //1.查询查询该商品是否还有存库
    @Select("select * from product where id=#{id}")
    Product getProduct(@Param("id")int id);
    //2.减少商品存库数量的
    @Update("update product set stock stock-1 where id=#{id]")
    int reduceStock(@Param("id")int id);

}
```

2.创建OrderMapper接口

```java
@Mapper
@Component
public interface OrderMapper {

    //生成订单
    @Insert("insert into `order` (id,pid,userid) values ( #{id},#{pid},#{userid} )")
    int insert(Order order);

}
```

**4.service层开发**

1.创建一个ProductService接口

```java
public interface ProductService {

    void reduceStock(int id)throws Exception;

}
```

2.创建该接口的实现类ProductServiceImpl

```java
@Service
public class ProductServiceImpl implements ProductService {

    @Autowired
    private ProductMapper productMapper;
    @Autowired
    private OrderMapper orderMapper;

    public void reduceStock(int id) throws Exception {
        //1.获取秒杀商品的信息（获取到了当前商品的库存数量）
        Product product = productMapper.getProduct(id);//stock =0
        //2.判断当前的商品是否库存数小于等于0
        if (product.getStock() <= 0) {//该商品已被抢光
            throw new RuntimeException("该商品已被抢光！！！");
        }

        //3.执行商品秒杀操作（商品库存数量-1）
        int row = productMapper.reduceStock(id);
        if (row == 1) {//该用户抢到商品，商品的抢购信息新增订单表中
            Order order = new Order();
            order.setId(UUID.randomUUID().toString());
            order.setPid(id);
            order.setUserid(1001);
            orderMapper.insert(order);
        } else {
            throw new RuntimeException("当前排队人数过多，请稍后重试！");
        }
    }
}

```

**5.Controller层的开发**

创建一个类ProductController类，添加一个请求处理方法，根据商品的id执行商品秒杀抢购功能

```java
@RestController //@Controller + @Response 组合注解
public class ProductController {

    @Autowired
    private ProductService productService;
    @GetMapping("/product/reduce")
    public String reduceStock(int id)throws Exception {

        productService.reduceStock(id);
        return "success";

    }

}
```

**6.功能测试**

APIPost、Postmain等测试工具，来测试该接口的测试

1.将项目通过内嵌的Tomcati端口配置，来指定8001和8002端口，操作同一台数据，个时候就可能有请求的兵法问题。

2.使用ApiPosti测试工具，在指定的时间内容，发送多个请求，模拟出了请求并发。

3.数据的商品库存数据被抢购到小于0的数字，这个是和业务的场景符，需要通过手动来解决该问题。

### 5.3.6 Zookeeper解决并发问题

Curator是基于Zookeeper原生的客户端类实现的一个中分布式并发问题的解决依赖。

1.Curator引入依赖

```xml
<dependency>
<groupId>org.apache.curator</groupId>
<artifactId>curator-recipes</artifactId>
<!-一网友投票最牛版本-->
<version>4.2.0</version>
</dependency>
```

> 在该依赖性中包含Zookeeper的相关技术

2.在控制层来控制分布式锁的使用

```
 @GetMapping("/product/reduce")
    public String reduceStock(int id)throws Exception {

        //1.创建一个重试策略（重试三次，每次重试的时间间隔是1秒）
        /**
         * 参数一：表示每次重试的时间间隔
         * 参数二：表示重试多少次
         * */
        RetryPolicy retryPolicy = new ExponentialBackoffRetry(1000,3);
        CuratorFramework client = CuratorFrameworkFactory.newClient(connectionString,retryPolicy);

        //2.创建Curator对象（表示一个Zookeeper连接的工具对象）
        productService.reduceStock(id);
        return "success";

    }
        //3.开启客户端：表示连接上集群
        client.start();
        //4.根据client工具类创建一个"内部互斥锁"对象
        /*
         *参数1：表示目标客户端(client对象)
         *参数2：表示这个锁在集群中的节点名称（要求唯一）
         */
        InterProcessMutex lock =new InterProcessMutex(client,"/product_"+id);
        try{
        //5.开启锁（在目标方法指定之前开启锁）
            lock.acquire();
            productService.reduceStock(id);//并发了调用该方法
        }catch (Exception e){
            e.printStackTrace();
        }finally{
        //6.释放锁（目标方法被调用，无论是否产生异常，理论上都应该将锁释放掉）
            lock.release();
        }
        
         return "success";

    }
```

3.测试：在指定的时间内容，通过ApiPost发送并发的请求，通过访问8001和8002端口，发现分布式锁的作用就生效。

### Zookeeper总结
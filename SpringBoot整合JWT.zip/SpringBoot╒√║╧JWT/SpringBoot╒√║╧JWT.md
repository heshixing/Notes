## JWT教程

### 1 JWT概述

### 1.1什么是JWT

JSON Web Token,简称JWT。通过数字签名的方式，以JSON对象为载体，在不同的服务终端之间安全的传输信息.

### 1.2JWT有什么用

JWT通常用于Wb应用程序中的身份验证和授权目的。一旦用户登录，后续每个请求都将包含JJWT,系统在每次处理用户请求之前，都先进行JWT安全校验，通过之后再进行处理。

### 1.3JWT的组成

JWT由Header、Playload、Signature三部分组成，由 “ . ” 拼接。令牌最终的格式像这样：abc.def.yz。

**1.3.1 Header**

Header-标头。通常由两部分组成：令牌的类型(JWT)和所使用的签名算法（如HMAC、SHA256或RSA),经过Base64 Url编码后形成JWT的第一部分。

```json
{
  "type":"JWT",
  "alg":"HS256"
}
```

**1.3.2 Payload**

playload-有效负载。存放用户自定义的信息，通常会把用户信息和令牌到期时间放在这里，同样是一个JSON对象，里面的key和value可随意设置，经过Base64 Url编码后形成JWT的第二部分，由于部分是没有加密的，建议只存放一些非敏感信息。

```json
{
  "sub":"1234567890",
  "name":"john",
  "admin":true
}
```

**1.3.3 Signature**

Signature-签名。使用标头的算法和私钥对第一部分和第二部分进行加密，通过Base64 Url编码后形成JWT的第三部分。

```text
var encodestring = base64UrlEncode (header)+"."+base64Urlhcode(payload);
var signature    = HMACSHA256(encodeString,secret):
```

### 2 JWT使用

#### 2.1 JWT基本使用

1.使用IDEA创建一个Spring Initialize 类型的项目，名称为 SpringBoot_JWT（这里只使用Spring Web框架）。

2.在项目中导入JWT的依赖：

```xml
<dependency>
  <grouId>io.jsonwebtoken</groupId>
  <artifactId>jjwt</artifactId>
  <version>0.9.1</version>
</dependency>
```

jdk大于1.8还要导入下面的依赖：

```xml
<dependency>
    <groupId>javax.xml.bind</groupId>
    <artifactId>jaxb-api</artifactId>
    <version>2.3.1</version>
</dependency>
<dependency>
    <groupId>cn.lzgabel.jaxb.xml.bind</groupId>
    <artifactId>jaxb-impl</artifactId>
    <version>4.0.0</version>
</dependency>
<dependency>
    <groupId>com.sun.xml.bind</groupId>
    <artifactId>jaxb-core</artifactId>
    <version>3.0.2</version>
</dependency>
<dependency>
    <groupId>javax.activation</groupId>
    <artifactId>activation</artifactId>
    <version>1.1.1</version>
</dependency>
```

创建createJWT类，编写创建JWT的方法，代码如下：

```java
public class createJWT {

    private long time = 1000 * 6060 * 1;
    private String sign = "admin";

    @Test
    public void createJwt() {  //创建JWT
        //创建-个JwtBuilder对象

        JwtBuilder jwtBuilder = Jwts.builder();
        // jwtToken -> abc.def.xyz
        String jwtToken = jwtBuilder
                //Header:头部
                .setHeaderParam("typ", "JWT")
                .setHeaderParam("alg", "HS256")
                //Payload:载荷
                .claim("username", "tom")
                .claim("role", "admin")
                .setSubject("admin-test")
                .setExpiration(new Date(System.currentTimeMillis() + time))//Token的过期时间
                .setId(UUID.randomUUID().toString())//id字段
                //sign:签名
                .signWith(SignatureAlgorithm.HS256, sign)//设置加密算法和签名
                //使用”，“连接成一个完整的字符串
                .compact();
            System.out.println(jwtToken);

    }
}
```

输出结果如下：

```
eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9
.eyJ1c2VybmFtZSI6InRvbSIsInJvbGUiOiJhZG1pbiIsInN1YiI6ImFkbWluLXRlc3QiLCJleHAiOjE2ODg5MDI2ODUsImp0aSI6ImVjMmQ3MWU2LTY0MzgtNDg4NC05MzI5LTFmN2M2MmJmOWJhOCJ9
._8OvoM6koEBNgTvaO5gRmIVOgt6J67ZU3AvJvVQFMds
```

编写验证JWT的方法，代码如下：

```java
 //验证JWT
    @Test
    public void checkJwt() {
        String token = "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VybmFtZSI6InRvbSIsInJvbGUiOiJhZG1pbiIsInN1YiI6ImFkbWluLXRlc3QiLCJleHAiOjE2ODg5MDI2ODUsImp0aSI6ImVjMmQ3MWU2LTY0MzgtNDg4NC05MzI5LTFmN2M2MmJmOWJhOCJ9._8OvoM6koEBNgTvaO5gRmIVOgt6J67ZU3AvJvVQFMds";
        boolean result = Jwts.parser().isSigned(token);
        System.out.println(result);
    }
```

测试结果为 ： TRUE  ==》 这里方法检测的是 是不是JWT的语法出错 即 是不是 a+.b+.c的形式。

编写解析JWT方法，代码如下：

```java
 @Test
    //解析JWT
    public void parseJwt(){
        String token = "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VybmFtZSI6InRvbSIsInJvbGUiOiJhZG1pbiIsInN1YiI6ImFkbWluLXRlc3QiLCJleHAiOjE2ODg5MDI2ODUsImp0aSI6ImVjMmQ3MWU2LTY0MzgtNDg4NC05MzI5LTFmN2M2MmJmOWJhOCJ9._8OvoM6koEBNgTvaO5gRmIVOgt6J67ZU3AvJvVQFMds";
        JwtParser jwtParser=Jwts.parser();//获取JWT的解析对象
        //类似Map集合
        Jws <Claims> claimsJws = jwtParser.setSigningKey(sign).parseClaimsJws(token); //将JWT转化成一个Key-valve,通过key来获取对应的valve
        //获取Jws对象中的数据：get(key)表示根据key来获取value
        Claims claims=claimsJws.getBody();//存储的是用户保存的数据
        System.out.println(claims.get("username"));
        System.out.println(claims.get("role"));
        System.out.println(claims.getId());
        System.out.println(claims.getSubject());
        System.out.println(claims.getExpiration());
    }
```

测试结果如图：

![screen-capture](052c12156fc04d944aa62eae1fb4c2b3.png)

#### 2.2 SpringBoot+JWT编程实现

![screen-capture](71574b159caa971dfd2d2440deaa4ff5.png)

创建domain包，在该包下创建User实体类，代码如下：

```java
@Data
public class User implements Serializable {
    private String username;
    private String password;
    private String token;//token字符串
}
```

创建utils包，在该包下创建JWTUtil工具类，代码如下：

```java
/**
 * JWT工具类
 * */
public class JWTUtil {

    private static long time = 1000 * 60 * 60 * 1;
    private static String sign = "admin";

    public static String createJWT() {
        //创建-个JwtBuilder对象
        JwtBuilder jwtBuilder = Jwts.builder();
        // jwtToken -> abc.def.xyz
        String jwtToken = jwtBuilder
                //Header:头部
                .setHeaderParam("typ", "JWT")
                .setHeaderParam("alg", "HS256")
                //Payload:载荷
                .claim("username", "tom")
                .claim("role", "admin")
                .setSubject("admin-test")
                .setExpiration(new Date(System.currentTimeMillis() + time))//Token的过期时间
                .setId(UUID.randomUUID().toString())//id字段
                //sign:签名
                .signWith(SignatureAlgorithm.HS256, sign)//设置加密算法和签名
                //使用”，“连接成一个完整的字符串
                .compact();
        return jwtToken;
    }
}

```

创建controler包，在该包下创建UserController类，代码如下：

```java
@RestController
public class UserController {

    @GetMapping("login")
    public User login(User user) {
        String username = "tom";
        String password = "123456";
        if (username.equals(user.getUsername()) && password.equals(user.getPassword())) {
            //创建Token:token保存到user对象
            //T0D0
            user.setToken(JWTUtil.createJWT());
            return user;
        }
            return null;
    }
}
```

如果报错 ==》javax.xml.bind.DatatypeConverter

在pom.XML中，加入下面的依赖：

```xml
 <dependency>
    <groupId>javax.xml.bind</groupId>
    <artifactId>jaxb-api</artifactId>
    <version>2.3.1</version>
  </dependency>
```

测试该方法，结果如图所示：

![screen-capture](a8dd822bcb882be7740eb7e0d33dd1f6.png)

<br/>

***

模拟token过期:

1.把JWT的工具类(JWTUtil)的  time 值修改，代码如下：

```java
 private static long time = 1000 *15;
```

2.在JWTUtil类编写验证Token过期的方法，代码如下：

```java
//封装验证token是否过期的方法
    public static boolean checkToken(String token) {
        if (token == null || token == "") {
            return false;//false表示过期
        }
        try {
            Jws<Claims> claimsJws = Jwts.parser().setSigningKey(sign).parseClaimsJws(token);
        } catch (Exception e) {
            e.printStackTrace();
            return false;//false表示过期
        }
        return true;
    }
```

**在UserController类编写调用验证的方法（这种方法是前端通过  key=>value  形式给后端传Token），代码如下：**

```java
    @GetMapping("check_token")
    public boolean checkToken(String token){
        return JWTUtil.checkToken(token);
    }
```

测试Token是否过期：

- 先生成一个用户的Token：
  
  ![screen-capture](4f4e71d618cbe5dd7b7bd7b01b2959e7.png)
  
  <br/>
  - 复制该Token,等待15秒，测试下面的接口，显示false，则表示Token过期，即验证成功！
    
    ![screen-capture](05bea2fe953a24fab17c50506faabbe5.png)
    
    <br/>
    
    如果是在15秒之内发送该请求，则为TRUE。

![screen-capture](9df904e3af53949855b598c7e408961a.png)

**在UserController类编写调用验证的方法（ 这种方法是前端通过  请求头  形式给后端传Token），代码如下：**

```java
@GetMapping("check_token")
public boolean checkToken(HttpServletRequest request){
        String token request.getHeader("token");/key -token
        return JwtUtil.checkToken(token);
}
```

测试方法不变。

#### 2.3 跨域问题

创建config包，在该包下创建CorsConfig类，代码如下：

```java
@Configuration
public class CorsConfig implements WebMvcConfigurer {

    /**
     *  addMapping("/**“):配置可以被跨域的路径，可以任意配置，可以具体到直接请求路径
     *  alLowed0rigins("*")：允许所有的请求域名访问我们的跨域资源，可以固定单条或者多条内容，如http://www.yx.com",只有该域名可以访问我们的资源
     *  alLowedHeaders("*"):允许所有的请求header访问，可以自定义设置任意请求头信息
     *  alLowedMethods():允许所有的请求方法访问该跨域资源服务器，如GET、POST、DELETE、PUT、OPTIONS、HEAD等
     *  maxAge(3600)：配置客户端可以缓存pre-flight请求的响应的时间（秒）。默认设置为l800秒(30分钟)
     */
    @Override
    public void addCorsMappings(CorsRegistry registry) {
        registry.addMapping("/**")
                .allowedOrigins("*")
                .allowedHeaders("*")
                .allowedMethods("GET", "POST", "DELETE", "PUT", "OPTIONS", "HEAD")
                .maxAge(3600);

    }
}
```

#### 2.4 拦截器实现Token验证

创建intercepter包，在该包下创建TokenIncepter方法，代码如下：

```java
@Configuration
public class TokenIntercepter implements HandlerInterceptor {

    @Override   //在请求方法前被调用
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        String token = request.getParameter("token");
        if(! JWTUtil.checkToken(token) ){
            return false;
        }
        return true;
    }
}
```
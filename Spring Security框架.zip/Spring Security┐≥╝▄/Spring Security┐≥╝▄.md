# 整体框架

在<Spring Security>的架构设计中，认证<Authentication>和授权<Authorization:>是分开的，无论使用什么样的认证方式。都不会影响授权，这是两个独立的存在，这种独立带来的好处之一，就是可以非常方便地整合一些外部的解决方案。

![screen-capture](d541c0c4ca7a20f9931d7c667ad5ba2f.png)

## 认证

**AuthenticationManager：**

在Spring Seourity中认证是由AuthenticationManager接口来负责的，接口定义为：

```java
public interface AuthenticationManager{
       Authentication authenticate(Authentication authentication)
       throws AuthenticationException;
}
```

- 返回Authentication表示认证成功。
- 返回Authentication Exception异常，表示认证失败。

AuthenticationManager主要实现类为ProviderManager,.在ProviderManager中管理了众多AuthenticationProvider实例。在一次完整的认证流程中，Spring Security允许存在多个AuthenticationProvider,用来实现多种认证方式，这些AuthenticationProvider都是由ProviderManager进行统一管理的

**Authentication：**

认证以及认证成功的信息主要是由Authentication的实现类进行保存的，其接口定义为：

```java
接口Authentication
getAuthorities():Collection<?extends GrantedAuthority> //获取用户权限信息
getCredentials():Object  //获取用户凭证信息（密码等）
getDetails():Object  //获取用户详细
getPrincipal():Object  //获取用户身份（用户名，用户对象等）
isAuthenticated():boolean  //判断用户是否认证成功
setAuthenticated(boolean):void  //设置认证标记
```

**SecurityContextHolder：**

SecurityContextHolder用来获取登录之后用户宿息。Spring Security会将登录用户数据保存在Session中。但是，为了使用方便，Spring Security在此基础上还做了一些改进，其中最主要的一个变化就是线程绑定。当用户登录成功后，Spring Security会将登录成功的用户信息保存到SecurityContextHolder中。SecurityContextHolder中的数据保存默认是通过ThreadLocal来实现的，使用ThreadLocalf创建的变量只能被当前线程访问，不能被其他线程访问和修改，也就是用户数据和请求线程绑定在一起。当登录请求处理完毕后，Spring Security会将SecurityContextHolder中的数据拿出来保存到Session中，同时将SecurityContexHolder中的数据清空。以后每当有请求到来时，Spring Security就会先从Session中取出用户登录数据，保存到SecurityContextHolder中，方便在该请求的后续处理过程中使用，同时在请求结束时将SecurityContextHolder中的数据拿出来保存到Session中，然后将SecuritySecurityContextHolder中的数据清空。这一策略非常方便用户在Controller、Service层以及任何代码中获取当前登录用户数据。

## 授权

当完成认证后，接下米就是授权了。在Spring Security的授权体系中，有两个关键接口，
**AccessDecisionManager：**

> AccessDecisionManager(访问决策管理器)，用来决定此次访问是否被允许。

```java
接口AccessDecisionManager
decide(Authentication,Object,Collection<ConfigAttribute>):void
supports(Class<?>):boolean
supports(ConfigAttribute):boolean
```

AccessDecisionVote：

> AccessDecisionVoter(访问决定投票器)，投票器会检查用户是否具备应有的角色，进而投出赞成、反对或者弃权票。

```java
接口AccessDecisionVoter
supports(Class<?>):boolean
supports(ConfigAttribute):boolean
vote(Authentication,S,Collection<ConfigAttribute>):int
```

AveasDecisionVoter和AccessDecisionManager都有众多的实现类， 在AccessDecisionManager中会换个遍历AccessDecisionVoter,.进而决定是否允许用户访问，因而AaccesaccesDecisionVoter和AccessDecisionManager两者的关系类似于AuthenticationProvider和ProviderManager的关系。

**ConfigAttribute：**

> ConfigAttribute,用来保存授权时的角色信息

```java
接口ConfigAttribute
getAttribute():String
```

在Spring Security中，用户请求一个资源（通常是一个接口或者一个Java方法）需要的角色会被封装成一个ConfigAttribute对象，在ConfigAttribute中只有一个getAttribute方法，该方法返回一个String字符串，就是角色的名称。一般来说，角色名称都带有一个ROLE_前缀，投票器AccessDecisionVoter所做的事情，其实就是比较用户所具各的角色和请求某个咨酒所重的ConfigAt1ihta之间的关系

<br/>

**认证：判断用户是否是系统合法用户过程
授权：判断系统内用户可以访问或具有访问那些资源权限过程**

![screen-capture](8a44159abe60c5f51d1afab12d3098ea.png)

> SpringSecurity创建自己的过滤器，封装到DeleteGatingFilterProxy，
> 
> DeleteGatingFilterProxy把springSecurity封装到javaweb的Filter中

![screen-capture](e1467969bab11b85bedfbb1a73b0118b.png)

![screen-capture](57bc96ab0cbcac5bdc6368013cd12342.png)

需要注意的是，默认过滤器并不是直接放在Wb项目的原生过滤器链中，而是通过一个
FlterChainProxy来统一管理。Spring Security中的过滤器链通过FilterChainProxy嵌入到Web项目的原生过滤器链中。FilterChainProxy作为一个J顶层的管理者，将统一管理SecurityFilter。,FilterChainProxy本身是通过Spring框架提供的DelegatingFilterProxy整合到原生的过滤器链中。

## Security Filters

那么在Spring Security中给我们提供那些过滤器？默认情况下那些过滤器会被加载呢？

|过滤器|过滤器作用|默认加载|
|--|--|--|
|WebAsyncManagerIntegrationFilter|将WebAsyncManger与SpringSecurity上下文进行集成||
|SecurityContextPersistenceFilter|在处理请求之前，将安全信息加载到SecurityContextHolder中||
|HeaderWriterFilter|处理头消息加入响应||
|CsrfFilter|处理CSRF攻击||
|LogoutFilter|处理注销登录||
|UsernamePasswordAuthenticationFilter|处理表单登录||
|DefaultLoginPageGeneratingFilter|配置默认登陆页面||
|DefaultLogoutPageGeneratingFilter|配置默认注销页面||
|BasicAuthenticationFilter|处理HttpBasic登录||
|RequestCacheAwareFilter|处理请求缓存||
|SecurityContextHolder<br/>AwareRequestFilter|包装原始请求||
|AnonymousAuthenticationFilter|配置匿名认证||
|SessionManagementFilter|处理session并发问题||
|ExceptionTranslationFilter|处理认证/授权中的异常||
|FilterSecurityInterceptor|处理授权相关||

Spring Security提供了30多个过滤器。默认情况下Spring Boot在对SpringSecurity进入自动化配置时，会创建一个名为SpringSecurityFilerChain的过滤器，并注入到Spring容器中，这个过滤器将负责所有的安全管理，包括用户认证、授权、重定向到登录页面等。具体可以黪考WebSecurityConfiguration的源码：

![screen-capture](6dbbebfdb1722729717d08a2897b9b4d.png)

## SpringBootWebSecurityConfiguration

这个类是spring boot自动配置类，通过这个源码得知，默认情况下对所有请求进行权限控制：

```java
@Configuration(proxyBeanMethods false)
@ConditionalOnDefaultWebSecurity
@ConditionalOnWebApplication(type Type.SERVLET)
class SpringBootWebSecurityConfiguration
@Bean
@Order(SecurityProperties.BASIC_AUTH_ORDER)
SecurityFilterChain defaultSecurityFilterChain(HttpSecurity http)
throws Exception
```

> authorizeRequests对任何请求拦截

```java
http.authorizeRequests().anyRequest()
.authenticated().and().formLogin().and().httpBasic();
return http.build();
}
```

这就是为什么在引入Spring Security中没有任何配置情况下，请求会被拦截的原因

<br/>

> 分析@ConditionalOnDefaultWebSecurity注解

![screen-capture](89d6c97e3bb0808535d8feefcfa90a4b.png)

- @ConditionalOnClass 当类路径下有SecurityFilterChain.class和HttpSecurity.class文件时，执行方法。

- @ConditionalOnMissingBean 没有自定义实体类WebSecurityConfigureAdapter和SecurityFilterChain时，执行方法。

两个条件都满足，则@ConditionalOnDefaultWebSecurity注解生效

<br/>

> 1.分析WebSecurityConfigurerapter类（抽象类）

用来对Security的默认配置进行扩展，主要是通过继承他的Config方法（看绿字）

![screen-capture](b8f5b033893a99f580918b557d567bf5.png)

<br/>

> 2.分析SecurityFilterChain

用来扩展自定义Filter

![screen-capture](0004b07491bbd1498dcdf37c30a3f8c4.png)

## 流程分析

![screen-capture](7844dd3342dcd71308d534c678c0437a.png)

1.请求hello接口，在引入spring security之后会先经过一些列过滤器

2.在请求到达FilterSecuritylnterceptor时，发现请求并未认证。请求拦截下来，并抛出
AccessDenied Exception异常。

3.抛出AccessDenied Exception的异常会被ExceptionTranslationFilter捕获，这个Filter中会调用LoginUrlAuthenticationEntryPointa#commence方法给客户端返回302，要求客户端进行重定向到八ogin页面。

4.客户端发送/login请求。

5./login请求会再次被拦截器中DefaultLoginPageGeneratingFilter拦截到，并在拦截器中返回生成登录页面。

## 默认用户生成

l.查看SpringBootWebSecurityConfiguration类的defaultSecurityFilterChain方法，把用户名和密码封装成UsernamePasswordAuthejtication。

![screen-capture](dcf4339182c316b08f70b80401df9bef.png)

2.拦截UsernamePasswordAuthejtication，FormLoginConfigurer类中调用UsernamePasswordAuthenticationFilter这个类实例

![screen-capture](e8e2cdabcd3a43b370f84050e5a34403.png)

3.查看类中UsernamePasswordAuthenticationFilter类的attempAuthentication方法得知实际调用AuthenticationManager中authenticate方法

![screen-capture](858f2247adf50e67dedffee044f93b74.png)

4.在authenticate方法中调用ProviderManager类中方法authenticate

![screen-capture](cba496b7fac7cd871e542e7cb8eb988f.png)

5.调用了ProviderManager实现类中AbstractUserDetailsAuthenticationProvider类中的retrieveUser方法

![screen-capture](86555cf99f8c37a2320e8b88f8b58851.png)

6.最终调用实现类DaoAuthenticationProvider类中的getUserDetailsService方法

![screen-capture](4b8c8645b170a54a975e4a60956a3f92.png)

**看到这里就知道默认实现是基于InMemoryUserDetailsManager这个类，也就是内存的实现！**

**UserDetailService：**
通过刚才源码分析也能得知UserDetailService是J顶层父接口，接口中loadUserByUserName方法是用来在认证时进行用户名认证方法，默认实现使用是内存实现，如果想要修改数据库实现我们只需要自定义UserDetailService实现，最终返回UserDetails实例即可。

```java
public interface UserDetailsService{
UserDetails loadUserByUsername(String username)throws
UsernameNotFoundException
}
```

![screen-capture](7f97e32d2a4852a226ae2da9d896a6a9.png)

看到这里就知道默认实现是基于InMemoryUserDetailsManager这个类，也就是内存的实现！

**UserDetailServiceAutoConfigutation:**
这个源码非常多，这里梳理了关键部分：

![screen-capture](0cd80f0c25aa3b9ba8e5da179961ffef.png)

结论
l.从自动配置源码中得知当classpath下存在AuthenticationManager类
2.当前项目中，系统没有提供AuthenticationManager..class、
AuthenticationProvider.class UserDetailsService.class,
AuthenticationManagerResolver.class的实例，默认情况下都会满足，此时Spring Security会提供一个InMem的ryUserDetailManager实例

![screen-capture](83d75740f88c954fad1abbb1c857cb61.png)

```java
@ConfigurationProperties(prefix "spring.security")
public class SecurityProperties
private final Useruser new User();
public User getUser(){
return this.user;
}
public static class User
private String name "user";
private String password UUID.randomUUID().toString();
private List<String>roles new ArrayList<>();
private boolean passwordGenerated true;
//get set...
```

这就是默认生成user以及uuid密码过程！另外看明白源码之后，就知道只要在配置文件
加入如下配置可以对内存中用户和密码进行覆盖。
spring.security.user.name=root
spring.security.user.password=root

# 总结

AuthenticationManager、ProviderManger、.以及AuthenticationProvider关系

![screen-capture](b44b6ccfdc6a4ea9bb4c9d981a055f1e.png)

![screen-capture](af65e37f8d4226649ba5eb1e64e27122.png)

![screen-capture](c26f96b1ec0024ad8a7e8c81541c0608.png)

# 自定义认证

## 自定义资源权限规则

- /index公共资源
- /helo受保护资源

在项目中添加如下配置就可以实现对资源权限规则设定：

![screen-capture](ba8b4e7cd5318c51b041ed910d09fe82.png)

```java
@RestController
public class HelloController {
    @RequestMapping("hello")
    public String hello() {
        return "Spring Security";
    }
    
}

```

```java
@RestController
public class IndexController {

    @RequestMapping("index")
    public String hello() {
        return "Index Security";
    }

}
```

```java
@Controller
public class LoginController {

    @RequestMapping("/login.html")
    public String login() {
        return "login";
    }
}
```

<br/>

```properties
server.port=8080
spring.security.user.name=root
spring.security.user.password=root
spring.thymeleaf.cache=false
```

SpringBoot自动加前缀（Templates）、后缀（.html），所以不用配置

<br/>

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>用户登录</title>
</head>
<body>
<h1>用户登录</h1>
<form method="post" th:action="@{/doLogin}">
    用户名：<input name="username" type="text"><br>
    密码：<input name="password" type="text"><br>
    <input type="submit" value="登录">
</form>
</body>
</html>
```

<br/>

> WebSecurityConfigurer类

```java
@Configuration
public class WebSecurityConfigurer extends WebSecurityConfigurerAdapter {


    @Override
    protected void configure(HttpSecurity http) throws Exception {

        http.authorizeRequests()  //开启权限管理
                .mvcMatchers("/login.html").permitAll()
                .mvcMatchers("/index") //匹配请求
                .permitAll() //放行index的所有请求
                .anyRequest() //其余所有请求
                .authenticated()//进行认证
                .and().formLogin() //具体认证方式 ==》 表单认证
                .loginPage("/login.html")//  指定登陆验证页面  一旦自定义登录页面以后必须指定登录URL
                .loginProcessingUrl("/doLogin")//指定处理登录请求Url
                //.usernameParameter("uname")  自定义name属性
                //.passwordParameter("passwd")
                //.successForwardUrl("/hello") //认证成功 forward跳转 地址栏不变
                //.defaultSuccessUrl("/hello", true)//默认认证成功 redirect 跳转 地址栏变 根据上一保存请求进行成功跳转
                .successHandler(new MyAuthenticationSuccessHandler()) ////认证成功时处理前后端分离解决方案
                .and().csrf().disable()//防止csrf跨站请求保护
        ;

    }
}
```

> MyAuthenticationSuccessHandler实现AuthenticationSuccessHandler接口，重写onAuthenticationSuccess方法

```java
/**
 * 自定义认证成功之后的处理
 */
public class MyAuthenticationSuccessHandler implements AuthenticationSuccessHandler {


    @Override
    public void onAuthenticationSuccess(HttpServletRequest request, HttpServletResponse response, Authentication authentication) throws IOException, ServletException {
        Map<String, Object> result = new HashMap<>();
        result.put("msg", "登录成功");
        result.put("status", 200);
        result.put("authentication", authentication);
        response.setContentType("application/json;charset=UTF-8");
        String s = new ObjectMapper().writeValueAsString(result);
        response.getWriter().println(s);
    }
}
```

> localhost:8080/login.html,输入root root

```json
{
    "msg": "登录成功",
    "status": 200,
    "authentication": {
        "authorities": [],
        "details": {
            "remoteAddress": "0:0:0:0:0:0:0:1",
            "sessionId": null
        },
        "authenticated": true,
        "principal": {
            "password": null,
            "username": "root",
            "authorities": [],
            "accountNonExpired": true,
            "accountNonLocked": true,
            "credentialsNonExpired": true,
            "enabled": true
        },
        "credentials": null,
        "name": "root"
    }
}
```

<br/>

# 显示登录失败信息

为了能更直观在登录页面看到异常错误信息，可以在登录页面中直接获取异常信息。SpringSecurity在登录失败之后会将异常信息存储到request、session作用域中key为SPRING._SECURITY._LAST_EXCEPTION命名属性中，源码可以参考SimpleUrlAuthenticationFailureHandler

> WebSecurityConfigurer类

```java
@Configuration
public class WebSecurityConfigurer extends WebSecurityConfigurerAdapter {


    @Override
    protected void configure(HttpSecurity http) throws Exception {

        http.authorizeRequests()  //开启权限管理
                .mvcMatchers("/login.html").permitAll()
                .mvcMatchers("/index") //匹配请求
                .permitAll() //放行index的所有请求
                .anyRequest() //其余所有请求
                .authenticated()//进行认证
                .and().formLogin() //具体认证方式 ==》 表单认证
                .loginPage("/login.html")//  指定登陆验证页面  一旦自定义登录页面以后必须指定登录URL
                .loginProcessingUrl("/doLogin")//指定处理登录请求Url
                //.usernameParameter("uname")  自定义name属性
                //.passwordParameter("passwd")
                //.successForwardUrl("/hello") //认证成功 forward跳转 地址栏不变
                //.defaultSuccessUrl("/hello", true)//默认认证成功 redirect 跳转 地址栏变 根据上一保存请求进行成功跳转
                .successHandler(new MyAuthenticationSuccessHandler()) ////认证成功时处理前后端分离解决方案
                .failureForwardUrl("/login.html")//认证失败之后forward跳转
                //.failureUrl("/login.htmL")//认证失败之后redirect跳转
                .and().csrf().disable()//防止csrf跨站请求保护
        ;

    }
}
```

> login.html

```html
</head>
<body>
<h1>用户登录</h1>
<h2>
    <div th:text="${SPRING_SECURITY_LAST_EXCEPTION}"></div>
</h2>
<form method="post" th:action="@{/doLogin}">
    用户名：<input name="username" type="text"><br>
    密码：<input name="password" type="text"><br>
    <input type="submit" value="登录">
</form>
</body>
</html>

failureForwardUrl==》存储在request中，request可以不写
```

> 结果

![screen-capture](5784d39f44c20662439decb51f68de59.png)

> WebSecurityConfigurer类

```java
@Configuration
public class WebSecurityConfigurer extends WebSecurityConfigurerAdapter {


    @Override
    protected void configure(HttpSecurity http) throws Exception {

        http.authorizeRequests()  //开启权限管理
                .mvcMatchers("/login.html").permitAll()
                .mvcMatchers("/index") //匹配请求
                .permitAll() //放行index的所有请求
                .anyRequest() //其余所有请求
                .authenticated()//进行认证
                .and().formLogin() //具体认证方式 ==》 表单认证
                .loginPage("/login.html")//  指定登陆验证页面  一旦自定义登录页面以后必须指定登录URL
                .loginProcessingUrl("/doLogin")//指定处理登录请求Url
                //.usernameParameter("uname")  自定义name属性
                //.passwordParameter("passwd")
                //.successForwardUrl("/hello") //认证成功 forward跳转 地址栏不变
                //.defaultSuccessUrl("/hello", true)//默认认证成功 redirect 跳转 地址栏变 根据上一保存请求进行成功跳转
                .successHandler(new MyAuthenticationSuccessHandler()) ////认证成功时处理前后端分离解决方案
                //.failureForwardUrl("/login.html")//认证失败之后forward跳转
                .failureUrl("/login.htmL")//认证失败之后redirect跳转
                .and().csrf().disable()//防止csrf跨站请求保护
        ;

    }
}
```

> login.html

```html
</head>
<body>
<h1>用户登录</h1>
<h2>
    <div th:text="${session.SPRING_SECURITY_LAST_EXCEPTION}"></div>
</h2>
<form method="post" th:action="@{/doLogin}">
    用户名：<input name="username" type="text"><br>
    密码：<input name="password" type="text"><br>
    <input type="submit" value="登录">
</form>
</body>
</html>

failureUrl==》存储在session中
```

> 结果

![screen-capture](aa7cd1e7bc97328f98894b3db639339a.png)

# 显示登录失败处理

> WebSecurityConfigurer类

```java
@Configuration
public class WebSecurityConfigurer extends WebSecurityConfigurerAdapter {


    @Override
    protected void configure(HttpSecurity http) throws Exception {

        http.authorizeRequests()  //开启权限管理
                .mvcMatchers("/login.html").permitAll()
                .mvcMatchers("/index") //匹配请求
                .permitAll() //放行index的所有请求
                .anyRequest() //其余所有请求
                .authenticated()//进行认证
                .and().formLogin() //具体认证方式 ==》 表单认证
                .loginPage("/login.html")//  指定登陆验证页面  一旦自定义登录页面以后必须指定登录URL
                .loginProcessingUrl("/doLogin")//指定处理登录请求Url
                //.usernameParameter("uname")  自定义name属性
                //.passwordParameter("passwd")
                //.successForwardUrl("/hello") //认证成功 forward跳转 地址栏不变
                //.defaultSuccessUrl("/hello", true)//默认认证成功 redirect 跳转 地址栏变 根据上一保存请求进行成功跳转
                .successHandler(new MyAuthenticationSuccessHandler()) ////认证成功时处理前后端分离解决方案
                //.failureForwardUrl("/login.html")//认证失败之后forward跳转
                //.failureUrl("/login.htmL")//认证失败之后redirect跳转
                .failureHandler(new MyAuthenticationFailureHandler()) //用来自定义认证失败之后处理  前后端分离解决方案
                .and().csrf().disable()//防止csrf跨站请求保护
        ;

    }
}

```

> 结果

![screen-capture](ba1cdd4432bf0ac3d30bf7cd460fd5c9.png)

<br/>

failureUrl、failureForwardUrl关系类似于之前提到的successForwaru、defaultSuccessUrl方法

- failureUrl : 失败以后的**重定向**跳转,存储在**session**作用域
- failureForwardUrl : 失败以后的**forward**跳转，注意：因此获取**request**中异常信息，


# 注销登录

Spring Security中也提供了默认的注销登录配置，在开发时也可以按照自己需求对注销进行个性化定制。

- 开启注销登录，默认开启。访问localhost:8080/login.html

![screen-capture](30e3a19d34b37728305316897534d734.png)

访问localhost:8080/logout

![screen-capture](446cc2481d927f8f5bbb3115559ac486.png)

访问localhost:8080/hello

![screen-capture](0ec908104447670f9ebde75ca3390d1c.png)

代表确实退出了

# 自定义注销登录

> WebSecurityConfigurer类

```java
@Configuration
public class WebSecurityConfigurer extends WebSecurityConfigurerAdapter {


    @Override
    protected void configure(HttpSecurity http) throws Exception {

        http.authorizeRequests()  //开启权限管理
                .mvcMatchers("/login.html").permitAll()
                .mvcMatchers("/index") //匹配请求
                .permitAll() //放行index的所有请求
                .anyRequest() //其余所有请求
                .authenticated()//进行认证
                .and().formLogin() //具体认证方式 ==》 表单认证
                .loginPage("/login.html")//  指定登陆验证页面  一旦自定义登录页面以后必须指定登录URL
                .loginProcessingUrl("/doLogin")//指定处理登录请求Url
                //.usernameParameter("uname")  自定义name属性
                //.passwordParameter("passwd")
                //.successForwardUrl("/hello") //认证成功 forward跳转 地址栏不变
                //.defaultSuccessUrl("/hello", true)//默认认证成功 redirect 跳转 地址栏变 根据上一保存请求进行成功跳转
                .successHandler(new MyAuthenticationSuccessHandler()) ////认证成功时处理前后端分离解决方案
                //.failureForwardUrl("/login.html")//认证失败之后forward跳转
                //.failureUrl("/login.htmL")//认证失败之后redirect跳转
                .failureHandler(new MyAuthenticationFailureHandler()) //用来自定义认证失败之后处理  前后端分离解决方案
                .and().logout() //拿到注销登录的配置对象
                //.logoutUrl("/logout") //指定注销登录的Url 默认请求方式为 get
                .logoutRequestMatcher(new OrRequestMatcher(     //自定义注销方式
                        new AntPathRequestMatcher("/aa", "GET"),
                        new AntPathRequestMatcher("/bb", "POST")
                ))
                .invalidateHttpSession(true) //退出时是否是session失效，默认值为true
                .clearAuthentication(true) //退出时是否清除认证信息，默认值为true
                .logoutSuccessUrl("/login.html") //注销成功的跳转页面
                .and().csrf().disable()//防止csrf跨站请求保护
        ;

    }
}

```

> LogoutController类

```java
@Controller
public class LogoutController {

    @RequestMapping("/log")
    public String logout() {
        return "logout";
    }

}
```

> logout.html

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>注销登录</title>
</head>
<body>
<h1>注销登录</h1>
<form method="post" th:action="@{/bb}">
    <input type="submit" value="注销">
</form>
</body>
</html>
```

输入localhost:8080/login.html=>hello=>bb  ==>测试POST

	   localhost:8080/login.html=>aa ==>测试GET

<br/>

## 前后端分离注销登录配置

如果是前后端分离开发，注销成功之后就不需要页面跳转了，只需要将注销成功的信息
返回前端即可，此时我们可以通过自定义LogoutSuccessHandler实现来返回内容注销之
后信息：

> MyLogoutSuccessHandler

```java
/**
 * 自定义注销成功的处理
 */
public class MyLogoutSuccessHandler implements LogoutSuccessHandler {

    @Override
    public void onLogoutSuccess(HttpServletRequest request, HttpServletResponse response, Authentication authentication) throws IOException, ServletException {
        Map<String, Object> result = new HashMap<String, Object>();
        result.put("msg", "注销成功，当前认证对象为：" + authentication);
        result.put("status", 200);
        response.setContentType("application/json;charset=UTF-8");
        String s = new ObjectMapper().writeValueAsString(result);
        response.getWriter().println(s);
    }

}
```

> WebSecurityConfigurer类

```java
@Configuration
public class WebSecurityConfigurer extends WebSecurityConfigurerAdapter {


    @Override
    protected void configure(HttpSecurity http) throws Exception {

        http.authorizeRequests()  //开启权限管理
                .mvcMatchers("/login.html").permitAll()
                .mvcMatchers("/index") //匹配请求
                .permitAll() //放行index的所有请求
                .anyRequest() //其余所有请求
                .authenticated()//进行认证
                .and().formLogin() //具体认证方式 ==》 表单认证
                .loginPage("/login.html")//  指定登陆验证页面  一旦自定义登录页面以后必须指定登录URL
                .loginProcessingUrl("/doLogin")//指定处理登录请求Url
                //.usernameParameter("uname")  自定义name属性
                //.passwordParameter("passwd")
                //.successForwardUrl("/hello") //认证成功 forward跳转 地址栏不变
                //.defaultSuccessUrl("/hello", true)//默认认证成功 redirect 跳转 地址栏变 根据上一保存请求进行成功跳转
                .successHandler(new MyAuthenticationSuccessHandler()) ////认证成功时处理前后端分离解决方案
                //.failureForwardUrl("/login.html")//认证失败之后forward跳转
                //.failureUrl("/login.htmL")//认证失败之后redirect跳转
                .failureHandler(new MyAuthenticationFailureHandler()) //用来自定义认证失败之后处理  前后端分离解决方案
                .and().logout() //拿到注销登录的配置对象
                //.logoutUrl("/logout") //指定注销登录的Url 默认请求方式为 get
                .logoutRequestMatcher(new OrRequestMatcher(     //自定义注销方式
                        new AntPathRequestMatcher("/aa", "GET"),
                        new AntPathRequestMatcher("/bb", "POST")
                ))
                .invalidateHttpSession(true) //退出时是否是session失效，默认值为true
                .clearAuthentication(true) //退出时是否清除认证信息，默认值为true
                //.logoutSuccessUrl("/login.html") //注销成功的跳转页面
                .logoutSuccessHandler(new MyLogoutSuccessHandler()) //注销成功之后的处理
                .and().csrf().disable()//防止csrf跨站请求保护
        ;

    }
}

```

localhost:8080/login.html=>/aa

```json
{
    "msg": "注销成功，当前认证对象为：UsernamePasswordAuthenticationToken 
    [Principal=org.springframework.security.core.userdetails
    .User [Username=root, Password=[PROTECTED], Enabled=true,
    AccountNonExpired=true, credentialsNonExpired=true,
    AccountNonLocked=true, Granted Authorities=[]], 
    Credentials=[PROTECTED], Authenticated=true,
    Details=WebAuthenticationDetails 
    [RemoteIpAddress=0:0:0:0:0:0:0:1, SessionId=null], Granted Authorities=[]]",
    "status": 200
}
```

# 登陆数据获取

### SecurityContextHolder

Spring Security会将登录用户数据保存在Session中。但是，为了使用方便，Spring Security在此基础上还做了一些改进，其中最主要的一个变化就是线程绑定。当用户登录成功
后，Spring Security会将登录成功的用户信息保存到SecurityContextHolder中。

SecurityContextHolder中的数据保存默认是通过ThreadLocal来实现的，使用ThreadLocal创建的变量只能被当前线程访问，不能被其他线程访问和修改，也就是用户数据和请求线程绑定在一起。当登录请求处理完毕后，Spring Security会将SecurityContextHolder中的数据拿出来保存到Session中，同时将SecurityContexHolder中的数据清空。以后每当有请求到来时，Spring Security就会先从Session中取出用户登录数据，保存到SecurityContextHolder中，方便在该请求的后续处理过程中使用，同时在请求结束时将SecurityContextHolder中的数据拿出来保存到Session中，然后将Security SecurityContextHolder中的数据清空。

实际上SecurityContextHolder中存储是SecurityContext,.在SecurityContext中存储是
Authentication。

![screen-capture](636e3c1c23d0d34e2b3be52caddf1451.png)

这种设计是典型的策略设计模式：

![screen-capture](c0fa8307dad20900a37d6fcf827f1b6f.png)

![screen-capture](901743be9f12af14bdcd2bf887fb4f3d.png)

<br/>

### SecurityContextHolderStrategy

通过SecurityContextHolder可以得知，SecurityContextHolderStrategy接口用来定义存储策略方法

```java
public interface SecurityContextHolderStrategy{
    void clearContext();
    SecurityContext getContext();
    void setContext(SecurityContext context);
    SecurityContext createEmptyContext();
}
```

接口中一共定义了四个方法：

- clearContext·久万法用米肓标仔诸的SecurityContext对家。
- getContext：该方法用来获取存储的SecurityContext对象。
- setContext：该方法用来设置存储的SecurityContext对像。
- create Empty Context:该方法则用来创建一个空的SecurityContext对象。

#### 代码中获取认证之后用户数据

```java
@RestController
public class HelloController {
    @RequestMapping("hello")
    public String hello() {
        //1.获取认证信息
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        User user = (User) authentication.getPrincipal();
        System.out.println("身份信息" + user.getUsername());
        System.out.println("权限信息" + authentication.getAuthorities());
        return "Spring Security";
    }

}

```

localhost:8080/login.html=>/hello，控制台输出如下

```text
身份信息root
权限信息[ROLE_admin, ROLE_supper]
```

多线程情况下获取用户数据:

```java
@RestController
public class HelloController {
    @RequestMapping("hello")
    public String hello() {
        //1.获取认证信息
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        User user = (User) authentication.getPrincipal();
        System.out.println("身份信息" + user.getUsername());
        System.out.println("权限信息" + authentication.getAuthorities());
        new Thread(()->{
                Authentication authentication1 = SecurityContextHolder.getContext().getAuthentication();
        System.out.println("子线程获取："+authentication1);
        }).start();
        return "Spring Security";
    }

}
```

localhost:8080/login.html=>/hello，控制台输出如下

```
身份信息root
权限信息[ROLE_admin, ROLE_supper]
子线程获取：null
```

因为默认是将SecurityContext存放在ThreadLocal中，不支持多线程。解决办法：

![screen-capture](bf8d4cd206143327da433dd7e1aa26f5.png)

localhost:8080/login.html=>/hello，控制台输出如下

```text
身份信息root
权限信息[ROLE_admin, ROLE_supper]
子线程获取：UsernamePasswordAuthenticationToken [Principal=org.springframework.security.core.userdetails.User [Username=root, Password=[PROTECTED], Enabled=true, AccountNonExpired=true, credentialsNonExpired=true, AccountNonLocked=true, Granted Authorities=[ROLE_admin, ROLE_supper]], Credentials=[PROTECTED], Authenticated=true, Details=WebAuthenticationDetails [RemoteIpAddress=0:0:0:0:0:0:0:1, SessionId=null], Granted Authorities=[ROLE_admin, ROLE_supper]]
```

## 页面上获取用户信息

![screen-capture](fcef8a60e42e3460086da8ef53b87554.png)

![screen-capture](46de31fd78094393b66961be56f3f891.png)

# 自定义认证数据源

#### 认证流程分析

![screen-capture](538f0b4035413313e56c88545e9fa36c.png)

<br/>

- 发起认证请求，请求中携带用户名、密码，该请求会被UsernamePasswordAuthenticationFilter拦截
- 在UsernamePasswordAuthenticationFilter的attemptAuthentication方法中将请求中用户名和密码，封装为Authentication对象，并交给AuthenticationManager进行认证
- 认证成功，将认证信息存储到SecurityContextHodler以及调用记住我等，并回调AuthenticationSuccessHandler处理
- 认证失败，请除SecurityContextHodler以及记住我中信息，回调AuthenticationFailureHandler处理

## 三者关系

从上面分析中得知，AuthenticationManager是认证的核心类，但实际上在底层真正认证时还离不开ProviderManager以及AuthenticationProvider。他们三者关系是样的呢？

- AuthenticationManager是一个认证管理器，它定义了Spring Security过滤器要执行认证操作。
- ProviderManager是AuthenticationManager接口的实现类。Spring Security认证时默认使用就是ProviderManager。
- AuthenticationProvider就是针对不同的身份类型执行的具体的身份认证。

#### AuthenticationManager与ProviderManager

![screen-capture](9ffe72558c95d8a7a7fa1695ca622c4a.png)

ProviderManager是AuthenticationManager的唯一实现，也是Spring Security默认使用实现。从这里不难看出，默认情况下AuthenticationManager就是一个ProviderManager。

#### ProviderManager与AuthenticationProvider

![screen-capture](826ce44cf20bb58fa507ffe54bebedca.png)

在Spring Seourity中，允许系统同时支持多种不同的认证方式，例如同时支持用户名/密
码认证、ReremberMe认证、手机号码动态认证等，而不同的认证方式对应了不同的AuthenticationProvider,.所以一个完整的认证流程可能由多个AuthenticationProvider来提
供。

多个AuthenticationProvider将组成一个列表，这个列表将由ProviderManager代理。换句话说，在ProviderManager中存在一个AuthenticationProvider列表，在Provider Manager中遍历列表中的每一个AuthenticationProvider去执行身份认证，最终得到认证结果。

**ProviderManager本身也可以再配置一个AuthenticationManager作为parent,这样当ProviderManager认证失败之后，就可以进入到parent中再次进行认证。**理论上来说，ProviderManager的parent可以是任意类型的AuthenticationManager,但是通常都是由ProviderManager来扮演parent的角色，也就是ProviderManager是ProviderManager的
parent。

ProviderManager本身也可以有多个，多个ProviderManager共用同一个parent。有时，一个应用程序有受保护资源的逻辑组（例如，***所有符合路径模式的网络资源，如/api/*)，每个组可以有自己的专用AuthenticationManager。.通常，每个组都是一个ProviderManager,它们共享一个父级。然后，父级是一种全局资源，作为所有提供者的后备资源**。

根据上面的介绍，我们绘出新的AuthenticationManager、.ProvideManager和AuthentictionProvider关系

![screen-capture](587e28a82314ed735c8f297fb8e43aeb.png)

弄清楚认证原理之后我们来看下具体认证时数据源的获取。**默认情况下AuthenticationProvider是由DaoAuthenticationProvider类来实现认证的**，**在DaoAuthenticationProvider认证时又通过UserDetailsService完成数据源的校验**。

**总结：AuthenticationManager是认证管理器，在Spring Security中有全局
AuthenticationManager,.也可以有局部AuthenticationManager。全局的
AuthenticationManagerF用来对全局认证进行处理，局部的AuthenticationManager用来对某些特殊资源认证处理。当然无论是全局认证管理器还是局部认证管理器都是由
ProviderManger进行实现。每一个ProviderManger中都代理一个AuthenticationProvider的列表，列表中每一个实现代表一种身份认证方式。认证时底层数据源需要调用
UserDetailService来实现。**

## 配置全局AuthenticationManager

- 默认的全局AuthenticationManager

```java
@Configuration
public class WebSecurityConfigurer extends WebSecurityConfigurerAdapter{
  @Autowired
  public void initialize(AuthenticationManagerBuilder builder){
  //builder..
  }
}
```

> springboot对security进行自动配置时自动在工厂中创建一个全局
Authentication Manager

**总结**

1. 默认自动配置创建全局AuthenticationManager默认找当前项目中是否存在自定义
UserDetailService实例自动将当前项目UserDetailService实例设置为数据源

2. 默认自动配置创建全局AuthenticationManager在工厂中使用时直接在代码中注入即
可

自定义全局AuthenticationManager

```java
@Configuration
public class WebSecurityConfigurer extends WebSecurityConfigurerAdapter{
  @Override
  public void configure(AuthenticationManagerBuilder builder){
  //builder ...
}
```

**总结**
1.一旦通过configure方法自定义AuthenticationManager?实现就回将工厂中自动配置
AuthenticationManager进行覆盖
2.一旦通过configure方法自定义AuthenticationManager3实现需要在实现中指定认证
数据源对象UserDetaiService实例
3.一旦通过configure方法自定义AuthenticationManager3实现这种方式创建
AuthenticationManager>对象工厂内部本地一个AuthenticationManager对象不允许在其他自定义组件中进行注入

- 用来在工厂中暴露自定义AuthenticationManager实例

> WebSecurityConfigurer类

```java
@Configuration
public class WebSecurityConfigurer extends WebSecurityConfigurerAdapter {

    @Bean
    public UserDetailsService userDetailsService() {
        InMemoryUserDetailsManager userDetailsService = new InMemoryUserDetailsManager();
        userDetailsService.createUser(User.withUsername("aaa").password("{noop}123").roles("admin").build());
        return userDetailsService;
    }

    /**
     * //springboot对security默认配置中在工厂中默认创建AuthenticationManager
     *
     * @Autowired public void initialize(AuthenticationManagerBuilder builder) {
     * System.out.println("springboot默认配置：" + builder);
     * <p>
     * }
     */

    //自定义AuthenticationManager 推荐 并没有在工厂中暴露出来
    @Override
    protected void configure(AuthenticationManagerBuilder auth) throws Exception {
        System.out.println("自定义AuthenticationManager" + auth);
        auth.userDetailsService(userDetailsService());
    }

    //作用：用来将自定义AuthenticationManager在工厂中进行暴露，可以在任何位置注入
    @Override
    @Bean
    public AuthenticationManager authenticationManagerBean() throws Exception {
        return super.authenticationManagerBean();
    }

    @Override
    protected void configure(HttpSecurity http) throws Exception {

        http.authorizeRequests()  //开启权限管理
                .mvcMatchers("/login.html").permitAll()
                .mvcMatchers("/index") //匹配请求
                .permitAll() //放行index的所有请求
                .anyRequest() //其余所有请求
                .authenticated()//进行认证
                .and().formLogin() //具体认证方式 ==》 表单认证
                .loginPage("/login.html")//  指定登陆验证页面  一旦自定义登录页面以后必须指定登录URL
                .loginProcessingUrl("/doLogin")//指定处理登录请求Url
                //.usernameParameter("uname")  自定义name属性
                //.passwordParameter("passwd")
                //.successForwardUrl("/hello") //认证成功 forward跳转 地址栏不变
                //.defaultSuccessUrl("/hello", true)//默认认证成功 redirect 跳转 地址栏变 根据上一保存请求进行成功跳转
                .successHandler(new MyAuthenticationSuccessHandler()) ////认证成功时处理前后端分离解决方案
                //.failureForwardUrl("/login.html")//认证失败之后forward跳转
                //.failureUrl("/login.htmL")//认证失败之后redirect跳转
                .failureHandler(new MyAuthenticationFailureHandler()) //用来自定义认证失败之后处理  前后端分离解决方案
                .and().logout() //拿到注销登录的配置对象
                //.logoutUrl("/logout") //指定注销登录的Url 默认请求方式为 get
                .logoutRequestMatcher(new OrRequestMatcher(     //自定义注销方式
                        new AntPathRequestMatcher("/aa", "GET"),
                        new AntPathRequestMatcher("/bb", "POST")
                ))
                .invalidateHttpSession(true) //退出时是否是session失效，默认值为true
                .clearAuthentication(true) //退出时是否清除认证信息，默认值为true
                //.logoutSuccessUrl("/login.html") //注销成功的跳转页面
                .logoutSuccessHandler(new MyLogoutSuccessHandler()) //注销成功之后的处理
                .and().csrf().disable()//防止csrf跨站请求保护
        ;

    }
}
```

> HelloController类

```java
@RestController
public class HelloController {

    @Autowired
    private AuthenticationManager authenticationManager;

    @RequestMapping("hello")
    public String hello() {

        //1.获取认证信息
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        User user = (User) authentication.getPrincipal();
        System.out.println("身份信息" + user.getUsername());
        System.out.println("权限信息" + authentication.getAuthorities());
        new Thread(() -> {
            Authentication authentication1 = SecurityContextHolder.getContext().getAuthentication();
            System.out.println("子线程获取：" + authentication1);
        }).start();
        return "Spring Security";
    }

}
```

> 运行主类

```text
自定义AuthenticationManagerorg.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter$2@31ee96f4
```

## 自定义数据库数据源

> SQL语句

```mysql
create database security;
#用户表
CREATE TABLE user
( id int(11)NOT NULL AUTO_INCREMENT,
username varchar(32)DEFAULT NULL,
password varchar(255)DEFAULT NULL,
enabled  tinyint(1)DEFAULT NULL,
accountNonExpired tinyint(1) DEFAULT NULL,
accountNonLocked  tinyint(1) DEFAULT NULL,
credentialsNonExpired tinyint(1) DEFAULT NULL,
PRIMARY KEY (id)
)ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
#角色表
CREATE TABLE role(
id int(11)NOT NULL AUTO_INCREMENT,
name varchar(32) DEFAULT NULL,
name_zh varchar(32) DEFAULT NULL,
PRIMARY KEY (id)
)ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
#用户角色关系表
CREATE TABLE user_role
( id int(11)NOT NULL AUTO_INCREMENT,
  uid int(11)DEFAULT NULL,
  rid int(11)DEFAULT NULL,
PRIMARY KEY (id),
KEY uid(uid),
KEY rid(rid)
)ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

#插入用户数据
BEGIN;
INSERT INTO user
VALUES(1,'root','{noop}123',1,1,1,1);
INSERT INTO user
VALUES(2,'admin','{noop}123',1,1,1,1);
INSERT INTO user
VALUES(3,'b1r','{noop}123',1,1,1,1);
COMMIT;
#插入角色数据
BEGIN;
INSERT INTO role
VALUES(1,'ROLE_product','商品管理员');
INSERT INTO role
VALUES(2,'ROLE_admin','系统管理员');
INSERT INTO role
VALUES
(3,'R0LE_-user','用户管理员');
COMMIT;
#插入用户角色数据
BEGIN;
INSERT INTO user_role
VALUES (1,1,1);
INSERT INTO user_role
VALUES (2,1,2);
INSERT INTO user_role
VALUES (3,2,2);
INSERT INTO user_role
VALUES (4,3,3);
COMMIT;
```

> 引入依赖

```xml
  <!--druid-->
        <dependency>
            <groupId>com.alibaba</groupId>
            <artifactId>druid</artifactId>
            <version>1.1.20</version>
        </dependency>
        <!--mysql-->
        <dependency>
            <groupId>mysql</groupId>
            <artifactId>mysql-connector-java</artifactId>
            <version>8.0.20</version>
        </dependency>
        <!--mybatis-springboot-->
        <dependency>
            <groupId>org.mybatis.spring.boot</groupId>
            <artifactId>mybatis-spring-boot-starter</artifactId>
            <version>2.2.2</version>
        </dependency>
```

> 配置Spring文件

```properties
# 应用服务 WEB 访问端口
server.port=8080
spring.security.user.name=root
spring.security.user.password=root
spring.security.user.roles=admin,supper
spring.thymeleaf.cache=false
#datasource
spring.datasource.type=com.alibaba.druid.pool.DruidDataSource
spring.datasource.driver-class-name=com.mysql.cj.jdbc.Driver
spring.datasource.url=jdbc:mysql://localhost:3306/security?useUnicode=true&characterEncoding=UTF-8&serverTimezone=UTC
spring.datasource.username=root
spring.datasource.password=hsxsdm
#mybatis
mybatis.mapper-locations=classpath:com/cy/springsecurity02/mapper/*.xml
mybatis.type-aliases-package=com.cy.springsecurity02.entity
#log
logging.level.com.cy=debug
```

> 创建实体类Role

```java
//角色类
public class Role {

    private Integer id;
    private String name;
    private String namezh;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getNamezh() {
        return namezh;
    }

    public void setNamezh(String namezh) {
        this.namezh = namezh;
    }
}

```

> 创建实体类User（entity包下）

```java
public class User implements UserDetails {

    private Integer id;
    private String username;
    private String password;
    private Boolean enabled;//账户是否激活
    private Boolean accountNonExpired;//账户是否过期
    private Boolean accountNonLocked;//账户是否被锁定
    private Boolean credentialsNonExpired;//密码是否过期
    private List<Role> roles = new ArrayList<>();//关系属性用来存储当前用户所有角色信息

    //返回权限信息
    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        Set<SimpleGrantedAuthority> authorities = new HashSet<>();
        roles.forEach(role -> {
            SimpleGrantedAuthority simpleGrantedAuthority = new SimpleGrantedAuthority(role.getName());
            authorities.add(simpleGrantedAuthority);
        });
        return authorities;
    }

    @Override
    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    @Override
    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    @Override
    public boolean isAccountNonExpired() {
        return accountNonExpired;
    }

    public void setAccountNonExpired(Boolean accountNonExpired) {
        this.accountNonExpired = accountNonExpired;
    }

    @Override
    public boolean isAccountNonLocked() {
        return accountNonLocked;
    }

    public void setAccountNonLocked(Boolean accountNonLocked) {
        this.accountNonLocked = accountNonLocked;
    }

    @Override
    public boolean isCredentialsNonExpired() {
        return credentialsNonExpired;
    }

    public void setCredentialsNonExpired(Boolean credentialsNonExpired) {
        this.credentialsNonExpired = credentialsNonExpired;
    }

    @Override
    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(Boolean enabled) {
        this.enabled = enabled;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public List<Role> getRoles() {
        return roles;
    }

    public void setRoles(List<Role> roles) {
        this.roles = roles;
    }
}

```

> 除了id,roles，其他因为实现UserDetails，自带get方法

<br/>

> 在resources包下创建com.cy.springsecurity02.mapper.UserDaoMapper.xml文件

```xml
<?xml version="1.0" encoding="UTF-8" ?>
<!DOCTYPE mapper
        PUBLIC "-//mybatis.org//DTD Mapper 3.0//EN"
        "http://mybatis.org/dtd/mybatis-3-mapper.dtd">
<mapper namespace="com.cy.springsecurity02.dao.UserDao">

    <!--根据用户名查询用户方法-->
    <select id="LoadUserByUsername" resultType="User">
        select id,
               username,
               password,
               enabled,
               accountNonExpired,
               accountNonLocked,
               credentialsNonExpired
        from user
        where username = #{username}
    </select>

    <!--根据用户id查询信息-->
    <select id="getRolesByUid" resultType="Role">
        select r.id,
               r.name,
               r.name_zh nameZh
        from role r,
             user_role ur
        where r.id = ur.rid
          and ur.uid = #{uid}
    </select>

</mapper>

```

> 创建MyUserDetailService（config包下）

```java
@Component
public class MyUserDetailService implements UserDetailsService {

    private final UserDao userDao;

    @Autowired
    public MyUserDetailService(UserDao userDao) {
        this.userDao = userDao;
    }

    //dao===>springboot+mybatis

    
    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        User user = userDao.LoadUserByUsername(username);
        if (ObjectUtils.isEmpty(user)) throw new UsernameNotFoundException("用户名不正确~");
        //2.查询权限信息
        List<Role> roles = userDao.getRolesByUid(user.getId());
        user.setRoles(roles);
        return user;
    }
}

```

> 在WebSecurityConfigurer类中加入如下代码

```java
@Configuration
public class WebSecurityConfigurer extends WebSecurityConfigurerAdapter {
    private final MyUserDetailService myUserDetailService;

    @Autowired
    public WebSecurityConfigurer(MyUserDetailService myUserDetailService) {
        this.myUserDetailService = myUserDetailService;
    }

    @Bean
    public UserDetailsService userDetailsService() {
        InMemoryUserDetailsManager userDetailsService = new InMemoryUserDetailsManager();
        userDetailsService.createUser(User.withUsername("aaa").password("{noop}123").roles("admin").build());
        return userDetailsService;
    }

    /**
     * //springboot对security默认配置中在工厂中默认创建AuthenticationManager
     *
     * @Autowired public void initialize(AuthenticationManagerBuilder builder) {
     * System.out.println("springboot默认配置：" + builder);
     * <p>
     * }
     */

    //自定义AuthenticationManager 推荐 并没有在工厂中暴露出来
    @Override
    protected void configure(AuthenticationManagerBuilder auth) throws Exception {
        System.out.println("自定义AuthenticationManager" + auth);
        //auth.userDetailsService(userDetailsService());
        auth.userDetailsService(myUserDetailService);
    }
    
    ...
}
```

> 创建UserDao类（dao包）

```java
@Mapper
public interface UserDao {

    //提供根据用户名返回用户方法
    User LoadUserByUsername(String username);

    //根据用户id查询角色
    List<Role> getRolesByUid(Integer uid);
}
```

**User导入的是import com.cy.springsecurity02.entity.User**

运行主程序，localhost:8080/hello ，admin 123 登录成功

<br/>

# 自定义认证案例

## 1. 传统Web开发认证

> com.cy.dao.UserDao

```java
@Mapper
public interface UserDao {

    //提供根据用户名返回用户方法
    User LoadUserByUsername(String username);

    //根据用户id查询角色
    List<Role> getRolesByUid(Integer uid);
}
```

> entity.Role

```java
//角色类
public class Role {

    private Integer id;
    private String name;
    private String namezh;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getNamezh() {
        return namezh;
    }

    public void setNamezh(String namezh) {
        this.namezh = namezh;
    }
}
```

> User

```java
public class User implements UserDetails {

    private Integer id;
    private String username;
    private String password;
    private Boolean enabled;//账户是否激活
    private Boolean accountNonExpired;//账户是否过期
    private Boolean accountNonLocked;//账户是否被锁定
    private Boolean credentialsNonExpired;//密码是否过期
    private List<Role> roles = new ArrayList<>();//关系属性用来存储当前用户所有角色信息

    //返回权限信息
    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        Set<SimpleGrantedAuthority> authorities = new HashSet<>();
        roles.forEach(role -> {
            SimpleGrantedAuthority simpleGrantedAuthority = new SimpleGrantedAuthority(role.getName());
            authorities.add(simpleGrantedAuthority);
        });
        return authorities;
    }

    @Override
    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    @Override
    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    @Override
    public boolean isAccountNonExpired() {
        return accountNonExpired;
    }

    public void setAccountNonExpired(Boolean accountNonExpired) {
        this.accountNonExpired = accountNonExpired;
    }

    @Override
    public boolean isAccountNonLocked() {
        return accountNonLocked;
    }

    public void setAccountNonLocked(Boolean accountNonLocked) {
        this.accountNonLocked = accountNonLocked;
    }

    @Override
    public boolean isCredentialsNonExpired() {
        return credentialsNonExpired;
    }

    public void setCredentialsNonExpired(Boolean credentialsNonExpired) {
        this.credentialsNonExpired = credentialsNonExpired;
    }

    @Override
    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(Boolean enabled) {
        this.enabled = enabled;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public List<Role> getRoles() {
        return roles;
    }

    public void setRoles(List<Role> roles) {
        this.roles = roles;
    }
}

```

> LoginController

```java
@Controller
public class LoginController {

    @RequestMapping("/login.html")
    public String login() {
        return "login";
    }

}

```

> TestController

```java
@RestController
public class TestController {

    @RequestMapping("/user")
    public String user() {
        //1.代码中获取用户信息
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        //2.通过获取用户信息
        User user = (User) authentication.getPrincipal();
        System.out.println("username=" + user.getUsername());
        System.out.println("authorities=" + user.getAuthorities());
        return "user ok";
    }

}
```

> config.MvcConfigure

```java
/**
 * 对springmvc进行自定义配置
 */
@Configuration
public class MvcConfigure implements WebMvcConfigurer {

    @Override
    public void addViewControllers(ViewControllerRegistry registry) {
        registry.addViewController("/login.html").setViewName("login");
        registry.addViewController("/index.html").setViewName("index");

    }
}
```

> service.MyUserDetailService

```java
@Service
public class MyUserDetailService implements UserDetailsService {

    private final UserDao userDao;

    @Autowired
    public MyUserDetailService(UserDao userDao) {
        this.userDao = userDao;
    }

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        //1.根据用查询用户
        User user = userDao.LoadUserByUsername(username);
        if (ObjectUtils.isEmpty(user)) throw new UsernameNotFoundException("用户名不存在");
        //2.获取角色
        user.setRoles(userDao.getRolesByUid(user.getId()));
        return user;
    }


}

```

> resource/com.cy.UserDaoMapper.xml

```xml
<?xml version="1.0" encoding="UTF-8" ?>
<!DOCTYPE mapper
        PUBLIC "-//mybatis.org//DTD Mapper 3.0//EN"
        "http://mybatis.org/dtd/mybatis-3-mapper.dtd">
<mapper namespace="com.cy.dao.UserDao">

    <!--根据用户名查询用户方法-->
    <select id="LoadUserByUsername" resultType="User">
        select id,
               username,
               password,
               enabled,
               accountNonExpired,
               accountNonLocked,
               credentialsNonExpired
        from user
        where username = #{username}
    </select>

    <!--根据用户id查询信息-->
    <select id="getRolesByUid" resultType="Role">
        select r.id,
               r.name,
               r.name_zh nameZh
        from role r,
             user_role ur
        where r.id = ur.rid
          and ur.uid = #{uid}
    </select>

</mapper>

```

> templates.index

```html
<!DOCTYPE html>
<html lang="en" xmlns:sec="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="UTF-8">
    <title>系统主页</title>
</head>
<body>
<h1>欢迎<span sec:authentication="principal.username"></span>,进入我的系统！</h1>
<h3>用户信息信息：</h3>
<ul>
    <li sec:authentication="principal.username"></li>
    <li sec:authentication="principal.authorities"></li>
    <li sec:authentication="principal.accountNonExpired"></li>
    <li sec:authentication="principal.accountNonLocked"></Li>
    <li sec:authentication="principal.credentialsNonExpired"></li>
</ul>
<hr>
<a th:href="@{/logout}">退出系统</a>
</body>
</html>
```

> templates.login

```html
<!DOCTYPE html>
<html Lang="en" xmlns:th="http://www.thymeleaf.org"
>
<head>
    <meta charset="UTF-8">
    <title>登录页面</title>
</head>
<body>
<h1>用户登录</h1>
<form method="post" th:action="@{/doLogin}">
    用户名：<input name="uname" type="text"><br>
    密码：<input name="passwd" type="text"><br>
    <input type="submit" value="登录">
</form>
<h3>
    <div th:text="${SPRING_SECURITY_LAST_EXCEPTION}"></div>
</h3>
</body>
</html>
```

> application.properties

```properties
#项目端口
server.port=8081
#thymeleaf配置
spring.thymeleaf.cache=false
#thymeleaf默认配置
spring.thymeleaf.prefix=classpath:/templates/
spring.thymeleaf.suffix=.html
soring.thymeleaf.encoding=UTF-8
spring.thymeleaf.mode=HTML
#datasource
spring.datasource.type=com.alibaba.druid.pool.DruidDataSource
spring.datasource.driver-class-name=com.mysql.cj.jdbc.Driver
spring.datasource.url=jdbc:mysql://localhost:3306/security?useUnicode=true&characterEncoding=UTF-8&serverTimezone=UTC
spring.datasource.username=root
spring.datasource.password=hsxsdm
#mybatis
mybatis.mapper-locations=classpath:com/cy/mapper/*.xml
mybatis.type-aliases-package=com.cy.entity
#log
logging.level.com.cy=debug
```

> config.SecurityConfigure

```java
package com.cy.config;

import com.cy.service.MyUserDetailService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;

/**
 * 自定义 Security配置
 */
@Configuration
public class SecurityConfigure extends WebSecurityConfigurerAdapter {
    @Autowired
    private MyUserDetailService myUserDetailService;

    /**
     * 内存实现
     @Bean public UserDetailsService userDetailsService() {
     InMemorzidinyyUserDetailsManager inMemoryUserDetailsManager = new InMemoryUserDetailsManager();
     inMemoryUserDetailsManager.createUser(User.withUsername("root").password("{noop}123").roles("admin").build());
     return inMemoryUserDetailsManager;
     }
     */

    /**
     * 自定义实现方式
     */
    @Override
    protected void configure(AuthenticationManagerBuilder auth) throws Exception {
        /** auth.userDetailsService(userDetailsService()); 内存实现*/
        auth.userDetailsService(myUserDetailService);//数据库实现
    }

    @Override
    protected void configure(HttpSecurity http) throws Exception {
        http.authorizeRequests()
                .mvcMatchers("/login.html").permitAll()
                .anyRequest().authenticated()
                .and()
                .formLogin()
                .loginPage("/login.html")//指定自定义登录界面
                .loginProcessingUrl("/doLogin") //处理请求登录的url
                .usernameParameter("uname") //设置账户
                .passwordParameter("passwd") //设置密码
                .defaultSuccessUrl("/index.html", true)  //默认登录成功跳转的页面
                .failureUrl("/login.htmL")//重定向到登录页面
                .and()
                .logout()//开启退出登录
                .logoutUrl("/logout") //处理退出的Url
                .logoutSuccessUrl("/login.html") //退出成功跳转的页面
                .and()
                .csrf().disable()//csrf关闭
        ;
    }
}

```

- MvcConfig类配置视图（也可以在properties文件配置）

```properties
#thymeleaf默认配置
spring.thymeleaf.prefix=classpath:/templates/
spring.thymeleaf.suffix=.html
soring.thymeleaf.encoding=UTF-8
```

- 自定义实现两种
  - 内存实现：SecurityConfigure类的/***/注解
  - 数据库实现：myUserDetailService类注入 SecurityConfigure类的auth.userDetailsService()方法

## 2.前后端分离认证

<br/>

项目：spring-security04(只选Spring Web)

依赖：

```xml
        <!--druid-->
        <dependency>
            <groupId>com.alibaba</groupId>
            <artifactId>druid</artifactId>
            <version>1.1.20</version>
        </dependency>
        <!--mysql-->
        <dependency>
            <groupId>mysql</groupId>
            <artifactId>mysql-connector-java</artifactId>
            <version>8.0.20</version>
        </dependency>
        <!--mybatis-springboot-->
        <dependency>
            <groupId>org.mybatis.spring.boot</groupId>
            <artifactId>mybatis-spring-boot-starter</artifactId>
            <version>2.2.2</version>
        </dependency>

        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-security</artifactId>
        </dependency>
```

配置：

```properties
# 应用服务 WEB 访问端口
server.port=8082
```

Controller层：

```java
@RestController
public class TestController {

    @GetMapping("/test")
    public String test() {
        System.out.println("test ...");
        return "test ok!";
    }

}
```

Config层：

> LoginFilter类

```java
/**
 * 自定义前后端分离认证Filter
 */
public class LoginFilter extends UsernamePasswordAuthenticationFilter {
    @Override
    public Authentication attemptAuthentication(HttpServletRequest request, HttpServletResponse response) throws AuthenticationException {
        //1.判断是否是Post方式请求
        if (!request.getMethod().equals("POST")) {
            throw new AuthenticationServiceException("Authentication method not supported:" + request.getMethod());
        }
        //2,判断是否是json格式请求类型
        if (request.getContentType().equalsIgnoreCase(MediaType.APPLICATION_JSON_VALUE)) {
            //3.从json数据中获取用户输入用户名和密码进行认证{"uname":"xxx","password":"kx")
            try {
                Map<String, String> userInfo = new ObjectMapper().readValue(request.getInputStream(), Map.class);
                String username = userInfo.get(getUsernameParameter());
                String password = userInfo.get(getPasswordParameter());
                System.out.println("用户名：" + username + "密码：" + password);

                UsernamePasswordAuthenticationToken authRequest = new UsernamePasswordAuthenticationToken(username, password);
                setDetails(request, authRequest);
                return this.getAuthenticationManager().authenticate(authRequest);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return super.attemptAuthentication(request, response);
    }

}
```

- 继承UsernamePasswordAuthenticationFilter自定义判断方法，

源代码（UsernamePasswordAuthenticationFilter类）解析：

```java
public class UsernamePasswordAuthenticationFilter extends AbstractAuthenticationProcessingFilter {
    public static final String SPRING_SECURITY_FORM_USERNAME_KEY = "username";
    public static final String SPRING_SECURITY_FORM_PASSWORD_KEY = "password";
    private static final AntPathRequestMatcher DEFAULT_ANT_PATH_REQUEST_MATCHER = new AntPathRequestMatcher("/login", "POST");
    private String usernameParameter = "username";
    private String passwordParameter = "password";
    private boolean postOnly = true;

    public UsernamePasswordAuthenticationFilter() {
        super(DEFAULT_ANT_PATH_REQUEST_MATCHER);
    }

    public UsernamePasswordAuthenticationFilter(AuthenticationManager authenticationManager) {
        super(DEFAULT_ANT_PATH_REQUEST_MATCHER, authenticationManager);
    }

    public Authentication attemptAuthentication(HttpServletRequest request, HttpServletResponse response) throws AuthenticationException {
        if (this.postOnly && !request.getMethod().equals("POST")) {
            throw new AuthenticationServiceException("Authentication method not supported: " + request.getMethod());
        } else {
            String username = this.obtainUsername(request);
            username = username != null ? username : "";
            username = username.trim();
            String password = this.obtainPassword(request);
            password = password != null ? password : "";
            UsernamePasswordAuthenticationToken authRequest = new UsernamePasswordAuthenticationToken(username, password);
            this.setDetails(request, authRequest);
            return this.getAuthenticationManager().authenticate(authRequest);
        }
    }

    @Nullable
    protected String obtainPassword(HttpServletRequest request) {
        return request.getParameter(this.passwordParameter);
    }

    @Nullable
    protected String obtainUsername(HttpServletRequest request) {
        return request.getParameter(this.usernameParameter);
    }

    protected void setDetails(HttpServletRequest request, UsernamePasswordAuthenticationToken authRequest) {
        authRequest.setDetails(this.authenticationDetailsSource.buildDetails(request));
    }

    public void setUsernameParameter(String usernameParameter) {
        Assert.hasText(usernameParameter, "Username parameter must not be empty or null");
        this.usernameParameter = usernameParameter;
    }

    public void setPasswordParameter(String passwordParameter) {
        Assert.hasText(passwordParameter, "Password parameter must not be empty or null");
        this.passwordParameter = passwordParameter;
    }

    public void setPostOnly(boolean postOnly) {
        this.postOnly = postOnly;
    }

    public final String getUsernameParameter() {
        return this.usernameParameter;
    }

    public final String getPasswordParameter() {
        return this.passwordParameter;
    }
}

```

- 原方法是通过request.getParameter("username") 和 request.getParameter("password")来获取用户名和密码
- 这里有个知识点
  ```java
  Assert.hasText(usernameParameter, "Username parameter must not be empty or null");
  Assert.hasText("如果为空或null","抛出的异常信息")
  ```

过程：

先定义的初始化变量：

```java
  private String usernameParameter = "username";
  private String passwordParameter = "password";
```

进入验证：

```java
  public Authentication attemptAuthentication(HttpServletRequest request, HttpServletResponse response) throws AuthenticationException {
        if (this.postOnly && !request.getMethod().equals("POST")) {  //判断是否是get请求
            throw new AuthenticationServiceException("Authentication method not supported: " + request.getMethod()); //不是，抛出异常
        } else {
            String username = this.obtainUsername(request);  //调用obtainUsername方法
            username = username != null ? username : "";
            username = username.trim();
            String password = this.obtainPassword(request);
            password = password != null ? password : "";
            UsernamePasswordAuthenticationToken authRequest = new UsernamePasswordAuthenticationToken(username, password);
            this.setDetails(request, authRequest);
            return this.getAuthenticationManager().authenticate(authRequest);
        }
    }
```

调用obtainUsername方法:

```java
  @Nullable
    protected String obtainUsername(HttpServletRequest request) {
        return request.getParameter(this.usernameParameter);
    }
```

> this.usernameParameter = “username”，通过request.getParameter(“username”）获取表单属性为username的值给username。password同

进入UsernamePasswordAuthenticationToken方法，把username和password封装到UsernamePasswordAuthenticationToken对象中：

```java
 public Authentication attemptAuthentication(HttpServletRequest request, HttpServletResponse response) throws AuthenticationException {
        if (this.postOnly && !request.getMethod().equals("POST")) {  //判断是否是get请求
            throw new AuthenticationServiceException("Authentication method not supported: " + request.getMethod()); //不是，抛出异常
        } else {
            String username = this.obtainUsername(request);  //调用obtainUsername方法
            username = username != null ? username : "";
            username = username.trim();
            String password = this.obtainPassword(request);
            password = password != null ? password : "";
            UsernamePasswordAuthenticationToken authRequest = new UsernamePasswordAuthenticationToken(username, password);
            this.setDetails(request, authRequest);
            return this.getAuthenticationManager().authenticate(authRequest);
        }
    }
```

- 这里就可以看出默认表单的id属性应该是username和password。

前后端分离指的是传入的数据是JSON格式。所以只需要修改接收参数的那一部分，接受完还是要传给UsernamePasswordAuthenticationToken中。

<br/>

> SecurityConfig类

```java
@Configuration
public class SecurityConfig extends WebSecurityConfigurerAdapter {

    @Bean
    public UserDetailsService userDetailsService() {
        InMemoryUserDetailsManager inMemoryUserDetailsManager = new InMemoryUserDetailsManager();
        inMemoryUserDetailsManager.createUser(User.withUsername("root").password("{noop}123").roles("admin").build());
        return inMemoryUserDetailsManager;
    }

    @Override
    protected void configure(AuthenticationManagerBuilder auth) throws Exception {
        auth.userDetailsService(userDetailsService());
    }

    @Override
    @Bean
    public AuthenticationManager authenticationManagerBean() throws Exception {
        return super.authenticationManagerBean();
    }

    //自定义filter交给工厂管理
    @Bean
    public LoginFilter loginFilter() throws Exception {
        LoginFilter loginFilter = new LoginFilter();
        loginFilter.setFilterProcessesUrl("/doLogin");
        loginFilter.setUsernameParameter("uname");//指定接收json用户名key
        loginFilter.setPasswordParameter("passwd");//指定接收json密码key

        //调用authenticationManagerBean发方法，会返回父类的authenticationManager实例
        loginFilter.setAuthenticationManager(authenticationManagerBean());
        //认证成功处理
        loginFilter.setAuthenticationSuccessHandler((req, resp, authentication) -> {
            Map<String, Object> result = new HashMap<String, Object>();
            result.put("msg", "登录成功");
            result.put("用户信息", authentication.getPrincipal());
            resp.setContentType("application/json;charset=UTF-8");
            resp.setStatus(HttpStatus.OK.value());
            String s = new ObjectMapper().writeValueAsString(result);
            resp.getWriter().println(s);
        });
        //认证失败处理
        loginFilter.setAuthenticationFailureHandler((req, resp, ex) -> {
            Map<String, Object> result = new HashMap<String, Object>();
            result.put("msg", "登录失败：" + ex.getMessage());
            resp.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
            resp.setContentType("application/json;charset=UTF-8");
            String s = new ObjectMapper().writeValueAsString(result);
            resp.getWriter().println(s);
        });

        return loginFilter;
    }

    @Override
    protected void configure(HttpSecurity http) throws Exception {

        http.authorizeHttpRequests()
                .anyRequest().authenticated()//所有请求必须认证
                .and()
                .formLogin()
                .and()
                .exceptionHandling()
                .authenticationEntryPoint((req, resp, ex) -> {
                    resp.setContentType(MediaType.APPLICATION_JSON_UTF8_VALUE);
                    resp.setStatus(HttpStatus.UNAUTHORIZED.value());
                    resp.getWriter().println("请认证之后再去处理！");
                })
                .and()
                .logout()
                .logoutRequestMatcher(new OrRequestMatcher(
                        new AntPathRequestMatcher("/logout", HttpMethod.DELETE.name()),
                        new AntPathRequestMatcher("/logout", HttpMethod.GET.name())
                ))
                .logoutUrl("/logout")
                .logoutSuccessHandler((req, resp, auth) -> {
                    Map<String, Object> result = new HashMap<String, Object>();
                    result.put("msg", "注销成功");
                    result.put("用户信息", auth.getPrincipal());
                    resp.setContentType("application/json;charset=UTF-8");
                    resp.setStatus(HttpStatus.OK.value());
                    String s = new ObjectMapper().writeValueAsString(result);
                    resp.getWriter().println(s);
                })
                .and().csrf().disable()
        ;

        //at:用来某个filter替换过滤器链中哪个filter
        //before:放在过滤器链中哪个filter之前
        //after:放在过滤器链中那个filter之后
        http.addFilterAt(loginFilter(), UsernamePasswordAuthenticationFilter.class);
    }
}
```

- UserDetailsService方法：内存实现，设置用户名、密码、权限
- configure方法：调用auth.userDetailsService( userDetailsService( ) )，找到返回的 **UserDetailsService** 实例（inMemoryUserDetailsManager实现的），赋值给 auth.userDetailsService( **inMemoryUserDetailsManager** )，也就是用自定义的内存实现，不用默认的UserDetaiilsService实例
- authenticationManagerBean方法：因为configure类的参数是AuthenticationManagerBuilder类型，默认情况下在WebSecurityConfigurerAdapter类中，AuthenticationManagerBuilder是通过工厂模式加载的，
  
  打开WebSecurityConfigurerAdapter类，简化代码如下：
  ```java
  @Order(100)
  public abstract class WebSecurityConfigurerAdapter implements WebSecurityConfigurer<WebSecurity> {
      private ApplicationContext context;
      private AuthenticationConfiguration authenticationConfiguration;
      private AuthenticationManagerBuilder authenticationBuilder;
      private AuthenticationManagerBuilder localConfigureAuthenticationBldr;
      private boolean disableLocalConfigureAuthenticationBldr;  //默认false
      private boolean authenticationManagerInitialized;
      
       public AuthenticationManager authenticationManagerBean() throws Exception {
          return new AuthenticationManagerDelegator(this.authenticationBuilder, this.context);
      }
  
  
      protected void configure(AuthenticationManagerBuilder auth) throws Exception {
          this.disableLocalConfigureAuthenticationBldr = true;
      }
  
      protected AuthenticationManager authenticationManager() throws Exception {
          if (!this.authenticationManagerInitialized) {
              this.configure(this.localConfigureAuthenticationBldr);
              if (this.disableLocalConfigureAuthenticationBldr) {
                  this.authenticationManager = this.authenticationConfiguration.getAuthenticationManager();
              } else {
                  this.authenticationManager = (AuthenticationManager)this.localConfigureAuthenticationBldr.build();
              }
  
              this.authenticationManagerInitialized = true;
          }
  
          return this.authenticationManager;
      }
  }
  
  ```

> 直接看authenticationManager()方法，默认authenticationManagerInitialized是false,所以向下执行，调用configure()方法，disableLocalConfigureAuthenticationBldr=true,调用authenticationConfiguration.getAuthenticationManager方法

进入getAuthenticationManager方法

```java
 public AuthenticationManager getAuthenticationManager() throws Exception {
        if (this.authenticationManagerInitialized) {
            return this.authenticationManager;
        } else {
          //  AuthenticationManagerBuilder authBuilder = (AuthenticationManagerBuilder)this.applicationContext.getBean(AuthenticationManagerBuilder.class);
            if (this.buildingAuthenticationManager.getAndSet(true)) {
                return new AuthenticationManagerDelegator(authBuilder);
            } else {
                Iterator var2 = this.globalAuthConfigurers.iterator();

                while(var2.hasNext()) {
                    GlobalAuthenticationConfigurerAdapter config = (GlobalAuthenticationConfigurerAdapter)var2.next();
                    authBuilder.apply(config);
                }

                this.authenticationManager = (AuthenticationManager)authBuilder.build();
                if (this.authenticationManager == null) {
                    this.authenticationManager = this.getAuthenticationManagerBean();
                }

                this.authenticationManagerInitialized = true;
                return this.authenticationManager;
            }
        }
    }
```

> 看绿色这一行（不该注释）即AuthenticationManagerBuilder是从工厂里拿现有的bean 然后再去build构建,最后就生成了默认的AuthenticationManager.

直接在SecurityConfig类中实例化authenticationManagerBean

```java
@Override
    @Bean
    public AuthenticationManager authenticationManagerBean() throws Exception {
        return super.authenticationManagerBean();
    }
```

> 不管自定义与否,工厂中都会自动加载了authenticationManagerBuilder这个组件,只是自定义的话就不用工厂的builder去创建AuthenticationManager,而是用本类authenticationManagerBuilder成员

<br/>

换成数据源认证：

> entity.Role

```java
package com.cy.entity;

//角色类
public class Role {

    private Integer id;
    private String name;
    private String namezh;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getNamezh() {
        return namezh;
    }

    public void setNamezh(String namezh) {
        this.namezh = namezh;
    }
}

```

> entity.User

```java
package com.cy.entity;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import java.util.*;

public class User implements UserDetails {

    private Integer id;
    private String username;
    private String password;
    private Boolean enabled;//账户是否激活
    private Boolean accountNonExpired;//账户是否过期
    private Boolean accountNonLocked;//账户是否被锁定
    private Boolean credentialsNonExpired;//密码是否过期
    private List<Role> roles = new ArrayList<>();//关系属性用来存储当前用户所有角色信息

    //返回权限信息
    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        Set<SimpleGrantedAuthority> authorities = new HashSet<>();
        roles.forEach(role -> {
            SimpleGrantedAuthority simpleGrantedAuthority = new SimpleGrantedAuthority(role.getName());
            authorities.add(simpleGrantedAuthority);
        });
        return authorities;
    }

    @Override
    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    @Override
    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    @Override
    public boolean isAccountNonExpired() {
        return accountNonExpired;
    }

    public void setAccountNonExpired(Boolean accountNonExpired) {
        this.accountNonExpired = accountNonExpired;
    }

    @Override
    public boolean isAccountNonLocked() {
        return accountNonLocked;
    }

    public void setAccountNonLocked(Boolean accountNonLocked) {
        this.accountNonLocked = accountNonLocked;
    }

    @Override
    public boolean isCredentialsNonExpired() {
        return credentialsNonExpired;
    }

    public void setCredentialsNonExpired(Boolean credentialsNonExpired) {
        this.credentialsNonExpired = credentialsNonExpired;
    }

    @Override
    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(Boolean enabled) {
        this.enabled = enabled;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public List<Role> getRoles() {
        return roles;
    }

    public void setRoles(List<Role> roles) {
        this.roles = roles;
    }
}

```

> 配置

```properties
# 应用服务 WEB 访问端口
server.port=8082
#datasource
spring.datasource.type=com.alibaba.druid.pool.DruidDataSource
spring.datasource.driver-class-name=com.mysql.cj.jdbc.Driver
spring.datasource.url=jdbc:mysql://localhost:3306/security?useUnicode=true&characterEncoding=UTF-8&serverTimezone=UTC
spring.datasource.username=root
spring.datasource.password=hsxsdm
#mybatis
mybatis.mapper-locations=classpath:com/cy/mapper/*.xml
mybatis.type-aliases-package=com.cy.entity
#log
logging.level.com.cy=debug
```

> com.cy.mapper.UserDaoMapper.xml

```xml
<?xml version="1.0" encoding="UTF-8" ?>
<!DOCTYPE mapper
        PUBLIC "-//mybatis.org//DTD Mapper 3.0//EN"
        "http://mybatis.org/dtd/mybatis-3-mapper.dtd">
<mapper namespace="com.cy.dao.UserDao">

    <!--根据用户名查询用户方法-->
    <select id="LoadUserByUsername" resultType="User">
        select id,
               username,
               password,
               enabled,
               accountNonExpired,
               accountNonLocked,
               credentialsNonExpired
        from user
        where username = #{username}
    </select>

    <!--根据用户id查询信息-->
    <select id="getRolesByUid" resultType="Role">
        select r.id,
               r.name,
               r.name_zh nameZh
        from role r,
             user_role ur
        where r.id = ur.rid
          and ur.uid = #{uid}
    </select>

</mapper>

```

> dao.UserDao

```java
@Mapper
public interface UserDao {

    //提供根据用户名返回用户方法
    User LoadUserByUsername(String username);

    //根据用户id查询角色
    List<Role> getRolesByUid(Integer uid);
}

```

> service.MyUserDetailService

```java
//自定义 UserDetailsService 实现
@Service
public class MyUserDetailService implements UserDetailsService {


    private final UserDao userDao;

    @Autowired
    public MyUserDetailService(UserDao userDao) {
        this.userDao = userDao;
    }

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        User user = this.userDao.LoadUserByUsername(username);
        if (ObjectUtils.isEmpty(user)) throw new RuntimeException("用户名不存在！");
        user.setRoles(userDao.getRolesByUid(user.getId()));
        return user;
    }

}

```

```
security(只有前几行变了)
```

```java
@Configuration
public class SecurityConfig extends WebSecurityConfigurerAdapter {

    /**
     * 内存
     *
     * @Bean public UserDetailsService userDetailsService() {
     * InMemoryUserDetailsManager inMemoryUserDetailsManager = new InMemoryUserDetailsManager();
     * inMemoryUserDetailsManager.createUser(User.withUsername("root").password("{noop}123").roles("admin").build());
     * return inMemoryUserDetailsManager;
     * }
     */

    //数据源认证
    private final MyUserDetailService myUserDetailService;

    @Autowired
    public SecurityConfig(MyUserDetailService myUserDetailService) {
        this.myUserDetailService = myUserDetailService;
    }

    @Override
    protected void configure(AuthenticationManagerBuilder auth) throws Exception {
        auth.userDetailsService(myUserDetailService);
    }
    
    ...
}

```

运行主程序，先验证

![screen-capture](534e65b4e5124de4972866c525022093.png)

访问测试路径

![screen-capture](8a52c55fae9baf68896b4ae70d6226f9.png)

退出认证

![screen-capture](940b7092b81602a2747802b1cc989425.png)

再次进入测试路径

![screen-capture](a79489ffe0cd678593e5a58423cd46dd.png)

***

# 传统Web开发验证码

项目：spring-security05（选spring-web）

依赖：

```xml
 <!--验证码-->
        <dependency>
            <groupId>com.github.penggle</groupId>
            <artifactId>kaptcha</artifactId>
            <version>2.3.2</version>
        </dependency>

        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-security</artifactId>
        </dependency>
```

templates/index.html

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>主页</title>
</head>
<body>
<h1>欢迎进入我的主页</h1>
</body>
</html>
```

templates/login.html

```html
<!DOCTYPE html>
<html lang="en" xmlns:th="http://www.thymeleaf.org">
<head>
    <meta charset="UTF-8">
    <title>登录</title>
</head>
<body>
<h1>用户登录</h1>
<form method="post" th:action="@{/doLogin}">
    用户名：<input name="uname" type="text"><br>
    密码：<input name="passwd" type="text"><br>
    验证码：<input name="kaptcha" type="text"><img alt="" th:src="@{/vc.jpg}"><br>
    <input type="submit" value="登录">
</form>
</body>
</html>
```

config.kaptchaConfig（生成验证码）：

```java
@Configuration
public class kaptchaConfig {

    @Bean
    public Producer kaptcha() {
        Properties properties = new Properties();
        //验证码宽度
        properties.setProperty("kaptcha.image.width", "150");
        //验证码高度
        properties.setProperty("kaptcha.image.height", "50");
        //验证码字符串
        properties.setProperty("kaptcha.textproducer.char.string",
                "0123456789");
        //验证码长度
        properties.setProperty("kaptcha.textproducer.char.length", "4");
        Config config = new Config(properties);
        DefaultKaptcha defaultKaptcha = new DefaultKaptcha();
        defaultKaptcha.setConfig(config);
        return defaultKaptcha;
    }
}

```

controller.VerifyCodeController

```java
@Controller
public class VerifyCodeController {
    private final Producer producer;

    @Autowired
    public VerifyCodeController(Producer producer) {
        this.producer = producer;
    }

    @RequestMapping("/vc.jpg")
    public void verifyCode(HttpServletResponse response, HttpSession session) throws IOException {
        //1.生成验证码
        String verifyCode = producer.createText();
        //2.保存到中session
        session.setAttribute("kaptcha", verifyCode);
        //3.生成图片
        BufferedImage bi = producer.createImage(verifyCode);
        //4,响应图片
        response.setContentType("image/png");
        ServletOutputStream os = response.getOutputStream();
        ImageIO.write(bi, "jpg", os);
    }
}
```

config.MvcConfig(视图配置)

```java
@Configuration
public class MvcConfig implements WebMvcConfigurer {

    @Override
    public void addViewControllers(ViewControllerRegistry registry) {
        registry.addViewController("index.html").setViewName("index");
        registry.addViewController("login.html").setViewName("login");
    }

}

```

application.properties

```properties
# 应用服务 WEB 访问端口
server.port=8080
spring.thymeleaf.cache=false
```

config.SecurityConfig

```java
@Configuration
public class SecurityConfig extends WebSecurityConfigurerAdapter {

    @Bean
    public UserDetailsService userDetailsService() {
        InMemoryUserDetailsManager inMemoryUserDetailsManager = new InMemoryUserDetailsManager();
        inMemoryUserDetailsManager.createUser(User.withUsername("root").password("{noop}123").roles("admin").build());
        return inMemoryUserDetailsManager;
    }

    @Override
    protected void configure(AuthenticationManagerBuilder auth) throws Exception {
        auth.userDetailsService(userDetailsService());
    }

    @Override
    @Bean
    public AuthenticationManager authenticationManagerBean() throws Exception {
        return super.authenticationManagerBean();
    }

    @Bean
    public KaptchaFilter kaptchaFilter() throws Exception {
        KaptchaFilter kaptchaFilter = new KaptchaFilter();
        kaptchaFilter.setFilterProcessesUrl("/doLogin");
        kaptchaFilter.setUsernameParameter("uname");
        kaptchaFilter.setPasswordParameter("passwd");
        kaptchaFilter.setKaptchaParameter("kaptcha");
        //指定认证管理器
        kaptchaFilter.setAuthenticationManager(authenticationManagerBean());
        //指定认证成功处理
        kaptchaFilter.setAuthenticationSuccessHandler((req, resp, auth) -> {
            resp.sendRedirect("/index.html");
        });
        //指定认证失败处理
        kaptchaFilter.setAuthenticationFailureHandler((req, resp, ex) -> {
            resp.sendRedirect("/login.html");
        });
        return kaptchaFilter;
    }

    @Override
    protected void configure(HttpSecurity http) throws Exception {
        http.authorizeRequests()
                .mvcMatchers("/login.html").permitAll()
                .mvcMatchers("/vc.jpg").permitAll()
                .anyRequest().authenticated()
                .and()
                .formLogin()
                .loginPage("/login.html")
                .and()
                .logout()
                .logoutUrl("/logout")
                .and()
                .csrf().disable();

        http.addFilterAt(kaptchaFilter(), UsernamePasswordAuthenticationFilter.class);
    }
}

```

security.exception.KaptchaNotMatchException(自定义验证码认证异常)

```java
//自定义验证码认证异常
public class KaptchaNotMatchException extends AuthenticationException {
    public KaptchaNotMatchException(String msg, Throwable cause) {
        super(msg,cause);
    }

    public KaptchaNotMatchException(String msg) {
        super(msg);

    }
}
```

security.filters.KaptchaFilter

```java
//自定义验证码认证
public class KaptchaFilter extends UsernamePasswordAuthenticationFilter {

    private static final String FORM_KAPTCHA_KEY = "kaptcha";
    private String kaptchaParameter = FORM_KAPTCHA_KEY;

    public String getKaptchaParameter() {
        return kaptchaParameter;
    }

    public void setKaptchaParameter(String kaptchaParameter) {
        this.kaptchaParameter = kaptchaParameter;
    }

    @Override
    public Authentication attemptAuthentication(HttpServletRequest request, HttpServletResponse response) throws AuthenticationException {
        if (!request.getMethod().equals("POST")) {
            throw new AuthenticationServiceException("Authentication method not supported: " + request.getMethod());
     qian   }
        //1.从请求中获取验证码
        String verifyCode = request.getParameter(getKaptchaParameter());
        //2.与session中验证码进行比较
        String sessionVerifyCode = (String) request.getSession().getAttribute("kaptcha");
        if (!ObjectUtils.isEmpty(verifyCode) && !ObjectUtils.isEmpty(sessionVerifyCode) &&
                verifyCode.equalsIgnoreCase(sessionVerifyCode)) {

            return super.attemptAuthentication(request, response);

        }

        throw new KaptchaNotMatchException("验证码不匹配");
    }
}
```

访问localhost:8080/login.html,输入验证码即可验证。

# 前后端分离验证码验证

项目：spring-security06（选spring-web spring-security）

依赖：

```xml
  <dependency>
            <groupId>com.github.penggle</groupId>
            <artifactId>kaptcha</artifactId>
            <version>2.3.2</version>
  </dependency>

```

配置：

```properties
# 应用服务 WEB 访问端口
server.port=8080

```

config.kaptchaConfig(验证码生成)

```java
@Configuration
public class kaptchaConfig {

    @Bean
    public Producer kaptcha() {
        Properties properties = new Properties();
        //验证码宽度
        properties.setProperty("kaptcha.image.width", "150");
        //验证码高度
        properties.setProperty("kaptcha.image.height", "50");
        //验证码字符串
        properties.setProperty("kaptcha.textproducer.char.string",
                "0123456789");
        //验证码长度
        properties.setProperty("kaptcha.textproducer.char.length", "4");
        Config config = new Config(properties);
        DefaultKaptcha defaultKaptcha = new DefaultKaptcha();
        defaultKaptcha.setConfig(config);
        return defaultKaptcha;
    }
}
```

config.SecurityConfig

```java
@Configuration
public class SecurityConfig extends WebSecurityConfigurerAdapter {

    //自定义内存数据源
    @Bean
    public UserDetailsService userDetailsService() {
        InMemoryUserDetailsManager inMemoryUserDetailsManager = new InMemoryUserDetailsManager();
        inMemoryUserDetailsManager.createUser(User.withUsername("root").password("{noop}123").roles("admin").build());
        return inMemoryUserDetailsManager;
    }

    @Override
    protected void configure(AuthenticationManagerBuilder auth) throws Exception {
        auth.userDetailsService(userDetailsService());
    }

    @Override
    @Bean
    public AuthenticationManager authenticationManagerBean() throws Exception {
        return super.authenticationManagerBean();
    }

    //配置
    @Bean
    public LoginKaptchaFilter loginKaptchaFilter() throws Exception {
        LoginKaptchaFilter loginKaptchaFilter = new LoginKaptchaFilter();
        //1.认证url
        loginKaptchaFilter.setFilterProcessesUrl("/doLogin");
        //2.认证接收参数
        loginKaptchaFilter.setUsernameParameter("uname");
        loginKaptchaFilter.setPasswordParameter("passwd");
        loginKaptchaFilter.setKaptchaParameter("kaptcha");
        //3.指定认证管理器
        loginKaptchaFilter.setAuthenticationManager(authenticationManagerBean());
        //指定认证成功处理
        loginKaptchaFilter.setAuthenticationSuccessHandler((req, resp, auth) -> {
            resp.sendRedirect("/index.html");
        });
        //指定认证失败处理
        loginKaptchaFilter.setAuthenticationFailureHandler((req, resp, ex) -> {
            resp.sendRedirect("/login.html");
        });
        return loginKaptchaFilter;
    }

    @Override
    protected void configure(HttpSecurity http) throws Exception {

        http.authorizeRequests()
                .mvcMatchers("/vc.jpg").permitAll()
                .anyRequest().authenticated()
                .and()
                .formLogin()
                .and()
                .exceptionHandling()
                .authenticationEntryPoint((req, resp, ex) -> {
                    resp.setContentType("application/json;charset=UTF-8");
                    resp.setStatus(HttpStatus.UNAUTHORIZED.value());
                    resp.getWriter().println("必须认证之后才能访问！");
                })
                .and()
                .logout()
                .and()
                .csrf().disable()
        ;
        http.addFilterAt(loginKaptchaFilter(), UsernamePasswordAuthenticationFilter.class);
    }
}

```

controller.TestController

```java
@Controller
public class TestController {

    @GetMapping("/test")
    public String test() {
        System.out.println("test ...");
        return "test ok!";
    }

}
```

controller.VerifyCodeController

```java
@RestController
public class VerifyCodeController {
    private final Producer producer;

    @Autowired
    public VerifyCodeController(Producer producer) {
        this.producer = producer;
    }

    @GetMapping("/vc.jpg")
    public String getVerifyCode(HttpSession session) throws IOException {
        // 1. 生成验证码
        String text = producer.createText();
        //2.放入session redis实现
        session.setAttribute("kaptcha", text);
        //3. 生成图片
        BufferedImage bi = producer.createImage(text);
        FastByteArrayOutputStream fos = new FastByteArrayOutputStream();
        ImageIO.write(bi, "jpg", fos);
        //4.返▣base64
        return Base64.encodeBase64String(fos.toByteArray());
    }
}
```

security.exception.KaptchaNotMatchException

```
public class KaptchaNotMatchException extends AuthenticationException {

    public KaptchaNotMatchException(String msg) {
        super(msg);
    }

    ;

    public KaptchaNotMatchException(String msg, Throwable cause) {
        super(msg, cause);
    }

    ;

}

```

security.filter

```java
@Configuration
public class SecurityConfig extends WebSecurityConfigurerAdapter {

    //自定义内存数据源
    @Bean
    public UserDetailsService userDetailsService() {
        InMemoryUserDetailsManager inMemoryUserDetailsManager = new InMemoryUserDetailsManager();
        inMemoryUserDetailsManager.createUser(User.withUsername("root").password("{noop}123").roles("admin").build());
        return inMemoryUserDetailsManager;
    }

    @Override
    protected void configure(AuthenticationManagerBuilder auth) throws Exception {
        auth.userDetailsService(userDetailsService());
    }

    @Override
    @Bean
    public AuthenticationManager authenticationManagerBean() throws Exception {
        return super.authenticationManagerBean();
    }

    //配置
    @Bean
    public LoginKaptchaFilter loginKaptchaFilter() throws Exception {
        LoginKaptchaFilter loginKaptchaFilter = new LoginKaptchaFilter();
        //1.认证ur1
        loginKaptchaFilter.setFilterProcessesUrl("/doLogin");
        //2.认证接收参数
        loginKaptchaFilter.setUsernameParameter("uname");
        loginKaptchaFilter.setPasswordParameter("passwd");
        loginKaptchaFilter.setKaptchaParameter("kaptcha");
        //3.指定认证管理器
        loginKaptchaFilter.setAuthenticationManager(authenticationManagerBean());
        //指定认证成功处理
        loginKaptchaFilter.setAuthenticationSuccessHandler((req, resp, auth) -> {
            Map<String, Object> result = new HashMap();
            result.put("msg", "登录成功");
            result.put("用户信息", auth.getPrincipal());
            resp.setContentType("application/json;charset=UTF-8");
            resp.setStatus(HttpStatus.OK.value());
            String s = new ObjectMapper().writeValueAsString(result);
            resp.getWriter().println(s);
        });
        //指定认证失败处理
        loginKaptchaFilter.setAuthenticationFailureHandler((req, resp, ex) -> {
            Map<String, Object> result = new HashMap();
            result.put("msg", "登录失败" + ex.getMessage());
            resp.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
            resp.setContentType("application/json;charset=UTF-8");
            String s = new ObjectMapper().writeValueAsString(result);
            resp.getWriter().println(s);
        });
        return loginKaptchaFilter;
    }

    @Override
    protected void configure(HttpSecurity http) throws Exception {

        http.authorizeRequests()
                .mvcMatchers("/vc.jpg").permitAll()
                .anyRequest().authenticated()
                .and()
                .formLogin()
                .and()
                .exceptionHandling()
                .authenticationEntryPoint((req, resp, ex) -> {
                    resp.setContentType("application/json;charset=UTF-8");
                    resp.setStatus(HttpStatus.UNAUTHORIZED.value());
                    resp.getWriter().println("必须认证之后才能访问！");
                })
                .and()
                .logout()
                .and()
                .csrf().disable()
        ;
        http.addFilterAt(loginKaptchaFilter(), UsernamePasswordAuthenticationFilter.class);
    }
}

```

http://localhost:8080/vc.jpg:

```text
/9j/4AAQSkZJRgABAgAAAQABAAD/2wBDAAgGBgcGBQgHBwcJCQgKDBQNDAsLDBkSEw8UHRofHh0aHBwgJC4nICIsIxwcKDcpLDAxNDQ0Hyc5PTgyPC4zNDL/2wBDAQkJCQwLDBgNDRgyIRwhMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjL/wAARCAAyAJYDASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwDU8L+GNAuPCejTTaHpkksljA7u9pGWZiikkkjkmm+KfBFpeaBNBoGjaLb37FSsj2ka4AOTg7TycY59a2PCP/Im6H/2D7f/ANFrW2KAPCk1O98KOIvFfgDSriAHH2mOxiTP/AlUofpxXZ6Frnwx13akem6Pazt/yxu7GKM59jjafwNeiFFdCjqGUjBBGQRXIa58LfC+t7n+xfYbhv8AlrZnZz7r939KAF1TTPDdhrmh6bD4X0aVtSkkBY2cY2Iibiw+Xnt+dbo8H+GP+hc0j/wBj/8Aia8n0/4e6zZeN20jTfFM0X2Gz+0RXHlE+V5jbdm3dgEgZJHXA4rpbzRviLpFq86+NbSRFwAs1soLknAUZU8kkAe5oA7YeDvDH/QuaR/4Axf/ABNPHg3wv/0Lej/+AMX/AMTXnOja78QtW3/2XrnhvVGjyWVchsBiucbV4yOtXG8b+O9HvAusaPos8KLvkW2uxG5UgkEEuegBJ46DnA5oA7weDPC3/Qt6P/4Axf8AxNPHgzwt/wBC1o//AIAxf/E1zen/ABV064jL3ekatbKhxJKkHnxIfQtGTg/hW/pvjvwrqhAtdesi56JJJ5TH/gL4NAFgeC/Cv/QtaN/4ARf/ABNOHgrwr/0LOjf+AEX/AMTVq513TLKaCK4vYUaYgJ84PU4H0GSBnpkgZ5Gbi3ts1l9sEyG327hIDkEUAZg8FeFP+hY0b/wAi/8AiacPBPhT/oWNF/8AACL/AOJrhtR+PHhq2jP2KC6unxlfl2A8HrnkcgD8c1Bpf7QGh3FwItQ066tUJwJUw6jnv0P86APQx4I8J/8AQr6L/wCAEX/xNPHgjwn/ANCvov8A4L4v/ia0NK1Sy1mwivtPnE9tKoZXAI4IBGQcEcEdavCgDDHgfwl/0K2if+C+L/4mnjwN4R/6FbRP/BfF/wDE1uCpBQB4h8ePDehaP4GsrjTNF06ynbUo0aS2tUjYr5UpwSoBxkDj2FFan7RX/JPrD/sKx/8AoqWigDQ8I/8AImaF/wBg+3/9FrW2KxfCP/ImaF/2D7f/ANFrW2KAHCnimiub8b+LY/Cmjh4k8/Uro+VZ24GS7nvjrgZH14HegChoc7trvjbW41DeVMlqgP8A0wj+Yfmxry7W7vxr4p0m61W6WW306HEiqcoGwSRgdzz+g9K9h8A+H77QfDZi1W4M99eTPdXIOCFd8ZGe/Tk+uak8fxhfBGoSIo/0eMyBAOuARj8jQB89+FdVvNLgvGs4HcMoE7xplvL/ALuf4ckA5HpWtH4U1rxHptxqlxeJCyuXeGTcDyQPlUZ/i2qB04HYV0PwOxJqV3b+WD8rNMGHDJgAfkw/Wuq+KWqahplkulaLp8Wy5XMskceSvJOD6eufUUAcd8ImvdO8QTL+9f5/LZVxtzkjk9eobtjgnrivWfHU3hzT9DnvdX0yyvJMYjWaBXYsenUZFcB8NNUtNGUadb2UZvjIRdSPMDtcfKR6jOM9Me9YfjPxXa+IPGM2nXEUzW0EwhgAKoqsThmbIyeOnTkDmgDzyMtf6uqxRmCOeXCxQ5AAJ+6P0H5V7wPBfim98JRw6R4q863lKyJBeQJwwIO7zV+YEEeh5Ga8u8cWf2HxJaz6bC8SbgsBTZkuhALYXjk4P419NeHRF/wj9iIQoQRAEL2b+IfXdmgDwaw8C6J4cmf/AITzTNUthu+W7t8S2Z54+ZBuXPoRWBpnha08a+MZbHw5aPBp0TkmV2LfJwBk++D+desfGrxC9p4eGk2j/vbobZV9V3KMD3yRVP4d/DWGTwhZ6rBqV/pesShj9ptJccbj8roflYAjpQB6l4c0K38OaFbaVbMzRQAgM3Vue/6D8K1xXn0fiTxJ4NJj8Y241HTNx261p8X+rXP/AC2iAyv1XI7c9a7nTtQs9Vso7ywuorm2kGUlicMp/EUAWxUgpop4oA8j/aL/AOSe2H/YVj/9FS0UftF/8k9sP+wrH/6KlooA0fCP/ImaF/2D7f8A9FrS+KbnWrTQJpvD9slxqAZQkbrkEE4PcduetHhD/kTNC/7B9v8A+i1rbFAHkol+Ml592G2tAe/7j+pY1reEPBevnxS/iDxjPFeXUMQS0xIG8s+u0AAYGcY7kn3r0cU8UAOFZXiq1a98L6hABlWizInd4wcuo9CVDAHsSDWsKSe3iu7eSCdA8Ui7WU9xQB8seDPF8nhPUpbjyDdBht2MxGOQ2fruVfw3ete16T8SND1vS7m51DyLbCMfLbDtt5Izj/ZIB9CD6iobf4O6Zb6ubsXbzwSkm4t541YSZwcgjG35gTx646Vk3HwQjubsE3pSPdhtmACP74X1I6rwM8ggcUAcX4As5/EfxKS6tYrgWccm9y7s5SMcBS/04Gew74rvtT+C9q15Pe25jcBnmwd5eQnJ27QQBgngg/wjIOTXf+GfCmm+GLIQWUCKxA3MMnnAzgkk4OM9f6Ct8UAfJPi7S9b0XVvsmqEtIXV1u2i2Z44Cn+FBzgce4BGB6l8HZfFMkrLetcyabuLqzHKhnIbPUcYD+vLqccV1fxE+Hdv4zit7iOQwXkBAMmWbMeeQF6bvf+fGN3wTolzoHh6OwunLyKxOWwW/Ejgnj8BgdqAPFvjXO83i+zXYXVSESMZG4g5Ygg4BO4Ke+Ywe9e9eFoEtfDGm26MriK3RC69HYD5m/E5P41X1Hwb4f1fURqGoaZFcXQUJvfJ4ByBjp1ras7WGytIrW3TZDEoRF9AKAJ8AjBGQeoNcZf8AgFrK9k1Xwdff2JqDndLbhd1pcn/bj7H/AGlwRXaCnigDjNM8fC2vo9I8XWJ0PU3O2OSRt1rcn1jl6f8AATgjIHJruFqnqOl2OsWMllqVpDdWsn3opkDA+/196uRRpDEkcaKiIAqqowAB0AoA8k/aM/5J7Yf9hWP/ANFS0Uv7Rn/JPbD/ALCsf/oqWigD53h8UeIbeGOGDXdTiijUIiJdyKqqBgAAHgAU/wD4S/xN/wBDFq3/AIGyf/FUUUAL/wAJf4m/6GLV/wDwNk/+Ko/4TDxP/wBDHq//AIHS/wDxVFFAB/wmPif/AKGPV/8AwOl/+Kpf+Ex8Uf8AQyax/wCB0v8A8VRRQAf8Jl4o/wChk1j/AMDpf/iqP+Ez8U/9DLrH/gdL/wDFUUUAL/wmnir/AKGXWf8AwPl/+Ko/4TTxV/0M2s/+B8v/AMVRRQAv/Ca+K/8AoZtZ/wDA+X/4qj/hNvFf/Qz61/4Hy/8AxVFFAB/wm3iz/oaNa/8AA+X/AOKpf+E38Wf9DRrX/gwl/wDiqKKAD/hOPFv/AENGt/8Agwl/+Ko/4Tjxd/0NOt/+DCX/AOKoooAX/hOfF3/Q1a3/AODCX/4qj/hOvF//AENWuf8Agwl/+KoooAqal4l13WLdbfVNb1K+gVw6x3V08qhsEZAYkZwSM+5ooooA/9k=
```

复制到base64解密

```html
https://www.toolhelper.cn/Image/Base64ToImage
```

http://localhost:8080/doLogin

```json
{
    "uname":"root",
    "passwd":"123",
    "kaptcha":"1347"
}
```

结果：

```json
{
	"msg": "登录成功",
	"用户信息": {
		"password": null,
		"username": "root",
		"authorities": [
			{
				"authority": "ROLE_admin"
			}
		],
		"accountNonExpired": true,
		"accountNonLocked": true,
		"credentialsNonExpired": true,
		"enabled": true
	}
}
```

# 密码加密

## Hash加密

最早我们使用类似SHA-256、SHA-512、MD5等这样的单向Hash算法。用户注册成功

后，保存在数据库中不再是用户的明文密码，而是经过SHA-256加密计算的一个字行串，

当用户进行登录时，用户输入的明文密码用SHA-256进行加密，加密完成之后，再和存诸

在数据库中的密码进行比对，进而确定用户登录信息是否有效。如果系统遭遇攻击，最多

也只是存储在数据库中的密文被泄漏。

这样就绝对安全了吗？由于彩虹表这种攻击方式的存在以及随着计算机硬件的发展，每秒

执行数十亿次HASH计算己经变得轻轻松松，这意味着即使给密码加密加盐也不再安全。

## 单向自适应加密

### PasswordEncoder

通过对认证流程源码分析得知，实际密码比较是由PasswordEncoder:完成的，因此只需
用PasswordEncoder不同实现就可以实现不同方式加密。

```java
public interface PasswordEncoder{
  String encode(CharSequence rawPassword);
  boolean matches(CharSequence rawPassword,String encodedPassword);
  default boolean upgradeEncoding(String encodedPassword){
        return false;
  }
}
```

- encode用米进行明文加密的
- matches用来比较密码的方法
- upgradeEncoding用来给密码进行升级的方法

<br/>

![screen-capture](420452f468d0ba9dd9743b041c7da87d.png)

<br/>

![screen-capture](8e9283f5ce8a1bea9e05eeba9ee996e7.png)

<br/>

![screen-capture](0354ee5b664be550ea824b47e00e9eee.png)

<br/>

![screen-capture](424a0539b2c0c63451cf407acfc2bc0a.png)

<br/>

![screen-capture](f1279b74a479cdfca036409edfc064fe.png)

<br/>

![screen-capture](4d0d93058794f39f6730d49a6b5b3408.png)

<br/>

![screen-capture](bc84c68725901e7c14eaa2b15fa6aaf0.png)

<br/>

<br/>

![screen-capture](1cbfffb266bf7aa654fdc26323142c70.png)

具体实现：

![screen-capture](bd37ef033c9f076d510be63eaa725e1b.png)

![screen-capture](816a06f3f9ad4ce7bb277257a84d7c38.png)

点最左边跳过出去该方法，再继续往下：

![screen-capture](2b045b24a9e78fd4d26b0ac0448261ca.png)

![screen-capture](41375cbd72556d838348257acb135d31.png)

![screen-capture](ca0826fbc2739fb11f24e079589e1775.png)

代码：

```java
 private class DefaultPreAuthenticationChecks implements UserDetailsChecker {
        private DefaultPreAuthenticationChecks() {
        }

        public void check(UserDetails user) {
            if (!user.isAccountNonLocked()) { //当前用户是否被锁定
                AbstractUserDetailsAuthenticationProvider.this.logger.debug("Failed to authenticate since user account is locked");
                throw new LockedException(AbstractUserDetailsAuthenticationProvider.this.messages.getMessage("AbstractUserDetailsAuthenticationProvider.locked", "User account is locked"));
            } else if (!user.isEnabled()) { //当前用户是否被禁用
                AbstractUserDetailsAuthenticationProvider.this.logger.debug("Failed to authenticate since user account is disabled");
                throw new DisabledException(AbstractUserDetailsAuthenticationProvider.this.messages.getMessage("AbstractUserDetailsAuthenticationProvider.disabled", "User is disabled"));
            } else if (!user.isAccountNonExpired()) { //当前用户是否过期
                AbstractUserDetailsAuthenticationProvider.this.logger.debug("Failed to authenticate since user account has expired");
                throw new AccountExpiredException(AbstractUserDetailsAuthenticationProvider.this.messages.getMessage("AbstractUserDetailsAuthenticationProvider.expired", "User account has expired"));
            }
        }
    }
```

![screen-capture](6c9ae4673d2f84661160467367717fb9.png)

<br/>

![screen-capture](b1385559624684e5597bcc0cc33c8827.png)

<br/>

![screen-capture](816a06f3f9ad4ce7bb277257a84d7c38.png)

左边第一个：

![screen-capture](d7299527f00bace219ff9660981922ca.png)

转为为明文密码和UserDetailsService的比较

![screen-capture](6e12341edc4863ad567307101e5bda8e.png)

<br/>

![screen-capture](3782b7b5cb9161513985ac57e0672455.png)

<br/>

![screen-capture](a48fb02a9a09c0de658b28169b38e0d2.png)

<br/>

![screen-capture](b7eed0b93a740bb7d4f1a73acd85d3da.png)

<br/>

![screen-capture](c232ba8531c6aabf043dafe1415fe5ef.png)

返回断点，查看默认实现方式

![screen-capture](67fb43fc7c7e36c9315bd25cf0a6b471.png)

进入断点

![screen-capture](26376a4875a2db35b36d9703ad35057d.png)

<br/>

![screen-capture](190963c6c23a23c057f1ae78461361bd.png)

继续进入matches()

![screen-capture](935590bf25152d83ef888b98a87b031c.png)

<br/>

![screen-capture](b2baca16a67089c4d501d6caee5c5938.png)

<br/>

![screen-capture](c9dc9318e307f8c4699397576b6aed1b.png)

方法实现

![screen-capture](49c6c8bc093a04042306972cd533f74d.png)

<br/>

![screen-capture](1af5b0540fcf05af15db60adce77858b.png)

<br/>

![screen-capture](3c902eca483b1fe891335619b5eb330f.png)

<br/>

如果不是明文加密，例如：

![screen-capture](15bfe574955564827bb6a10e81725a13.png)

<br/>

![screen-capture](62e55f203d2407d20b31bdba318608ac.png)

<br/>

![screen-capture](b0185c54b208711223f001353a05e616.png)

<br/>

![screen-capture](29703055649ed61873197b7e396542ab.png)

<br/>

![screen-capture](db062e62d73fb3af3f9f581e12e261ec.png)

<br/>

<br/>

<br/>

<br/>

# DelegatingPasswordEncoder

根据上面PasswordEncoder的介绍，可能会以为Spring security中默认的密码加密方案应该是四种自适应单向加密函数中的一种，其实不然，在spring Security5.0之后，默认的密码
加密方案其实是DelegatingPasswordEncoder。从名字上来看，DelegatingPaswordEncoder是一个代理类，而并非一种全新的密码加密方案，DeleggtinePasswordEncoder主要用来代理上面介绍的不同的密码加密方案。为什么采DelegatingPasswordEncoder而不是某一个具体加密方式作为默认的密码加密方案呢？主要考虑了如下两方面的因素：

- 兼容性：使用DelegatingPasswrordEncoder可以帮助许多使用l旧密码加密方式的系统顺
利迁移到Spring security中，它允许在同一个系统中同时存在多种不同的密码加密方
案。
- 便捷性：密码存储的最佳方案不可能一直不变，如果使用DelegatingPasswordEncoderf作
为默认的密码加密方案，当需要修改加密方案时，只需要修改很小一部分代码就可以实
现。

源码：

![screen-capture](28553dc08e678ab6f662e772348dc386.png)

<br/>

简化代码：

```java
@Order(100)
public abstract class WebSecurityConfigurerAdapter implements WebSecurityConfigurer<WebSecurity> {


    static class LazyPasswordEncoder implements PasswordEncoder {
        private ApplicationContext applicationContext;
        private PasswordEncoder passwordEncoder;

        LazyPasswordEncoder(ApplicationContext applicationContext) {
            this.applicationContext = applicationContext;
        }

        public String encode(CharSequence rawPassword) {
            return this.getPasswordEncoder().encode(rawPassword);
        }

        public boolean matches(CharSequence rawPassword, String encodedPassword) {
            return this.getPasswordEncoder().matches(rawPassword, encodedPassword);
        }

        public boolean upgradeEncoding(String encodedPassword) {
            return this.getPasswordEncoder().upgradeEncoding(encodedPassword);
        }

  //3      private PasswordEncoder getPasswordEncoder() {
            if (this.passwordEncoder != null) {
                return this.passwordEncoder;
            } else {
  //4              PasswordEncoder passwordEncoder = (PasswordEncoder)this.getBeanOrNull(PasswordEncoder.class);
                if (passwordEncoder == null) {
  //7                  passwordEncoder = PasswordEncoderFactories.createDelegatingPasswordEncoder();
                }

  //8              this.passwordEncoder = passwordEncoder;
  /              return passwordEncoder;
            }
        }

  //5      private <T> T getBeanOrNull(Class<T> type) {
            try {
                return this.applicationContext.getBean(type);
            } catch (NoSuchBeanDefinitionException var3) {
  //6              return null;
            }
        }

        public String toString() {
            return this.getPasswordEncoder().toString();
        }
    }

 //1   static class DefaultPasswordEncoderAuthenticationManagerBuilder extends AuthenticationManagerBuilder {
//2      private PasswordEncoder defaultPasswordEncoder;

        DefaultPasswordEncoderAuthenticationManagerBuilder(ObjectPostProcessor<Object> objectPostProcessor, PasswordEncoder defaultPasswordEncoder) {
            super(objectPostProcessor);
            this.defaultPasswordEncoder = defaultPasswordEncoder;
        }

        public InMemoryUserDetailsManagerConfigurer<AuthenticationManagerBuilder> inMemoryAuthentication() throws Exception {
            return (InMemoryUserDetailsManagerConfigurer)super.inMemoryAuthentication().passwordEncoder(this.defaultPasswordEncoder);
        }

        public JdbcUserDetailsManagerConfigurer<AuthenticationManagerBuilder> jdbcAuthentication() throws Exception {
            return (JdbcUserDetailsManagerConfigurer)super.jdbcAuthentication().passwordEncoder(this.defaultPasswordEncoder);
        }

        public <T extends UserDetailsService> DaoAuthenticationConfigurer<AuthenticationManagerBuilder, T> userDetailsService(T userDetailsService) throws Exception {
            return (DaoAuthenticationConfigurer)super.userDetailsService(userDetailsService).passwordEncoder(this.defaultPasswordEncoder);
        }
    }
  }
```

<br/>

<br/>

<br/>

![screen-capture](11ccce79ffb6e191ef448ed7d0b0363d.png)

<br/>

![screen-capture](54f2eab987eea0d65f15ae3e64300786.png)

<br/>

<br/>

![screen-capture](87a265cdb6c3213a7cc0b87d8206684c.png)

<br/>

![screen-capture](ed8be2ad4df5a3e58345360c7cbb1df0.png)

<br/>

![screen-capture](ec51900bcf5f011823dfb3c235ac91db.png)

<br/>

就是说默认在WebSecurity在继承WebSecurityConfigurerAdapter类时，会执行WebSecurityConfigurerAdapter类的static方法和类，会加载DefaultPasswordEncoderAuthenticationManagerBuilder类，这个类有个私有属性passwordEncoder，会调用passwordEncoder的构造方法，在passwordEncoder的构造方法中，先在applicationContext域找PasswordEncoder类的实例，找不到，返回 PasswordEncoder passwordEncoder = null ,调用PasswordEncoderFactories.createDelegatingPasswordEncoder()方法，默认生成bcrypt加密的passwordEncoder 。

<br/>

如果自定义了passwordEncoder 实例，那就不用默认的了，因为可以在applicationContext域找到PasswordEncoder。

<br/>

## 自定义加密（方式一）

在测试主类加入代码

```java
@SpringBootTest
class SpringSecurity07ApplicationTests {

    @Test
    void contextLoads() {
        BCryptPasswordEncoder bCryptPasswordEncoder = new BCryptPasswordEncoder();
        String encode = bCryptPasswordEncoder.encode("123");
        System.out.println(encode);
    }

}
```

得到bcrypt加密的结果

```java
$2a$10$zE.1gzN1qFouQLhF5fbxkOX1slP460jqzdeARskRONQRj0z2Uq7i6
```

config.WebSecurity修改加密方式

```java
 inMemoryUserDetailsManager.createUser(User.withUsername("root").password("{bcrypt}$2a$10$zE.1gzN1qFouQLhF5fbxkOX1slP460jqzdeARskRONQRj0z2Uq7i6").roles("admin").build());
```

重新验证即可

## 自定义加密（方式二）

![screen-capture](a8c6bfa2cdc764d12973abea0860bfc8.png)

密码升级

MyUserDetailService 实现UserDetailsService, UserDetailsPasswordService，重写UserDetailsPasswordService的updatePassword()方法

```java
  @Override  //默认使用DelegatingPasswordEncoder默认使用相当最安全密码加密Bcrypt--->cxx
    public UserDetails updatePassword(UserDetails user, String newPassword) {
        Integer result = userDao.updatePassword(user.getUsername(), newPassword);
        if (result == 1) {
            ((User) user).setPassword(newPassword);
        }
        return user;
    }
```

# RememberMe

具体的实现思路就是通过Cookie来记录当前用户身份。当用户登录成功之后，会通过一定算法，将用户信息、时间戳等进行加密，加密完成后，通过响应头带回前端存储在cookie中，当浏览器会话过期之后，如果再次访问该网站，会自动将Cook中的信息发送给服务器，服务器对Cookier中的信息进行校验分析，进而确定出用户的身份，Cookie中所保存的用户信息也是有时效的，例如三天、一周等。

<br/>

项目：spring-security08（Spring Web、Spring Security）

> 配置：

```java
# 应用服务 WEB 访问端口
server.port=8080
#修改服务器端会话
server.servlet.session.timeout=1 //一分钟之内都可以登录
```

> Security.SecurityConfig

```java
@Configuration
public class SecurityConfig extends WebSecurityConfigurerAdapter {

    @Bean
    public UserDetailsService userDetailsService() {
        InMemoryUserDetailsManager inMemoryUserDetailsManager = new InMemoryUserDetailsManager();
        inMemoryUserDetailsManager.createUser(User.withUsername("root").password("{noop}123").roles("ADMIN").build());
        return inMemoryUserDetailsManager;
    }

    @Override
    protected void configure(AuthenticationManagerBuilder auth) throws Exception {
        auth.userDetailsService(userDetailsService());
    }

    @Override
    protected void configure(HttpSecurity http) throws Exception {
        http.authorizeRequests()
                .anyRequest().authenticated()
                .and()
                .formLogin()
                .and()
                .csrf().disable();
    }

}

```

> controller.IndexController

```java
@RestController
public class IndexController {

    @GetMapping("/index")
    public String index() {
        System.out.println("index ok");
        return "index ok!";
    }

}
```

<br/>

<br/>

### 基本使用

**开启记住我(一分钟后不需要认证)**

```java
 @Override
    protected void configure(HttpSecurity http) throws Exception {
        http.authorizeRequests()
                .anyRequest().authenticated()
                .and()
                .formLogin()
                .and()
                .rememberMe() //开启记住我功能
                .and()
                .csrf().disable();
    }

```

## 原理分析

### RememberMeAuthenticationFilter

![screen-capture](affea46316f2b5034703eafb5f1601af.png)

从上图中，当在SecurityConfig配置中开启了"记住我"功能之后，在进行认证时如果勾选了"记住我“选项，此时打开浏览器控制台，分析整个登录过程。首先当我们登录时，在登录请求中多了一个RememberMe的参数。

![screen-capture](aac9f980c128f1c1c328679e0f79fbfa.png)

很显然，这个参数就是告诉服务器应该开启RememberMe功能的。如果自定义登录页面开启RememberMe功能应该多加入一个一样的请求参数就可以啦。该请求会被RememberMeAuthenticationFilter进行拦截然后自动登录具体参见源码：

![screen-capture](b7f9ae890df0550cfb1acd46212ffc2f.png)

- (1)请求到达过滤器之后，首先判断SecurityContextHolder中是否有值，没值的话表示用户尚未登录，此时调用autoLogin方法进行自动登录。
- (2)当自动登录成功后返回的rememberMeAuth不为null时，表示自动登录成功，此时调用authenticate方法对key进行校验，并且将登录成功的用户信息保存到SecurityContextHolder对象中，然后调用登录成功回调，并发布登录成功事件。需要注意的是，登录成功的回调并不包含RememberMeServices中的loginSuccess方法。
- (3)如果自动登录失败，则调用remenberMeServices.loginFail方法处理登录失败回调。onUnsuccessfulAuthentication和onSuccessfulAuthentication都是该过滤器中定义的空方法，并没有任何实现这就是RememberMeAuthenticationFilter过滤器所做的事情，成功将RememberMeServices的服务集成进来。

### RememberMeServices

这里一共定义了三个方法：

1.autoLogin方法可以从请求中提取出需要的参数，完成自动登录功能。

2.loginFail方法是自动登录失败的回调。

3.loginSuccess方法是自动登录成功的回调。

![screen-capture](535677e21f394a1009ea474cfc052d44.png)

### TokenBasedRememberMeServices

在开启记住我后如果没有加入额外配置默认实现就是由TokenBasedRememberMeServices进行的实现。查看这个类源码中processAutoLoginCookie方法实现：

![screen-capture](90b21dcf1b202961c9d0e1015f7664c0.png)

processAutoLoginCookie方法主要用来验证Cookie中的令牌信息是否合法：

1.首先判断cookieTokens长度是否为了，不为了说明格式不对，则直接抛出异常。

2.从cookieTokens数组中提取出第1项，也就是过期时间，判断令牌是否过期，如果己经过期，则抛出异常

3.根据用户名(cookieTokens数组的第一项)查询出当前用户对象。

4.调用makeTokenSignature方法生成一个签名，签名的生成过程如下：首先将用户名、令牌过期时间、用户密码以及ky组成一个宇符串，中间用“：”隔开，然后通过MD5消息摘要算法对该宇符串进行加密，并将加密结果转为一个字符串返回。

5.判断第4步生成的签名和通过Cookie传来的签名是否相等（即cookieTokens数组的第2项)，如果相等，表示令牌合法，则直接返回用户对象，否则抛出异常。

![screen-capture](646c7ae74742001c57aa753e9030f487.png)

<br/>

1.在这个回调中，首先获取用户经和密码信息，如果用户密码在用户登录成功后从success

fulAuthentication对象中擦除，则从数据库中重新加载出用户密码。

2.计算出令牌的过期时间，令牌默认有效期是两周。

3.根据令牌的过期时间、用户名以及用户密码，计算出一个签名。

4.调用setCookie方法设置Cookie,.第一个参数是一个数组，数组中一共包含三项。用户

名、过期时间以及签名，在setCookie方法中会将数组转为字符串，并进行Base64编码后

响应给前端。

### 总结

当用户通过用户名/密码的形式登录成功后，系统会根据用户的用户名、密码以及令牌的过

期时间计算出一个签名，这个签名使用MD5消息摘要算法生成，是不可逆的。然后再将用

户名、令牌过期时间以及签名拼接成一个字符串，中间用“：”隔开，对拼接好的字符串进

行Bas64编码，然后将编码后的结果返回到前端，也就是我们在浏览器中看到的令牌。当

会话过期之后，访问系统资源时会自动携带上Cookie中的令牌，服务端拿到Cookier中的

令牌后，先进行Bae64解码，解码后分别提取出令牌中的三项数据：接着根据令牌中的数

据判断令牌是否已经过期，如果没有过期，则根据令牌中的用户名查询出用户信息：接着

再计算出一个签名和令牌中的签名进行对比，如果一致，表示会牌是合法令牌，自动登录

成功，否则自动登录失败。

<br/>

![screen-capture](86cebbe56643779767bb1be0e3fe432e.png)

<br/>

<br/>

![screen-capture](09c6ea98b3819033b82e2c1c0113cfb7.png)

<br/>

## 内存令牌（程序重启Token失效）

先看调用过程

![screen-capture](45e428093c10159e4d39953658213127.png)

![screen-capture](5cd1813b87b5ed002d04b68ecc38775e.png)

![screen-capture](1471a148e362451c7567773f143835ad.png)

![screen-capture](79b4fe710dcca6e52505eb5012722a54.png)

![screen-capture](56d9afa8c7ae99441c42ddac9589e8b4.png)

已经实例化了PersistentTokenBasedRememberMeServices对象

![screen-capture](8c873b9f8de4a4e6fead60f4a7366371.png)

<br/>

![screen-capture](da0535f7e920ffc9b412caa05f8164d9.png)

另一种

![screen-capture](68d3f7080288ab185d58dffb3239db4d.png)

<br/>

<br/>

### PersistentTokenBasedRememberMeServices

<br/>

![screen-capture](a0a87c98a081c2bada7ab647f1eb0a81.png)

先看参数调用的方法

![screen-capture](39bc4c85a6a71a0c563aa526136c11ef.png)

再看构造函数

![screen-capture](2507fe620b23212fcd01759a6312ea51.png)

到这儿，就是生成一个persistentToken。

![screen-capture](94cb78ff62f825af7b21629a3a51000c.png)

先看tokenRepository类

![screen-capture](700d2635030a0ef0c6d9993c6f73e2f8.png)

再看createNewToken方法

![screen-capture](50b5fdc08fbb69881eb0e040bd49e66a.png)

默认找内存实现

![screen-capture](2dad1ffc4a6a33a71d1a945946770101.png)

<br/>

具体实现

![screen-capture](a65432c8810fa8ed5b24e2c9436a5fad.png)

创建完，返回原方法，继续执行

![screen-capture](22b5a898fc30bddc181995b3050898b9.png)

从这里，可以看出，是通过Series找到Token。自动登录应该就是传入两个参数，一个是Series，一个是Token，通过传入的Series，在内存中寻找对应的Token和传入的Token作比较。

具体实现

![screen-capture](a7f17f8cfb0851b71edc493017290d7a.png)

进入getTokenForSeries方法

![screen-capture](f72b531be6fa4378468b7ed59f027224.png)

<br/>

![screen-capture](1d588ec833c537d6124c23f193d0d890.png)

<br/>

具体实现

![screen-capture](5517e9e86985d55c8cbdbf8f5e479c14.png)

也就是通过传入的Series，在内存中寻找对应的Token并返回。

继续看原方法

![screen-capture](d984491fbdaa36ce203a8236730a341b.png)

进入删除Token的方法

![screen-capture](d7c07c61b0a86090de4448394a341b2f.png)

![screen-capture](2366aa7d90bae09d0268c5d11d16a7f6.png)

进入具体实现

![screen-capture](e3a6a2418d7df0cbeea98c853ee49296.png)删除完，继续看原方法

![screen-capture](7cb36132d91724820367920bd89c9b0c.png)

进入方法

![screen-capture](cc76750f0da0a40eade6f54c552bf60f.png)

![screen-capture](cee0b086bdc504cd107ee639ff9c0962.png)

具体实现

![screen-capture](ebc914e1a5f9592718749dcc80bfcdc2.png)

返回原方法

![screen-capture](a830a561e2b87ce861615267010511b9.png)

进入方法

![screen-capture](132d0850ce00e872a145332c1e6e72e7.png)

具体实现

![screen-capture](cef9e756e463efd545901211912430e4.png)

<br/>

![screen-capture](1382c5a60cf3f3de7e7602a9f144263a.png)

<br/>

<br/>

![screen-capture](0a4946e88d0a95da29be7170a2cd74e1.png)

<br/>

1.不同于TokonBasedRemornberMeServices中的processAutologinCookie方法，这里cookieTokens数组的长度为2，第一项是series,第二项是token。

2.从cookieTokens数组中分到提取出series和token.然后根据series去内存中查询出个PersistentRememberMeToken对象。如果查询出来的对象为null,表示内存中并没有series对应的值，本次自动登

录失败。如果查询出来的token和从cookieTokens中解析出来的tokn不相同，说明自动登录会牌已经泄漏（恶意用户利用令牌登录后，内存中的token变了)，此时移除当前用户的所有自动登录记录并抛

出异常。

3.根据数据库中查询出来的结果判断令牌是否过期，如果过期就抛出异常。

4.生成一个新的PersistentRememberMeToken对象，用户名和series不变，token重新生成，date也使用当前时间。newToken生成后，根据series去修改内存中的token和date(即每次自动登录后都会

产生新的token和date)

5.调用addCookie方法添加Cookie,在addCookie方法中，会调用到我们前面所说的setCookie方法，但是要注意第一个数组参数中只有两项：series和token(即返回到前端的令牌是通过对series和toke

n进行Base64编码得到的)

6.最后将根据用户名查询用户对象并返回。

## 持久化令牌

上述配置程序（基于内存实现）关闭或重启，Token都会失效。

PersistentTokenRepository还有一个实现类，基于数据库实现

![screen-capture](eabb985d1802ea382f2be5848dafac3e.png)

依赖（项目不变）

```xml
        <dependency>
            <groupId>com.alibaba</groupId>
            <artifactId>druid</artifactId>
            <version>1.1.20</version>
        </dependency>

        <dependency>
            <groupId>mysql</groupId>
            <artifactId>mysql-connector-java</artifactId>
        </dependency>

        <dependency>
            <groupId>org.mybatis.spring.boot</groupId>
            <artifactId>mybatis-spring-boot-starter</artifactId>
            <version>2.3.0</version>
        </dependency>
```

配置

```properties
# 应用服务 WEB 访问端口
server.port=8080
#修改服务器端会话
server.servlet.session.timeout=1
#spring.thymeleaf.cache=false
spring.datasource.type=com.alibaba.druid.pool.DruidDataSource
spring.datasource.driver-class-name=com.mysql.cj.jdbc.Driver
spring.datasource.url=jdbc:mysql://localhost:3306/security?characterEncoding=UTF-8
spring.datasource.username=root
spring.datasource.password=hsxsdm
mybatis.mapper-locations=classpath:mapper/*.xml
mybatis.type-aliases-package=com.entity
```

构造注入数据源

![screen-capture](021e826819c8d32a31a449ef10347d1d.png)

使用数据库方式实现

<br/>

![screen-capture](394deb37c7d5ec8be30d286e73b8b682.png)

<br/>

这里有个注意点，就是这个JdbcTokenRepositoryImpl类里数据库表的创建

<br/>

![screen-capture](fcca6223348dbd7182759255960c2b7b.png)

<br/>

```mysql
create table persistent_logins (username varchar(64) not null, series varchar(64) primary key, token varchar(64) not null, last_used timestamp not null)
```

<br/>

运行程序，选择记住我，查看数据库

![screen-capture](d5b594bc9e6227a249e0a1fecb235329.png)

第二种

<br/>

![screen-capture](006f3698ff3f70e75f7bc75a7f7798fb.png)

<br/>

运行程序，选择记住我，查看数据库

<br/>

![screen-capture](f0a6f4eefab27adffeb8e4889a356d76.png)

<br/>

## 自定义记住我

AbstractUserDetailsAuthenticationProvider类中authenticate方法在最后认证成功之后实现了记住我功能，但是查看源码得知如果开启记住我，必须进行相关的设置

### 传统web开发

项目：spring-security09（Thymeleaf,Sercurity）

配置

```properties
# 应用服务 WEB 访问端口
server.port=8080
#thymeleaf配置
spring.thymeleaf.cache=false
#thymeleaf默认配置
spring.thymeleaf.prefix=classpath:/templates/
spring.thymeleaf.suffix=.html
spring.thymeleaf.encoding=UTF-8
spring.thymeleaf.mode=HTML

```

config.SecurityConfig

```java
@Configuration
public class SecurityConfig extends WebSecurityConfigurerAdapter {

    //自定义数据源
    @Bean
    public UserDetailsService userDetailsService() {
        InMemoryUserDetailsManager inMemoryUserDetailsManager = new InMemoryUserDetailsManager();
        inMemoryUserDetailsManager.createUser(User.withUsername("root").password("{noop}123").roles("admin").build());
        return inMemoryUserDetailsManager;
    }

    @Override
    protected void configure(AuthenticationManagerBuilder auth) throws Exception {
        auth.userDetailsService(userDetailsService());
    }

    @Override
    protected void configure(HttpSecurity http) throws Exception {
        http.authorizeRequests()
                .mvcMatchers("/login.html").permitAll()
                .anyRequest().authenticated()
                .and().formLogin()
                .loginPage("/login.html").loginProcessingUrl("/doLogin")
                .usernameParameter("uname").passwordParameter("passwd")
                .defaultSuccessUrl("/test").and()
                .rememberMe().and().csrf().disable();
    }
}

```

config.WebConfig

```java
@Configuration
public class WebConfig implements WebMvcConfigurer {

    @Override
    public void addViewControllers(ViewControllerRegistry registry) {
        //localhost:8080/login.html --> 找templates下的login
        registry.addViewController("login.html").setViewName("login");
    }
}
```

controller.TestController

```java
@RestController
public class TestController {

    @GetMapping("/test")
    public String test(HttpServletRequest request) {
        System.out.println("test ok");
        return "test ok";
    }

}
```

templates.login.html

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>登陆页面</title>
</head>
<body>
<h1>用户登录</h1>
<form method="post" th:action="@{/doLogin}">
    用户名：<input name="uname" type="text">
    密码：<input name="passwd" type="text">
    记住我：<input name="remember-me" type="checkbox">
    <input type="submit" value="登录">
</form>
<h3>
    <div th:text="${session.SPRING_SECURITY_LAST_EXCEPTION}"></div>
</h3>
</body>
</html>
```

### 前后端分离

项目：spring-security10（Security）

配置

```xml
# 应用服务 WEB 访问端口
server.port=8080
```

controller.TestController

```java
@RestController
public class TestController {

    @GetMapping("/test")
    public String test() {
        System.out.println("test ...");
        return "test ok!";
    }

}
```

config.MyPersistentTokenBasedRememberMeService

```java
/**
 * 自定义记住我 Service 实现类
 */
public class MyPersistentTokenBasedRememberMeService extends PersistentTokenBasedRememberMeServices {
    public MyPersistentTokenBasedRememberMeService(String key, UserDetailsService userDetailsService, PersistentTokenRepository tokenRepository) {
        super(key, userDetailsService, tokenRepository);
    }

    /**
     * 自定义前后端分离获取 remember-me 方式
     */

    @Override
    protected boolean rememberMeRequested(HttpServletRequest request, String parameter) {
        String paramValue = request.getAttribute(parameter).toString();
        if (paramValue != null) {
            if (paramValue.equalsIgnoreCase("true") || paramValue.equalsIgnoreCase("on") ||
                    paramValue.equalsIgnoreCase("yes") || paramValue.equalsIgnoreCase("1")) {
                return true;
            }
        }
        return false;
    }
}

```

config.LoginFilter

```java
/**
 * 自定义前后端分离认证Filter
 */
public class LoginFilter extends UsernamePasswordAuthenticationFilter {
    @Override
    public Authentication attemptAuthentication(HttpServletRequest request, HttpServletResponse response) throws AuthenticationException {
        //1.判断是否是Post方式请求
        if (!request.getMethod().equals("POST")) {
            throw new AuthenticationServiceException("Authentication method not supported:" + request.getMethod());
        }
        //2,判断是否是json格式请求类型
        if (request.getContentType().equalsIgnoreCase(MediaType.APPLICATION_JSON_VALUE)) {
            //3.从json数据中获取用户输入用户名和密码进行认证{"uname":"xxx","password":"kx","remember-me":"true")
            try {
                Map<String, String> userInfo = new ObjectMapper().readValue(request.getInputStream(), Map.class);
                String username = userInfo.get(getUsernameParameter());
                String password = userInfo.get(getPasswordParameter());
                String rememberValue = userInfo.get(AbstractRememberMeServices.DEFAULT_PARAMETER);
                if (!ObjectUtils.isEmpty(rememberValue)) {
                    request.setAttribute(AbstractRememberMeServices.DEFAULT_PARAMETER, rememberValue);
                }
                System.out.println("用户名：" + username + "密码：" + password + "是否记住我" + rememberValue);

                UsernamePasswordAuthenticationToken authRequest = new UsernamePasswordAuthenticationToken(username, password);
                setDetails(request, authRequest);
                return this.getAuthenticationManager().authenticate(authRequest);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return super.attemptAuthentication(request, response);
    }

}

```

config.SecurityConfig

```java
@Configuration
public class SecurityConfig extends WebSecurityConfigurerAdapter {


    //内存
    @Bean
    public UserDetailsService userDetailsService() {
        InMemoryUserDetailsManager inMemoryUserDetailsManager = new InMemoryUserDetailsManager();
        inMemoryUserDetailsManager.createUser(User.withUsername("root").password("{noop}123").roles("admin").build());
        return inMemoryUserDetailsManager;
    }


    @Override
    protected void configure(AuthenticationManagerBuilder auth) throws Exception {
        auth.userDetailsService(userDetailsService());
    }

    @Override
    @Bean
    public AuthenticationManager authenticationManagerBean() throws Exception {
        return super.authenticationManagerBean();
    }

    //自定义filter交给工厂管理
    @Bean
    public LoginFilter loginFilter() throws Exception {
        LoginFilter loginFilter = new LoginFilter();
        loginFilter.setFilterProcessesUrl("/doLogin");
        loginFilter.setUsernameParameter("uname");//指定接收json用户名key
        loginFilter.setPasswordParameter("passwd");//指定接收json密码key
        loginFilter.setRememberMeServices(rememberMeServices());//设置登陆成功后再登录的验证
        //调用authenticationManagerBean发方法，会返回父类的authenticationManager实例
        loginFilter.setAuthenticationManager(authenticationManagerBean());
        //认证成功处理
        loginFilter.setAuthenticationSuccessHandler((req, resp, authentication) -> {
            Map<String, Object> result = new HashMap<String, Object>();
            result.put("msg", "登录成功");
            result.put("用户信息", authentication.getPrincipal());
            resp.setContentType("application/json;charset=UTF-8");
            resp.setStatus(HttpStatus.OK.value());
            String s = new ObjectMapper().writeValueAsString(result);
            resp.getWriter().println(s);
        });
        //认证失败处理
        loginFilter.setAuthenticationFailureHandler((req, resp, ex) -> {
            Map<String, Object> result = new HashMap<String, Object>();
            result.put("msg", "登录失败：" + ex.getMessage());
            resp.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
            resp.setContentType("application/json;charset=UTF-8");
            String s = new ObjectMapper().writeValueAsString(result);
            resp.getWriter().println(s);
        });

        return loginFilter;
    }

    @Override
    protected void configure(HttpSecurity http) throws Exception {

        http.authorizeHttpRequests()
                .anyRequest().authenticated()//所有请求必须认证
                .and()
                .formLogin()
                .and()
                .rememberMe() //开启记住我 cookie进行实现1.认证成功保存记住我cookie到客户端 2.只有cookie写入客户端成功才能实现自动登录功能
                .rememberMeServices(rememberMeServices()) //第一次登录
                .and()
                .exceptionHandling()
                .authenticationEntryPoint((req, resp, ex) -> {
                    resp.setContentType(MediaType.APPLICATION_JSON_UTF8_VALUE);
                    resp.setStatus(HttpStatus.UNAUTHORIZED.value());
                    resp.getWriter().println("请认证之后再去处理！");
                })
                .and()
                .logout()
                .logoutRequestMatcher(new OrRequestMatcher(
                        new AntPathRequestMatcher("/logout", HttpMethod.DELETE.name()),
                        new AntPathRequestMatcher("/logout", HttpMethod.GET.name())
                ))
                .logoutUrl("/logout")
                .logoutSuccessHandler((req, resp, auth) -> {
                    Map<String, Object> result = new HashMap<String, Object>();
                    result.put("msg", "注销成功");
                    result.put("用户信息", auth.getPrincipal());
                    resp.setContentType("application/json;charset=UTF-8");
                    resp.setStatus(HttpStatus.OK.value());
                    String s = new ObjectMapper().writeValueAsString(result);
                    resp.getWriter().println(s);
                })
                .and().csrf().disable()
        ;

        //at:用来某个filter替换过滤器链中哪个filter
        //before:放在过滤器链中哪个filter之前
        //after:放在过滤器链中那个filter之后
        http.addFilterAt(loginFilter(), UsernamePasswordAuthenticationFilter.class);
    }

    @Bean
    public RememberMeServices rememberMeServices() {
        return new MyPersistentTokenBasedRememberMeService(UUID.randomUUID().toString(), userDetailsService(), new InMemoryTokenRepositoryImpl());
    }
}

```

<br/>

# 会话管理

### 简介

当浏览器调用登录接口登录成功后，服务端会和浏览器之间建立一个会话(Session)浏览器
在每次发送请求时都会携带一个Sessionld,服务端则根据这个Sessionld来判断用户身份。
当浏览器关闭后，服务端的Session并不会自动销毁，需要开发者手动在服务端调用Session销毁方法，或者等Session过期时间到了自动销毁。在Spring Security中，与HttpSession相关的功能由SessionManagemenFiter和Session AutheaticationStrateey接口来处理，SessionManagomentFilter过滤器将Session相关操作委托给SessionAuthenticationStrategy接口去完成。

### 会话并发管理

#### 简介

会话并发管理就是指在当前系统中，同一个用户可以同时创建多少个会话，如果一合设备对应一个会话，那么也可以简单理解为同一个用户可以同时在多少台设备上进行登录。默认情况下，同一用户在多少台设备上登录并没有限制，不过开发者可以在Spring Security中对此进行配置。

项目：spring-security10（Security）

配置

```properties
# 应用服务 WEB 访问端口
server.port=8080
```

controller.IndexController

```java
@RestController
public class IndexController {

    @GetMapping("/index")
    public String test() {
        System.out.println("index ok");
        return "index ok";
    }

}
```

config.SecurityConfig

```java
@Configuration
public class SecurityConfig extends WebSecurityConfigurerAdapter {

    @Override
    protected void configure(HttpSecurity http) throws Exception {
        http.authorizeRequests()
                .anyRequest().authenticated()
                .and()
                .formLogin()
                .and()
                .rememberMe()
                .and()
                .csrf().disable()
                .sessionManagement() //开启会话管理
                .maximumSessions(1) //设置回话并发数为1
        ;
    }

    @Bean
    public HttpSessionEventPublisher httpSessionEventPublisher() {
        return new HttpSessionEventPublisher();
    }
}

```

### 传统方式开启会话

```java
@Configuration
public class SecurityConfig extends WebSecurityConfigurerAdapter {

    @Override
    protected void configure(HttpSecurity http) throws Exception {
        http.authorizeRequests()
                .anyRequest().authenticated()
                .and()
                .formLogin()
                .and()
                .rememberMe()
                .and()
                .csrf().disable()
                .sessionManagement() //开启会话管理
                .maximumSessions(1) //设置回话并发数为1
        ;
    }

    @Bean
    public HttpSessionEventPublisher httpSessionEventPublisher() {
        return new HttpSessionEventPublisher();
    }
}

```

<br/>

1. sessionManagement)(用来开启会话管理、maximumSessions指定会auyT及xy±。
2. HttpSessionEventPublisher提供一一个Htp SessionEvenePubishor--实例。Spring Security中通过一个Map集合来集护当前的Http Session记录，进而实现会话的并发管理。当用户登录成功时，就向集合中添加一条Http Session记录；当会话销毁时，就从集合中移除一条Httpsession记录。HtpSesionEvenPublisher实现了Fttp SessionListener接口，可以监听到HtpSession的创建和销毁事件，并将Fltp Session的创建/销毁事件发布出去，这样，当有HttpSession销毁时，Spring Security就可以感知到该事件了。

<br/>

> 用浏览器访问localhost:8080/index，再用无痕（相当于新开一个客户端）访问index，会顶掉前面的

![screen-capture](d6d38004b2ec6acb461f0885b4be3a47.png)

<br/>

解决办法

<br/>

![screen-capture](663d8021b98f31758f4e99dc2c32619a.png)

### 前后端分离开启会话

项目：spring-security11（Security）

controller.Indexcontroller

```java
@RestController
public class IndexController {

    @GetMapping("/index")
    public String test() {
        System.out.println("index ok");
        return "index ok";
    }

}
```

config.SecurityConfig

```java
@Configuration
public class SecurityConfig extends WebSecurityConfigurerAdapter {

    @Override
    protected void configure(HttpSecurity http) throws Exception {
        http.authorizeRequests()
                .anyRequest().authenticated()
                .and()
                .formLogin()
                .and()
                .rememberMe()
                .and()
                .csrf().disable()
                .sessionManagement() //开启会话管理
                .maximumSessions(1) //设置回话并发数为1
                //.expiredUrl("/test") //当用户的挤下线之后跳转路径
                .expiredSessionStrategy(event -> {//前后端分离架构处理分案
                    HttpServletResponse response = event.getResponse();
                    Map<String, Object> result = new HashMap<>();
                    result.put("status", 500);
                    result.put("msg", "当前会话已经失效，请重新登录！");
                    String s = new ObjectMapper().writeValueAsString(result);
                    response.setContentType("application/json;charset=UTF-8");
                    response.getWriter().println(s);
                })
        ;
    }

    @Bean
    public HttpSessionEventPublisher httpSessionEventPublisher() {
        return new HttpSessionEventPublisher();
    }
}

```

验证

![screen-capture](7e438852a71087d30b8d7a7c61ed7b33.png)

## 禁止再次登录

默认的效果是一种被“挤下线”的效果，后面登录的用户会把前面登录的用户“挤下线”。还
有一种是禁止后来者登录，即一旦当前用户登录成功，后来者无法再次使用相同的用户登
录，直到当前用户主动注销登录，配置如下：

> 基本不变，加一个maxSessionsPreventsLogin（true）

```java
@Configuration
public class SecurityConfig extends WebSecurityConfigurerAdapter {

    @Override
    protected void configure(HttpSecurity http) throws Exception {
        http.authorizeRequests()
                .anyRequest().authenticated()
                .and()
                .formLogin()
                .and()
                .rememberMe()
                .and()
                .csrf().disable()
                .sessionManagement() //开启会话管理
                .maximumSessions(1) //设置回话并发数为1
                //.expiredUrl("/test") //当用户的挤下线之后跳转路径
                .expiredSessionStrategy(event -> {//前后端分离架构处理分案
                    HttpServletResponse response = event.getResponse();
                    Map<String, Object> result = new HashMap<>();
                    result.put("status", 500);
                    result.put("msg", "当前会话已经失效，请重新登录！");
                    String s = new ObjectMapper().writeValueAsString(result);
                    response.setContentType("application/json;charset=UTF-8");
                    response.getWriter().println(s);
                }).maxSessionsPreventsLogin(true);//登录之后禁止再次登录
        ;
    }

    @Bean
    public HttpSessionEventPublisher httpSessionEventPublisher() {
        return new HttpSessionEventPublisher();
    }
}

```

<br/>

![screen-capture](9881895d15f02eb6267e23a4649730a0.png)

<br/>

## 会话共享

前面所讲的会话管理都是单机上的会话管理，如果当前是集群环境，前面所讲的会话管理方案就会失效。此时可以利用spring-session结合redis实现session共享。
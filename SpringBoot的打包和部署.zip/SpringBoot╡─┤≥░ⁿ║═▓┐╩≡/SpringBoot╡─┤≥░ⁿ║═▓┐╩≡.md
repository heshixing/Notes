传统的Web应用进行打包部署时，通常会打成War包的形式，然后将War包部署到Tomcat等服务器中，而Spring Boot)应用使用的是嵌入式Servlet容器，也就是说，Spring Bootl应用默认是以)ar包形式进行打包部署的，而如果想要使用传统的Wr包形式进行打包部署，就需要进行一些配置。

## 1. jar包方式打包部署

由于Spring Bootl应用中已经嵌入了Tomcat)服务器，所以将Spring Boot)应用以默认)ar包形式进行打包部署非常简单和方便。

### 1.1 jar包方式打包

1.添加Maven:打包插件。在对Spring Boot项目进行打包（包括ar包和War包）前，需要在项目pom.xml文件中加入Maven打包插件，Spring Boot为项目打包提供了整合后的Maven打包插件spring-boot-maven-plugin,可以直接使用。

```xml
<build>
  <plugins>
    <!--Maven打包插件-->
    <plugin>
      <groupId>org.springframework.boot</groupId>
      <artifactId>spring-boot-maven-plugin</artifactId>
    </plugin>
  </plugins>
</build>
```

![screen-capture](a1b979522b3479c179dfd9c7cfea4091.png)

![screen-capture](6a6372e831fcd9095f7702fae298f26a.png)

![screen-capture](4b9b846619de3e8c2d921860a41a73b1.png)

java -jar sb_pack-0.0.1-SNAPSHOT.jar 回车 

## 2. War包方式打包部署

虽然通过Spring Bootl内嵌的Tomcat可以直接将项目打成ar包进行部署，但有时候还需要通过外部的可配置Tomcat;进行项目管理，这就需要将项目打成War包。

### 2.1 War包方式打包

1.声明打包方式为War包。打开chapter05项目的pom.xml文件，使用packaging标签将  Spring Boot项目默认的Jar包打包方式修改为War形式。

```xml
<description>Demo project for Spring Boot</description>
  <!--1.将项目打包方式声明为war-->
  <packaging>war</packaging>
  <properties>
     <java.version>1.8</java.version>
  </properties>
```

2.声明使用外部Tomcat服务器。Spring Booti为项目默认提供了内嵌的Tomcat服务器，为了将项目以War形式进行打包部署，还需要声明使用外部Tomcat)服务器。打开chaptert05项目的pom.xml文件，在依赖文件中将Tomcati声明为外部提供。

```xml
<!--2.声明使用外部提供的Tomcat-->
<dependency>
  <groupId>org.springframework.boot</groupId>
  <artifactId>spring-boot-starter-tomcat</artifactId>
  <!--将服务器声明为外部已提供-->
  <scope>provided</scope>
</dependency>
```

![screen-capture](d454c8d45cf2bab4cb7650e7feb6c854.png)

package  Tomcat的webapps

![screen-capture](cb791939e002256af47c8086caa01016.png)
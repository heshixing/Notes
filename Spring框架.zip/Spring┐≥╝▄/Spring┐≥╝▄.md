## 1. Spring的IOC

> **IOC** : inversion of control，控制反转。就是将对象创建的权利交给Spring框架，而开发者无需去关注对象的生命周期。

1. 创建一个java项目spring-code（单纯的java项目，不含Maven）,在该项目下创建一个Model名为
   
   spring-01-ioc。

> 导入下面的jar包：

![screen-capture](d84bc6d6c3c558073be1c29577257e24.png)

> 在src下创建com.cy.pojo.Hello类，代码如下：

```java
public class Hello {
  
    public void say() {

        System.out.println("Hello!");

    }
}
```

> 在src下创建applicationContext.xml文件，代码如下：

```xml
<?xml version="1.0" encoding="UTF-8"?>

<!--beans标签中用来配置将来要托管给Spring框架管理的对象，可以看作是一个对象的管理容器。
    配置A0P基础、事务技术、其他框架的整合技术
-->
<!--xmlns : 表示xml的命令空间http:/www.springframework.org,表示Spring的官方配置
    xmlns:xsi : 表示XML的规范XMLSchema-instance来遵循的(即进一步规范)
    xsi:schemaLocation : 表示XML书写的语法格式-->
<beans xmlns="http://www.springframework.org/schema/beans"
       xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
       xsi:schemaLocation="http://www.springframework.org/schema/beans http://www.springframework.org/schema/beans/spring-beans.xsd">

    <!--Bean标签 : 来配置托管给Spring容器管理的对象
        1.class属性 : class属性用来表示将那个类托管给Spring容器，编写类的完成路径
        2.id属性：表示在Spring容器中Bean对象的唯一标识符，id是不可以重复，同时id的格式
        必须使用类名的首字母小写的形式，将来使用配置的d来获取这个对象
    -->
    <bean id="hello" class="com.cy.pojo.Hello"></bean>
</beans>
```

> 在src下创建com.cy.test.TestSpring测试类，代码如下：

```java
public class TestSpring {

     @Test
    public void test01(){

        //1.获取Spring容器
        ApplicationContext context = new ClassPathXmlApplicationContext( "applicationContext.xml");
        //2，通过Spring的容器来获取容器中的某个指定对象（id = hello）
        Hello hello = (Hello) context.getBean("hello");
        //3. 访问Hello对象的方法
        hello.say();
    }

    @Test
    public void test02(){

        //1.获取Spring容器
        ApplicationContext context = new ClassPathXmlApplicationContext( "applicationContext.xml");
        //2，通过类型来获取容器中的java对象（不需要类型转化）
        Hello hello = context.getBean(Hello.class);
        //3. 访问Hello对象的方法
        hello.say();
    }
    
    /** 在applicationContext.xml中配置别名
      * alias标签：表示为某个Bean对象配置访问别名
      *  name属性：表示对那个Bean对象进行别名配置，取值必须是某个Bean的id属性的取值
      *  alias属性：表示这个Bean对象配置的别名是什么
      *<alias name="hello" alias="hel" />
      */

    @Test
    public void test03(){

        //1.获取Spring容器
        ApplicationContext context = new ClassPathXmlApplicationContext( "applicationContext.xml");
        //2，通过Spring的容器来获取容器中的某个指定对象（id = hello）
        Hello hello = (Hello) context.getBean("hel");
        //3. 访问Hello对象的方法
        hello.say();
    }

}
```

如果运行报错是:  ...not exists  ==》 File -> Project Structure -> Modules -> spring-o1-ioc -> paths

-> use module compile out path -> Output path :  -> 在spring-01-ioc加 " \src "。 

原理：

1. 当Springs容器启动时，找到对应的核心配置文件applicationContext.xml
2. 当加载配置文件applicationContext..xml时，逐行读取配置文件并解析bean标签
3. bean标签的id属性值，解析为Map集合中的key值；bean标签的class属性值，解析时通过ava的反射机制创建对应类的对象，同时把这个对象存入Map集合key值所对应的value值中
4. 使用Map集合中的key值(id属性的值)，获取Map集合中的value值(class属性的值所指向的对象)

## 2. Spring创建对象的方式

> 在spring-demo文件夹创建一个java文件名称为spring-01-Object（lib包相同）

1. 默认模式：默认使用无参数构造方法来创建对象

**验证：** 给Hello类加构造方法（默认有无参构造，但是如果手动加了有参，但是不加无参，就没有无参）

```java
public class Hello {

    public Hello(int a){

    }

    public void say() {
      
        System.out.println("Hello!");
        
    }

}
```

测试方法代码如下：

```java
 @Test
    public void test01(){

        //1.获取Spring容器
        ApplicationContext context = new ClassPathXmlApplicationContext( "applicationContext.xml");
        //2，通过Spring的容器来获取容器中的某个指定对象（id = hello）
        Hello hello = (Hello) context.getBean("hello");
        //3. 访问Hello对象的方法
        hello.say();
    }
```

> 报错：nested exception is java.lang.**ClassNotFoundException**: com.cy.pojo.Hello

2. 静态工厂：在一个静态的工厂类中，定义一个静态的方法，负责获取某一个对象（用Calendar类测试）

**验证：**给Hello类加获取Calendar类的静态方法

```java
public class Hello {

    public void say() {

        System.out.println("Hello!");

    }

}
```

> 在pojo包下创建staticFactory类，代码如下

```java
public class staticFactory {

    public static Calendar getCalendar(){
        return Calendar.getInstance();
    }

}
```

> applicationContext.xml代码如下：**（注释有解释）**

```xml
<?xml version="1.0" encoding="UTF-8"?>

<!--beans标签中用来配置将来要托管给Spring框架管理的对象，可以看作是一个对象的管理容器。
    配置A0P基础、事务技术、其他框架的整合技术
-->
<!--xmlns : 表示xml的命令空间http:/www.springframework.org,表示Spring的官方配置
    xmlns:xsi : 表示XML的规范XMLSchema-instance来遵循的(即进一步规范)
    xsi:schemaLocation : 表示XML书写的语法格式-->
<beans xmlns="http://www.springframework.org/schema/beans"
       xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
       xsi:schemaLocation="http://www.springframework.org/schema/beans http://www.springframework.org/schema/beans/spring-beans.xsd">

    <!--Bean标签 : 来配置托管给Spring容器管理的对象
        1.class属性 : class属性用来表示将那个类托管给Spring容器，编写类的完成路径
        2.id属性：表示在Spring容器中Bean对象的唯一标识符，id是不可以重复，同时id的格式
        必须使用类名的首字母小写的形式，将来使用配置的d来获取这个对象
    -->
    <bean id="hello" class="com.cy.pojo.Hello">

    </bean>

    <!--静态工厂访问对象
    factory-method属性：表示工厂模式来常见对象，在获取bean标签的时候，
    会先去执行Factory-method属性对象的方法，而把这个方法的返回值最为
    此Ban的标签返回对象
    -->
    <bean id="calendarA" class="com.cy.pojo.StaticFactory"
          factory-method="getCalendar"></bean>
</beans>
```

> 编写测试方法，代码如下：

```java
 @Test
    public void test01(){

        //1.获取Spring容器
        ApplicationContext context = new ClassPathXmlApplicationContext( "applicationContext.xml");

        Calendar calendar = (Calendar) context.getBean("calendarA");

        System.out.println(calendar.getTime());

    }
```

测试结果如下：表示获取到了Calendar类

```text
Wed Jul 12 21:57:57 CST 2023
```

3. 实例工厂：在一个非静态的工厂类中，定义一个非静态的方法，负责获取某一个对象

> 在pojo包下创建instanceFactory类，代码如下：

```java
public class instanceFactory {

    public Calendar getCalendar(){
        return Calendar.getInstance();
    }

}



```

> applicationContext.xml代码如下：**（注释有解释）**

```xml
<?xml version="1.0" encoding="UTF-8"?>

<!--beans标签中用来配置将来要托管给Spring框架管理的对象，可以看作是一个对象的管理容器。
    配置A0P基础、事务技术、其他框架的整合技术
-->
<!--xmlns : 表示xml的命令空间http:/www.springframework.org,表示Spring的官方配置
    xmlns:xsi : 表示XML的规范XMLSchema-instance来遵循的(即进一步规范)
    xsi:schemaLocation : 表示XML书写的语法格式-->
<beans xmlns="http://www.springframework.org/schema/beans"
       xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
       xsi:schemaLocation="http://www.springframework.org/schema/beans http://www.springframework.org/schema/beans/spring-beans.xsd">

    <!--Bean标签 : 来配置托管给Spring容器管理的对象
        1.class属性 : class属性用来表示将那个类托管给Spring容器，编写类的完成路径
        2.id属性：表示在Spring容器中Bean对象的唯一标识符，id是不可以重复，同时id的格式
        必须使用类名的首字母小写的形式，将来使用配置的d来获取这个对象
    -->
    <bean id="hello" class="com.cy.pojo.Hello">

    </bean>

    <!--静态工厂访问对象
    factory-method属性：表示工厂模式来常见对象，在获取bean标签的时候，会先去执行Factor
    属性对象的方法，而把这个方法的返回值值最为此Ban的标签返回对象
    -->
    <bean id="calendarA" class="com.cy.pojo.staticFactory"
          factory-method="getCalendar"></bean>

    <!--实例工厂访问对象-->
    <bean id="instanceFactory" class="com.cy.pojo.instanceFactory"></bean>
    <!--factory-bean属性 : 取值需要执行实例工厂的id属性的取值
         factory-method : 配置的是买例工厂的某个方法的名称，这个方法的返回值就是目标你要获取的对象-->
    <bean id="CalendarB" factory-bean="instanceFactory" factory-method="getCalendar"></bean>
</beans>
```

> 编写测试方法，代码如下：

```java
 @Test
    public void test02(){

        //1.获取Spring容器
        ApplicationContext context = new ClassPathXmlApplicationContext( "applicationContext.xml");

        Calendar calendar = (Calendar) context.getBean("CalendarB");

        System.out.println(calendar.getTime());

    }
```

测试结果如下：表示获取到了Calendar类

```text
Wed Jul 12 22:12:53 CST 2023
```

4. 实现接口：定义一个类，Spring框架提供了一个接口FactoryBean接口，只需要让自定义的类实现这个接口，需要重写接口中的方法。

> 建议：以后创建对象时，而该对象又不能直接被Spring容器管理，可以选择Spring提供的工厂模式
FactoryBean接口来实现。

> 在pojo包下创建SpringFactory类，代码如下：

```java
//Spring提供的接口方式来获取对象
public class SpringFactory implements FactoryBean {
    //表示通过这种方式获取的对象是谁
    @Override
    public Object getObject() throws Exception {
        return Calendar.getInstance();
    }
    //获取对象的数据类型
    @Override
    public Class<?> getObjectType() {
        return ClassLoader.class;
    }

    //false : 多例
     @Override
    public boolean isSingleton(){
        return false;
    }
}
```

> applicationContext.xml代码如下：**（注释有解释）**

```xml
<?xml version="1.0" encoding="UTF-8"?>

<!--beans标签中用来配置将来要托管给Spring框架管理的对象，可以看作是一个对象的管理容器。
    配置A0P基础、事务技术、其他框架的整合技术
-->
<!--xmlns : 表示xml的命令空间http:/www.springframework.org,表示Spring的官方配置
    xmlns:xsi : 表示XML的规范XMLSchema-instance来遵循的(即进一步规范)
    xsi:schemaLocation : 表示XML书写的语法格式-->
<beans xmlns="http://www.springframework.org/schema/beans"
       xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
       xsi:schemaLocation="http://www.springframework.org/schema/beans http://www.springframework.org/schema/beans/spring-beans.xsd">

    <!--Bean标签 : 来配置托管给Spring容器管理的对象
        1.class属性 : class属性用来表示将那个类托管给Spring容器，编写类的完成路径
        2.id属性：表示在Spring容器中Bean对象的唯一标识符，id是不可以重复，同时id的格式
        必须使用类名的首字母小写的形式，将来使用配置的d来获取这个对象
    -->
    <bean id="hello" class="com.cy.pojo.Hello">

    </bean>

    <!--静态工厂访问对象
    factory-method属性：表示工厂模式来常见对象，在获取bean标签的时候，会先去执行Factor
    属性对象的方法，而把这个方法的返回值值最为此Ban的标签返回对象
    -->
    <bean id="calendarA" class="com.cy.pojo.staticFactory"
          factory-method="getCalendar"></bean>

    <!--实例工厂访问对象-->
    <bean id="instanceFactory" class="com.cy.pojo.instanceFactory"></bean>
    <!--factory-bean属性 : 取值需要执行实例工厂的id属性的取值
         factory-method : 配置的是买例工厂的某个方法的名称，这个方法的返回值就是目标你要获取的对象-->
    <bean id="CalendarB" factory-bean="instanceFactory" factory-method="getCalendar"></bean>


    <bean id="CalendarC" class="com.cy.pojo.SpringFactory"></bean>
</beans>
```

> 编写测试方法，代码如下：

```java
  @Test
    public void test03(){
        //1.获取Spring容器
        ApplicationContext context = new ClassPathXmlApplicationContext( "applicationContext.xml");

        Calendar calendar = (Calendar) context.getBean("CalendarC");

        System.out.println(calendar.getTime());
    }
```

测试结果如下：表示获取到了Calendar类

```text
Wed Jul 12 22:21:10 CST 2023
```

## 3. Spring的单例多例和懒加载

### 3.1 Spring的单例多例

1. 单例模式：

![screen-capture](8f231741398a881ef8febf0018d7cc6f.png)

2. 多例模式：

![screen-capture](74f3ff1d250d631fa372334dc8865258.png)

3. 单例多例实现方式：

```text
<!--默认情况下是单例：
scope="singleton"单例，启动Spring容器时创建对象
scope="prototype"多例，启动Spring容器时不创建对象，调用getBean()方法时创建对象
-->
<bean id = "user" class="com.cy.pojo.User" scope="prototype"></bean>
```

### 3.2 Spring的懒加载

**懒加载：**什么时候需要使用对象，就什么时候创建对象(理想化)

**实现方式一：**

```text
<!--默认不是懒加载：
lazy-init="false"表示懒加载无效，启动Spring容器时创建对象
lazy-init="true"表示懒加载生效，启动Spring容器时不创建对象，调用getBean()方法时创建对象
-->
```

**实现方式二：**

当项目的核心配置文件中bean标签越来越多时，如何设置懒加载属性？

在beans根标签中添加default-lazy-init属性。

```xml
default-lazy-init = "true"
```

### 3.3 单例多例和懒加载配合使用

在多例模式下，无论懒加载属性为true还是false，懒加载都将生效。

![screen-capture](48dae7de50a3a9596d516e65c266e43e.png)

## 4. Spring维护对象的生命周期

### 4.1 Spring维护对象的生命周期

1. 加载对象时，通过构造方法创建对象
2. 对象的初始化阶段
3. 对象的基本调用阶段(执行相应的自定义方法)
4. 对象的销毁阶段

![screen-capture](24894cb2fe79206c11dbef9701184181.png)

## 5. Spring的DI

1. DI ：Dependency Injection,依赖注入
2.  依赖 ： 在类中，对象的创建依赖于成员变量
3.  注入：  把成员变量的值注入到对象中
4. Spring的DI依赖注入方式：set方式注入，构造方法注入，Spring框架默认使用无参构造方法注入

### 5.1 set方式注入

Spring在进行bean标签解析时，根据property标签的name属性的值与类中定义的SetXxx()方法的Xxx名称进行

匹配。匹配的规则是：先将setXxx(0方法的set去掉，再将Xxx首字母改为小写；最后将得到的首字母小写的xXX

与property标签的name属性的值进行比较，如果匹配上则注入成功，则注入失败。set方式注入，前提条件是类

的属性必须有对应的setXxx()方法，否则将注入失败。

**set方式注入可以完成：简单类型属性值的注入、复杂类型属性值的注入、引用类型属性值的注入**

**验证：**

创建一个spring-05-DI的java项目，导入lib文件夹和applicationContext.xml文件（空文件）。

> 在src下创建一个com.cy.pojo.User类，代码如下：

```java
public class User {

    private int age;
    private String name;

    private List<String> Doglist;

    private Map map;

    private Set set;

    private String[] arr;
    private Properties properties;

    @Override
    public String toString() {
        return "User{" +
                "age=" + age +
                ", name='" + name + '\'' +
                ", Doglist=" + Doglist +
                ", map=" + map +
                ", set=" + set +
                ", arr=" + Arrays.toString(arr) +
                ", properties=" + properties +
                '}';
    }

    public Map getMap() {
        return map;
    }

    public void setMap(Map map) {
        this.map = map;
    }

    public Set getSet() {
        return set;
    }

    public void setSet(Set set) {
        this.set = set;
    }

    public String[] getArr() {
        return arr;
    }

    public void setArr(String[] arr) {
        this.arr = arr;
    }

    public Properties getProperties() {
        return properties;
    }

    public void setProperties(Properties properties) {
        this.properties = properties;
    }

    public List<String> getDoglist() {
        return Doglist;
    }

    public void setDoglist(List<String> doglist) {
        Doglist = doglist;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
```

> 配置applicationContext.xml文件，如下所示：

```properties
<?xml version="1.0" encoding="UTF-8"?>

<!--beans标签中用来配置将来要托管给Spring框架管理的对象，可以看作是一个对象的管理容器。
    配置A0P基础、事务技术、其他框架的整合技术
-->
<!--xmlns : 表示xml的命令空间http:/www.springframework.org,表示Spring的官方配置
    xmlns:xsi : 表示XML的规范XMLSchema-instance来遵循的(即进一步规范)
    xsi:schemaLocation : 表示XML书写的语法格式-->
<beans xmlns="http://www.springframework.org/schema/beans"
       xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
       xsi:schemaLocation="http://www.springframework.org/schema/beans http://www.springframework.org/schema/beans/spring-beans.xsd">

<bean id="user" class="com.cy.pojo.User">
    <!--对象创建的初始化配置，给属性赋值的操作-->

    <!--properties表示对class类的属性配置
        name:类中的属性   value:初始化属性值-->
    <property name="name" value="tom"></property>
    <property name="age" value="18"></property>
</bean>
</beans>
```

> 在src下创建com.cy.test.TestSpring测试类，代码如下：

```java
public class TestSpring {

    @Test
    public void test01(){

        ApplicationContext context = new
                ClassPathXmlApplicationContext("applicationContext.xml");
                
        User user = context.getBean(User.class);
        
        System.out.println(user);

    }

}
```

测试结果如下：

```text
User{age=18, name='tom', Doglist=null, map=null, set=null, arr=null, properties=null}
```

> 如果把User类的set方法注释掉，测试结果如下（测试完，还原）：

```java
Invalid property 'name' of bean class [com.cy.pojo.User]: Bean property 'name' is not writable or has an invalid setter method.
```

**上面验证的是set方式注入简单类型，下面是复杂类型的注入：**

**1.List类型：**

> 在applicationContext.xml文件中加入List类型的初始化配置：

```properties
<?xml version="1.0" encoding="UTF-8"?>

<!--beans标签中用来配置将来要托管给Spring框架管理的对象，可以看作是一个对象的管理容器。
    配置A0P基础、事务技术、其他框架的整合技术
-->
<!--xmlns : 表示xml的命令空间http:/www.springframework.org,表示Spring的官方配置
    xmlns:xsi : 表示XML的规范XMLSchema-instance来遵循的(即进一步规范)
    xsi:schemaLocation : 表示XML书写的语法格式-->
<beans xmlns="http://www.springframework.org/schema/beans"
       xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
       xsi:schemaLocation="http://www.springframework.org/schema/beans http://www.springframework.org/schema/beans/spring-beans.xsd">

<bean id="user" class="com.cy.pojo.User">
    <!--对象创建的初始化配置，给属性赋值的操作-->

    <!--properties表示对class类的属性配置
        name:类中的属性   value:初始化属性值-->
    <property name="name" value="tom"></property>
    <property name="age" value="18"></property>

    <!--复杂类型的注入-->

    <!--1.List类型-->
    <property name="doglist">
        <list>
            <value>小狗</value>
            <value>小猫</value>
        </list>
    </property>
</bean>
</beans>
```

> 重新运行测试方法，测试结果如下：

```text
User{age=18, name='tom', Doglist=[小狗, 小猫], map=null, set=null, arr=null, properties=null}
```

**2.Map类型：**

> 在applicationContext.xml文件中加入Map类型的初始化配置：

```xml
 <!--2.Map类型-->
    <property name="map">
        <map>
            <entry key="k1" value="1"></entry>
            <entry key="k2" value="2"></entry>
        </map>
    </property>
```

> 重新运行测试方法，测试结果如下：

```text
User{age=18, name='tom', Doglist=[小狗, 小猫], map={k1=1, k2=2}, set=null, arr=null, properties=null}
```

**3.Set类型：**

> 在applicationContext.xml文件中加入Set类型的初始化配置：

```xml
    <!--3.Set类型-->
    <property name="set">
        <set>
            <value>1</value>
            <value>2</value>
        </set>
    </property>
```

> 重新运行测试方法，测试结果如下：

```text
User{age=18, name='tom', Doglist=[小狗, 小猫], map={k1=1, k2=2}, set=[1, 2], arr=null, properties=null}
```

**4.Array类型：**

> 在applicationContext.xml文件中加入Array类型的初始化配置：

```xml
    <!--4.Array类型-->
    <property name="arr">
        <list>
            <value>1</value>
            <value>2</value>
        </list>
    </property>
```

> 重新运行测试方法，测试结果如下：

```text
User{age=18, name='tom', Doglist=[小狗, 小猫], map={k1=1, k2=2}, set=[1, 2], arr=[1, 2], properties=null}
```

**5.Properties类型：**

> 在applicationContext.xml文件中加入Properties类型的初始化配置：

```xml
<!--5.Properties-->
    <property name="properties">
        <props>
            <prop key="username">何世兴</prop>
            <prop key="password">123</prop>
        </props>
    </property>
```

> 重新运行测试方法，测试结果如下：

```text
User{age=18, name='tom', Doglist=[小狗, 小猫], map={k1=1, k2=2}, set=[1, 2], arr=[1, 2], properties={password=123, username=何世兴}}
```

**上面验证的是set方式注入复杂类型，下面是引用类型的注入：**

> 给User类加一个DogList属性，为其添加Set和Get方法，重写toString方法

```java
public class User {

    private Dog dog;

    private int age;
    private String name;

    private List<String> Doglist;

    private Map map;

    private Set set;

    private String[] arr;
    private Properties properties;

    @Override
    public String toString() {
        return "User{" +
                "dog=" + dog +
                ", age=" + age +
                ", name='" + name + '\'' +
                ", Doglist=" + Doglist +
                ", map=" + map +
                ", set=" + set +
                ", arr=" + Arrays.toString(arr) +
                ", properties=" + properties +
                '}';
    }

    public Dog getDog() {
        return dog;
    }

    public void setDog(Dog dog) {
        this.dog = dog;
    }

    public Map getMap() {
        return map;
    }

    public void setMap(Map map) {
        this.map = map;
    }

    public Set getSet() {
        return set;
    }

    public void setSet(Set set) {
        this.set = set;
    }

    public String[] getArr() {
        return arr;
    }

    public void setArr(String[] arr) {
        this.arr = arr;
    }

    public Properties getProperties() {
        return properties;
    }

    public void setProperties(Properties properties) {
        this.properties = properties;
    }

    public List<String> getDoglist() {
        return Doglist;
    }

    public void setDoglist(List<String> doglist) {
        Doglist = doglist;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
```

> applicationContext.xml的配置如下（看注释部分）：

```xml
<?xml version="1.0" encoding="UTF-8"?>

<!--beans标签中用来配置将来要托管给Spring框架管理的对象，可以看作是一个对象的管理容器。
    配置A0P基础、事务技术、其他框架的整合技术
-->
<!--xmlns : 表示xml的命令空间http:/www.springframework.org,表示Spring的官方配置
    xmlns:xsi : 表示XML的规范XMLSchema-instance来遵循的(即进一步规范)
    xsi:schemaLocation : 表示XML书写的语法格式-->
<beans xmlns="http://www.springframework.org/schema/beans"
       xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
       xsi:schemaLocation="http://www.springframework.org/schema/beans http://www.springframework.org/schema/beans/spring-beans.xsd">

<bean id="user" class="com.cy.pojo.User">
    <!--对象创建的初始化配置，给属性赋值的操作-->

    <!--properties表示对class类的属性配置
        name:类中的属性   value:初始化属性值-->
    <property name="name" value="tom"></property>
    <property name="age" value="18"></property>

    <!--复杂类型的注入-->

    <!--1.List类型-->
    <property name="doglist">
        <list>
            <value>小狗</value>
            <value>小猫</value>
        </list>
    </property>

    <!--2.Map类型-->
    <property name="map">
        <map>
            <entry key="k1" value="1"></entry>
            <entry key="k2" value="2"></entry>
        </map>
    </property>

    <!--3.Set类型-->
    <property name="set">
        <set>
            <value>1</value>
            <value>2</value>
        </set>
    </property>

    <!--4.Array类型-->
    <property name="arr">
        <list>
            <value>1</value>
            <value>2</value>
        </list>
    </property>

    <!--5.Properties-->
    <property name="properties">
        <props>
            <prop key="username">何世兴</prop>
            <prop key="password">123</prop>
        </props>
    </property>

    <!--6.引入类型，当前的属性为引用类型的时候属性的取值
          为外部定义个一个bean标签的id属性的取值-->
    <property name="dog" ref="dogA"></property>
</bean>
    <bean id="dogA" class="com.cy.pojo.Dog">
        <property name="dogName" value="小黄"></property>
        <property name="dogType" value="黄狗"></property>
    </bean>
</beans>
```

> 重新运行测试方法，测试结果如下：

```text
User{dog=dao{dogName='小黄', dogType='黄狗'}, age=18, name='tom', Doglist=[小狗, 小猫], map={k1=1, k2=2}, set=[1, 2], arr=[1, 2], properties={password=123, username=何世兴}}
```

### 5.2 构造方法注入

构造函数分为三种类型指定参数索引(index),指定参数类型(type),指定参数名称(name)三

种方式，当我们指定任意一种方式时，Spig会自动帮我们识别对应的构造函数，并将值

行注入。

> 一个constructor-arg元素表示构造方法的一个参数，且使用时不区分顺序。constructor-arg核心属性见下：

- index="构造方法中参数列表中各个形参的位置，索引从0开始
- name="构造方法中参数列表形参的名称
- type="构造方法中形参的数据类型，Spring默认自动转换省略不写
- value="构造方法中形参的初始值
- ref="引用类型参数的id属性的值

> 注意：JDK1.7及以下版本不支持name、type属性独立使用

**建议采用set方式注入。正常的项目开发中，开发者一般使用set方式注入；而Spring源码中设计的是使用构造方法方式注入。**

> 在pojo包下创建Student类，代码如下：

```java
public class Student {

    private String name;
    private int age;

    private Dog dog;
    public Student() {
    }

    public Student(String name, int age ,Dog dog) {
        this.name = name;
        this.age = age;
        this.dog = dog;
    }

    @Override
    public String toString() {
        return "Student{" +
                "name='" + name + '\'' +
                ", age=" + age +
                ", dog=" + dog +
                '}';
    }

    public Dog getDog() {
        return dog;
    }

    public void setDog(Dog dog) {
        this.dog = dog;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }
}
```

> applicationContext.xml的配置如下（看注释）：

```xml
<?xml version="1.0" encoding="UTF-8"?>

<!--beans标签中用来配置将来要托管给Spring框架管理的对象，可以看作是一个对象的管理容器。
    配置A0P基础、事务技术、其他框架的整合技术
-->
<!--xmlns : 表示xml的命令空间http:/www.springframework.org,表示Spring的官方配置
    xmlns:xsi : 表示XML的规范XMLSchema-instance来遵循的(即进一步规范)
    xsi:schemaLocation : 表示XML书写的语法格式-->
<beans xmlns="http://www.springframework.org/schema/beans"
       xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
       xsi:schemaLocation="http://www.springframework.org/schema/beans http://www.springframework.org/schema/beans/spring-beans.xsd">

<bean id="user" class="com.cy.pojo.User">
    <!--对象创建的初始化配置，给属性赋值的操作-->

    <!--properties表示对class类的属性配置
        name:类中的属性   value:初始化属性值-->
    <property name="name" value="tom"></property>
    <property name="age" value="18"></property>

    <!--复杂类型的注入-->

    <!--1.List类型-->
    <property name="doglist">
        <list>
            <value>小狗</value>
            <value>小猫</value>
        </list>
    </property>

    <!--2.Map类型-->
    <property name="map">
        <map>
            <entry key="k1" value="1"></entry>
            <entry key="k2" value="2"></entry>
        </map>
    </property>

    <!--3.Set类型-->
    <property name="set">
        <set>
            <value>1</value>
            <value>2</value>
        </set>
    </property>

    <!--4.Array类型-->
    <property name="arr">
        <list>
            <value>1</value>
            <value>2</value>
        </list>
    </property>

    <!--5.Properties-->
    <property name="properties">
        <props>
            <prop key="username">何世兴</prop>
            <prop key="password">123</prop>
        </props>
    </property>

    <!--6.引入类型-->
    <property name="dog" ref="dogA">

    </property>
</bean>

    <bean id="dogA" class="com.cy.pojo.Dog">
        <property name="dogName" value="小黄"></property>
        <property name="dogType" value="黄狗"></property>
    </bean>

     <!--7.Student类的配置-->
    <bean id="student" class="com.cy.pojo.Student">
        <!--推荐第一种-->
        <constructor-arg index="0"  value="何世兴" type="java.lang.String"></constructor-arg>
        <constructor-arg index="1" value="18" ></constructor-arg>
        <constructor-arg index="2" ref="dogA" ></constructor-arg>
        <!--
        <constructor-arg name="age" value="18" ></constructor-arg>
        <constructor-arg name="dog" ref="dogA"></constructor-arg>
        <constructor-arg name="name" value="何世兴" type="java.lang.String"></constructor-arg>
        -->
    </bean>
</beans>
```

> 在TestSpring中编写如下测试方法：

```java
    @Test
    public void test02(){

        ApplicationContext context = new
                ClassPathXmlApplicationContext("applicationContext.xml");

        Student student = context.getBean(Student.class);
        System.out.println(student);

    }
```

测试结果如下：

```text
Student{name='何世兴', age=18, dog=dao{dogName='小黄', dogType='黄狗'}}
```

## 6. Spring的注解

### 6.1 Spring的自动装配

1. **autowire="byName"** : 实体类中的引用类型属性必须声明set方法才能生效

> 对bean标签进行解析，当遇到autowire="byName"属性时，Spring会自动找到类中的成员变量的set方法。

举例：

```text
setDog解析时，会先把set去掉，然后得到Dog单词，再进行首字母的小写得到dog。
那么该dog就是bean标签中的id属性的值。Spring会根据dog值匹配配置文件中id="dog"的bean标签。
如果匹配成功，dog对象会注入到user对象中；如果匹配失败则注入nul川值。
```

2. **autowire="byType"** : 实体类中的引用类型属性必须声明set方法才能生效
   > 对bean标签进行解析，当遇到autowire="byType"属性时，Spring会自动找到类中的成员变量的set方法。

举例：

```text
setDog解析时，会找到setDog(Dogdog)方法中的形参类型Dog,然后找到Dog类所在的包，拼接了一个
com.Gy.pojo.Dog值。Spring会根据com.cy.pojo.Dog值，匹配配置文件中的class="com.Cy.pojo.Dog"
的bean标签。如果匹配成功，dog对象会注入到user对象中；如果匹配失败则注入null值。
```

**演示：**

创建一个spring-07-autowire的java项目（lib文件夹保留）

> 在src下创建com.cy.pojo.Cat类：

```java
public class Cat {

    private String catName;

    @Override
    public String toString() {
        return "Cat{" +
                "catName='" + catName + '\'' +
                '}';
    }

    public String getCatName() {
        return catName;
    }

    public void setCatName(String catName) {
        this.catName = catName;
    }
}
```

> 在src下创建com.cy.pojo.Dog类：

```java
public class Dog {

    private String dogName;

    @Override
    public String toString() {
        return "Dog{" +
                "dogName='" + dogName + '\'' +
                '}';
    }

    public String getDogName() {
        return dogName;
    }

    public void setDogName(String dogName) {
        this.dogName = dogName;
    }
}
```

> 在src下创建com.cy.pojo.User类：

```java
public class User {

    private Cat cat;
    private Dog dog;

    @Override
    public String toString() {
        return "User{" +
                "cat=" + cat +
                ", dog=" + dog +
                '}';
    }

    public Cat getCat() {
        return cat;
    }

    public void setCat(Cat cat) {
        this.cat = cat;
    }

    public Dog getDog() {
        return dog;
    }

    public void setDog(Dog dog) {
        this.dog = dog;
    }
}
```

> applicationContext.xml配置如下：

```xml
<?xml version="1.0" encoding="UTF-8"?>

<!--beans标签中用来配置将来要托管给Spring框架管理的对象，可以看作是一个对象的管理容器。
    配置A0P基础、事务技术、其他框架的整合技术
-->
<!--xmlns : 表示xml的命令空间http:/www.springframework.org,表示Spring的官方配置
    xmlns:xsi : 表示XML的规范XMLSchema-instance来遵循的(即进一步规范)
    xsi:schemaLocation : 表示XML书写的语法格式-->
<beans xmlns="http://www.springframework.org/schema/beans"
       xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
       xsi:schemaLocation="http://www.springframework.org/schema/beans http://www.springframework.org/schema/beans/spring-beans.xsd">


    <bean id="dog" class="com.cy.pojo.Dog">
        <property name="dogName" value="小狗"></property>
    </bean>
    <bean id="cat" class="com.cy.pojo.Cat">
        <property name="catName" value="小猫"></property>
    </bean>

    <!--autowire : 表示自动装配。将实体类中的引用类型的变量进行自动的初始化操作
    -->
    <bean id="user" class="com.cy.pojo.User" autowire="byName">

    </bean>

</beans>
```

> 在src下创建com.cy.test.TestSpring类，代码如下：

```java
public class TestSpring {

    @Test
    public void test01(){

        ApplicationContext context = new
                ClassPathXmlApplicationContext("applicationContext.xml");

        User user = context.getBean(User.class);
        System.out.println(user);

    }

}
```

测试结果如下：

```text
User{cat=Cat{catName='小猫'}, dog=Dog{dogName='小狗'}}
```

### 6.2 Spring的属性注解

对引用类型参数进行简化，使用属性注解@Autowired的形式。

> 在类的成员变量上加@Autowired注解，属性注解取代了自动装配。可以把实体类的set方法全部去掉。

```text
1.Spring容器加载时，首先去解析核心配置文件applicationContext.xml。
2.当解析到context:annotation-config标签时，将会扫描每个bean标签对应的类中的属性注解。
3.当检测到类的成员变量被@Autowired注解修饰时，将会进行自动装配的过程。
4.先进行byName自动装配的过程，将成员变量的名称作为bean标签id属性的值进行匹配。
举例：Dog dog,Spring会根据成员变量dog值匹配配置文件中id="dog"的bean标签。如果匹配成功，
dog对象注入到user对象中；如果匹配失败则采用byType自动装配的过程。不需要set方法的支持。
5.在进行byType自动装配的过程，将成员变量的数据类型作为bean标签class属性的值进行匹配。
举例：Dog dog,Spring:会根据成员变量数据类型com.Cy.pojo.Dog值匹配配置文件中class="com.Cy.pojo.Dog"
的bean标签。如果匹配成功，dog对象注入到user对象中；如果匹配失败则注入nul值。
```

**演示：**

创建一个spring-08-propertyAnno的java项目（和上一个项目一样，除了User类和xml配置）

> applicationContext.xml的配置如下：

```xml
<?xml version="1.0" encoding="UTF-8"?>

<!--beans标签中用来配置将来要托管给Spring框架管理的对象，可以看作是一个对象的管理容器。
    配置A0P基础、事务技术、其他框架的整合技术
-->
<!--xmlns : 表示xml的命令空间http:/www.springframework.org,表示Spring的官方配置
    xmlns:xsi : 表示XML的规范XMLSchema-instance来遵循的(即进一步规范)
    xsi:schemaLocation : 表示XML书写的语法格式-->
<beans xmlns="http://www.springframework.org/schema/beans"
       xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
       xmlns:context="http://www.springframework.org/schema/context"
       xsi:schemaLocation="http://www.springframework.org/schema/beans http://www.springframework.org/schema/beans/spring-beans.xsd http://www.springframework.org/schema/context http://www.springframework.org/schema/context/spring-context.xsd">

    <bean id="dog" class="cy.pojo.Dog">
        <property name="dogName" value="小狗"></property>
    </bean>
    <bean id="cat" class="cy.pojo.Cat">
        <property name="catName" value="小猫"></property>
    </bean>
    <bean id="user" class="cy.pojo.User"></bean>

    <!--开启属性注解扫描的配置-->
    <context:annotation-config></context:annotation-config>
</beans>
```

> User类的代码如下（**这里用了@Autowired，干脆把set方法省略了**）：

```java
/**
 *Spring的属性注解：@Autowire.
 *1.作用：是用来标记对应的属性是自动依赖注入（自动初始化）
 *2.语法：在对应的属性定义前添加此注解即可
 *3.使用：告诉Spring容器开启注解的功能（开启注解的扫描）
 */
public class User {

    @Autowired
    private Cat cat;
    @Autowired
    private Dog dog;

    @Override
    public String toString() {
        return "User{" +
                "cat=" + cat +
                ", dog=" + dog +
                '}';
    }

    public Cat getCat() {
        return cat;
    }

    public Dog getDog() {
        return dog;
    }

}
```

测试类代码不变，测试结果如下：

```text
User{cat=Cat{catName='小猫'}, dog=Dog{dogName='小狗'}}
```

### 6.3 Spring的类注解

对核心配置文件中的bean标签进行简化，使用类注解@Component的形式

> @Component（类注解）： 取代核心配置文件的bean标签

```text
(l)在配置文件中添加开启包扫描：<context:component-scan base-package="包的路径“/>，开启包扫描的同时，开启了属性的注解
(2)在实体类的定义前添加Component注解
(3)开启单元测试
```

**执行原理：**

```text
1.Spring加载配置文代读取到<context:component-scan base-package=包的路径"/>标签。
2.Spring首先会对指定的包路径下所有的)avaBean进行扫描，如果检测到类被@Component注解修饰，则创建对应类的对象。
3.Spring:将继续扫描属性注解，如果检测到类的属性被@Autowired注解修饰，将进行自动装配的过程完成对avaBean对象的依赖注入。
```

类的id生成规则（了解即可）：

```
类的id生成规则：根据类名中的第二个字母判断。如果类名中第二个字母是小写，则将类名的首字母小写后作为的值；如果类名中第二个字母是大写，则直
接将类名作为id的值。
```

**演示：**

创建一个spring-09-classAnno的java项目（lib包一样）

> applicationContext.xml配置如下：

```xml
<?xml version="1.0" encoding="UTF-8"?>

<!--beans标签中用来配置将来要托管给Spring框架管理的对象，可以看作是一个对象的管理容器。
    配置A0P基础、事务技术、其他框架的整合技术
-->
<!--xmlns : 表示xml的命令空间http:/www.springframework.org,表示Spring的官方配置
    xmlns:xsi : 表示XML的规范XMLSchema-instance来遵循的(即进一步规范)
    xsi:schemaLocation : 表示XML书写的语法格式-->
<beans xmlns="http://www.springframework.org/schema/beans"
       xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
       xmlns:context="http://www.springframework.org/schema/context"
       xsi:schemaLocation="http://www.springframework.org/schema/beans http://www.springframework.org/schema/beans/spring-beans.xsd http://www.springframework.org/schema/context http://www.springframework.org/schema/context/spring-context.xsd">



    <!--开启属性注解扫描的配置
    <context:annotation-config></context:annotation-config>-->
    
    <!--开启包扫描(含注解扫描)
    base-package:表示要监测哪一个包下的所有类是否开启类类注解的配置
    -->
    <context:component-scan base-package="cy.pojo"></context:component-scan>
</beans>
```

> User类如下：

```java
@Component
public class User {

    @Autowired
    private Cat cat;
    @Autowired
    private Dog dog;

    @Override
    public String toString() {
        return "User{" +
                "cat=" + cat +
                ", dog=" + dog +
                '}';
    }
    
}
```

> Dog类如下：

```java
public class Dog {

    private String dogName;

    @Override
    public String toString() {
        return "Dog{" +
                "dogName='" + dogName + '\'' +
                '}';
    }
    
}
```

> Cat类如下：

```java
/**
 * 作用：@Component的做使用是，被这个注解标注的类，会告诉Spring容器，自动创建该类的对象
 * */
@Component
public class Cat {

    private String catName;

    @Override
    public String toString() {
        return "Cat{" +
                "catName='" + catName + '\'' +
                '}';
    }

}
```

测试类代码如下：

```java
 @Test
    public void test01(){

        ApplicationContext context = new
                ClassPathXmlApplicationContext("applicationContext.xml");

        User user = context.getBean(User.class);
        System.out.println(user);

    }
```

测试结果如下：

```text
User{cat=Cat{catName='null'}, dog=Dog{dogName='null'}}
```

### 6.4 Spring的@Value

创建一个spring-10-annoAssign的java项目（lib包一样）

#### 1. 简单类型赋值

```text
1.简单类型赋值语法：在类的成员变量声明前添加@Value(value="值")
2.简单类型赋值作用：取代了bean标签中的property标签
```

> Dog类的代码如下：

```java
@Component
public class Dog {

    @Value(value = "小狗")
    private String dogName;
    @Value("18")
    private int dogAge;

    @Override
    public String toString() {
        return "Dog{" +
                "dogName='" + dogName + '\'' +
                ", dogAge=" + dogAge +
                '}';
    }
}
```

编写测试类，测试代码如下：

```java
    public void test01(){
        ApplicationContext context = new
                ClassPathXmlApplicationContext("applicationContext.xml");

        Dog dog = context.getBean(Dog.class);
        System.out.println(dog);
    }
```

测试结果如下：

```text
Dog{dogName='小狗', dogAge=18}
```

#### 2. 引入外部文件时

> 在src下创建db.properties文件，代码如下：

```properties
driver=com.mysql.cj.jdbc.Driver
url=jdbc:8080
username=root
password=hsxsdm
maxCount=10
```

> 在pojo包下创建DBUtils类，代码如下：

```java
@Component
public class DBUtils {
    //简单类型初始化。如果读取外部配置文件，需要使用${变量名}来获取指定变量的值
    @Value("${driver}")
    private String driver;
    @Value("${url}")
    private String url;
    @Value("${username}")
    private String username;
    @Value("${password}")
    private String password;
    @Value("${maxCount}")
    private int maxCount;

    @Override
    public String toString() {
        return "DBUtils{" +
                "driver='" + driver + '\'' +
                ", url='" + url + '\'' +
                ", username='" + username + '\'' +
                ", password='" + password + '\'' +
                ", maxCount=" + maxCount +
                '}';
    }
}
```

> applicationContext.xml文件配置如下：

```
<?xml version="1.0" encoding="UTF-8"?>

<!--beans标签中用来配置将来要托管给Spring框架管理的对象，可以看作是一个对象的管理容器。
    配置A0P基础、事务技术、其他框架的整合技术
-->
<!--xmlns : 表示xml的命令空间http:/www.springframework.org,表示Spring的官方配置
    xmlns:xsi : 表示XML的规范XMLSchema-instance来遵循的(即进一步规范)
    xsi:schemaLocation : 表示XML书写的语法格式-->
<beans xmlns="http://www.springframework.org/schema/beans"
       xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
       xmlns:context="http://www.springframework.org/schema/context"
       xmlns:utils="http://www.springframework.org/schema/util"
       xsi:schemaLocation="http://www.springframework.org/schema/beans http://www.springframework.org/schema/beans/spring-beans.xsd http://www.springframework.org/schema/context http://www.springframework.org/schema/context/spring-context.xsd http://www.springframework.org/schema/util http://www.springframework.org/schema/util/spring-util.xsd">



    <!--开启属性注解扫描的配置
    <context:annotation-config></context:annotation-config>-->
    <!--开启包扫描(含注解扫描)
    base-package:表示要监测哪一个包下的所有类是否开启类类注解的配置
    -->
    <context:component-scan base-package="com.cy.pojo"/>

    <!--配置外部文件引入
        location : 表示加载哪一个本地的文件，需要配置文件的路径
    -->
    <context:property-placeholder location="db.properties"/>
  
</beans>
```

编写测试类，测试代码如下：

```java
  @Test
    public void test02(){
        ApplicationContext context = new
                ClassPathXmlApplicationContext("applicationContext.xml");

        DBUtils dbUtils = context.getBean(DBUtils.class);
        System.out.println(dbUtils);
    }
```

测试结果如下：

```text
DBUtils{driver='com.mysql.cj.jdbc.Driver', url='jdbc:8080', username='何世兴', password='hsxsdm', maxCount=10}
```

#### 3. 复杂类型赋值

> 复杂类型赋值语法：在类的复杂类型成员变量声明前添加@Vlue("#{@id的值}")

```text
在配置文件中，加入头文件约束：ut11
在配置文件中，使用工具标签：<uti:list><value>:1</value></util:list>
在实体类中，找到相应的复杂类型的成员变量，在其声明前添加注解@Value("#
{eid的值}")
```

> 在pojo下创建User类，代码如下：

```java
@Component
public class User {
    //2.复杂类型的变量
    //@Valve("#{@utiL标签id的取值}")：会将xml配置文件中<UtiL:list id="id值">对应的值,赋值给当前这个变量
    @Value("#{@a}")
    private List list;
    @Value("#{@b}")
    private Set set;
    @Value("#{@c}")
    private Map map;
    @Value("#{@a}")
    private String[]arr;
    @Value("#{@d}")
    private Properties pro;

    @Override
    public String toString() {
        return "User{" +
                "list=" + list +
                ", set=" + set +
                ", map=" + map +
                ", arr=" + Arrays.toString(arr) +
                ", pro=" + pro +
                '}';
    }
}
```

> applicationContext.xml文件配置如下：

```xml
<?xml version="1.0" encoding="UTF-8"?>

<!--beans标签中用来配置将来要托管给Spring框架管理的对象，可以看作是一个对象的管理容器。
    配置A0P基础、事务技术、其他框架的整合技术
-->
<!--xmlns : 表示xml的命令空间http:/www.springframework.org,表示Spring的官方配置
    xmlns:xsi : 表示XML的规范XMLSchema-instance来遵循的(即进一步规范)
    xsi:schemaLocation : 表示XML书写的语法格式-->
<beans xmlns="http://www.springframework.org/schema/beans"
       xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
       xmlns:context="http://www.springframework.org/schema/context"
       xmlns:utils="http://www.springframework.org/schema/util"
       xsi:schemaLocation="http://www.springframework.org/schema/beans http://www.springframework.org/schema/beans/spring-beans.xsd http://www.springframework.org/schema/context http://www.springframework.org/schema/context/spring-context.xsd http://www.springframework.org/schema/util http://www.springframework.org/schema/util/spring-util.xsd">



    <!--开启属性注解扫描的配置
    <context:annotation-config></context:annotation-config>-->
    <!--开启包扫描(含注解扫描)
    base-package:表示要监测哪一个包下的所有类是否开启类类注解的配置
    -->
    <context:component-scan base-package="com.cy.pojo"/>

    <!--配置外部文件引入
        location : 表示加载哪一个本地的文件，需要配置文件的路径
    -->
    <context:property-placeholder location="db.properties"/>
    <utils:list id="a">
        <value>2</value>
        <value>3</value>
    </utils:list>

    <utils:set id="b">
        <value>tom</value>
        <value>jack</value>
        <value>coco</value>
    </utils:set>

    <utils:map id="c">
        <entry key="user" value="admin"></entry>
        <entry key="pwd" value="123456"></entry>
    </utils:map>

    <utils:properties id="d">
    <prop key="name">jack</prop>
    <prop key="age">20</prop>
    </utils:properties>
</beans>
```

编写测试类，测试代码如下：

```java
 @Test
    public void test03(){
        ApplicationContext context = new
                ClassPathXmlApplicationContext("applicationContext.xml");

        User user = context.getBean(User.class);
        System.out.println(user);
    }
```

测试结果如下：

```text
User{list=[2, 3], set=[tom, jack, coco], map={user=admin, pwd=123456}, arr=[2, 3], pro={name=jack, age=20}}
```

#### 4. 引用类型赋值

> 给User类加个Dog类的引用属性，重写toString方法，代码如下：

```java
@Component
public class User {
    @Autowired
    private Dog dog;//把当前引用类型的变量名称作为Spring容器中对象的id来进行进行匹配
    //2.复杂类型的变量
    //@Valve("#{@utiL标签id的取值}")：会将xml配置文件中<UtiL:list id="id值">对应的值,赋值给当前这个变量
    @Value("#{@a}")
    private List list;
    @Value("#{@b}")
    private Set set;
    @Value("#{@c}")
    private Map map;
    @Value("#{@a}")
    private String[]arr;
    @Value("#{@d}")
    private Properties pro;

    @Override
    public String toString() {
        return "User{" +
                "list=" + list +
                ", set=" + set +
                ", map=" + map +
                ", arr=" + Arrays.toString(arr) +
                ", pro=" + pro +
                ", dog=" + dog +
                '}';
    }
}
```

测试结果如下：

```text
User{list=[2, 3], set=[tom, jack, coco], map={user=admin, pwd=123456}, arr=[2, 3], pro={name=jack, age=20}, dog=Dog{dogName='小狗', dogAge=18}}
```

### 6.5 Spring注解综合案例

**需求分析：**

> 要求使用Spring的注解，完成用户模块新增用户功的MVC分层思想的设计。

创建一个java项目，名称为spring-11-annoCompareCase。

> 创建com.cy.pojo.User类，代码如下：

```java
//是单例还是多例 single 单例  prototype 多例
@Scope("prototype")
//是否懒加载 true懒加载生效
@Lazy(true)
@Component
public class User {

    @Value("${name}")
    private String name;
    @Value("${age}")
    private int age;

    @Override
    public String toString() {
        return "User{" +
                "name='" + name + '\'' +
                ", age=" + age +
                '}';
    }
}
```

> 创建com.cy.dao.UserDao接口，代码如下：

```java
public interface UserDao {

    void addUser(User user);

}
```

> 创建com.cy.dao.UserDaoImpl实现类，代码如下：

```java
//@Component  @Repository  @Service  @Controller 注解是一样的
/**
 * @Repository   Dao层
 * @Service     Service层
 * @Controller  Controller层
 * @Component   其他
 * */
@Repository
public class UserDaoImpl implements UserDao{
    @Override
    public void addUser(User user) {

        System.out.println("新增一个用户");

    }
}
```

> 创建com.cy.service.UserService接口,代码如下：

```java
public interface UserService {

    void addUser(User user);

}
```

> 创建com.cy.service.UserServiceImpl实现类,代码如下：

```java
@Service
public class UserServiceImpl implements UserService, BeanNameAware {
    //private UserDao userDao = new UserDaoImpl();
    @Autowired
    private UserDao userDao;//自动装配中根据byType类型来进行注入操作
    @Override
    public void addUser(User user) {
        userDao.addUser(user);
    }

    @Override
    public void setBeanName(String s) {
        System.out.println("当前类创建对象的id是"+s);
    }
}

```

> 创建com.cy.controller.UserController实现类,代码如下：

```java
@Controller
public class UserController {

    @Autowired
    private UserService userService;

    public void addUser(User user){
        userService.addUser(user);
    }

}
```

> applicationContext.xml配置如下：

```xml
<?xml version="1.0" encoding="UTF-8"?>

<!--beans标签中用来配置将来要托管给Spring框架管理的对象，可以看作是一个对象的管理容器。
    配置A0P基础、事务技术、其他框架的整合技术
-->
<!--xmlns : 表示xml的命令空间http:/www.springframework.org,表示Spring的官方配置
    xmlns:xsi : 表示XML的规范XMLSchema-instance来遵循的(即进一步规范)
    xsi:schemaLocation : 表示XML书写的语法格式-->
<beans xmlns="http://www.springframework.org/schema/beans"
       xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
       xmlns:context="http://www.springframework.org/schema/context"
       xmlns:utils="http://www.springframework.org/schema/util"
       xsi:schemaLocation="http://www.springframework.org/schema/beans http://www.springframework.org/schema/beans/spring-beans.xsd http://www.springframework.org/schema/context http://www.springframework.org/schema/context/spring-context.xsd http://www.springframework.org/schema/util http://www.springframework.org/schema/util/spring-util.xsd">



    <!--开启属性注解扫描的配置
    <context:annotation-config></context:annotation-config>-->
    <!--开启包扫描(含注解扫描)
    base-package:表示要监测哪一个包下的所有类是否开启类类注解的配置
    -->
    <context:component-scan base-package="com.cy"/>

    <!--配置外部文件引入
        location : 表示加载哪一个本地的文件，需要配置文件的路径
        <context:property-placeholder location="data.properties"/>
    -->
    <!--在项目的类路径下寻找，和上面一样-->
    <context:property-placeholder location="classpath:/data.properties"/>

</beans>
```

> data.properties配置如下：

```properties
name=张三
age=21
```

> 创建com.cy.test.TestSpring,代码如下：

```java
public class TestSpring {

    @Test
    public void addUser(){
        ClassPathXmlApplicationContext context = new
                ClassPathXmlApplicationContext("applicationContext.xml");
        UserController userController = (UserController) context.getBean("userController");
        User user = (User) context.getBean("user");
        userController.addUser(user);
    }
}
```

测试结果如下：

```text
当前类创建对象的id是userServiceImpl
新增一个用户
```

## 7. 代理模式

```text
不影响被代理者的主要业务逻辑实现了额外的操佾与主要的本职工作
之间的解耦。
好处：在项目当中，可以完成目标方法的同时，还可以进行额外的事件（事
务模块)添加，同时进行解耦。
代理者==》中介。被代理者==》房东。
```

### 7.1 静态代理模式

#### 7.1.1 静态代理模式的优缺点

1. 实现了业务层与事务控制层之间的解耦。
2. 代理类能够完成本职工作的调用（目标对象的方法调用）
3. 代理类还能够完成额外的操作（对业务逻辑方法添加事务控制）

#### 7.1.2 静态代理模式的缺点

1. 一个业务模块，必须要对应着一个代理类
2. 事务控制的代码依然会有大量的重复

#### 7.1.3 静态代理模式的前提条件

静态代理模式实现的前提条件：必须要实现目标对象的相同的接口。

说明：以后在项目中，不使用静态代理模式。但是，必须要了解静态代理的实现方式、优点以及缺点。

**静态代理模式的方式：**

![screen-capture](fa1518fd4bb1859ccc1295103c6a8d1d.png)

**演示：**

创建一个spring-13-staticProxy的Java项目（和项目11完全相同）。

> 创建com.cy.proxy.Proxy类，代码如下：

```java
/**
 * 中介类
 * */
@Component("userService")
public class Proxy implements UserService {

    @Autowired
    private TransactionManager tx;
    @Autowired
    private UserService target;

    @Override
    public void addUser(User user) {
        //1.开启事务
        tx.open();
        //2.添加用户数据操作（本职工作）
        target.addUser(user);
        //3.提交事务
        tx.commit();
    }
}
```

> UserController类修改如下：

```java
@Controller
public class UserController {

    @Autowired
    private UserService userService;  //先按照id(userService)找，找不到按type找，找到的是userServiceImpl实现类。

    public void addUser(User user){
        userService.addUser(user);
    }

}

```

> 创建com.cy.proxy.TransactionManager类，代码如下：

```java
/**
 * 事务模块：将来要扩展的额外功能模块
 * */

@Component("tx")
public class TransactionManager {

    public void open() {
        System.out.println("事务开启");
    }

    public void commit() {
        System.out.println("事务提交");
    }

    public void rollback(){
    System.out.println("事务回滚");
    }

}
```

重启测试方法，测试结果如下：

```text
当前类创建对象的id是userServiceImpl
事务开启
新增一个用户User{name='"??"', age=18}
事务提交
```

### 7.2 动态代理模式

#### 7.2.1 动态代理模式介绍

1. 动态代理模式的解决方案：在代码编译期间，不存在代理类；在代码运行期间，才会自动的产生代理类和代理对象。
2. 动态代理模式解决的问题：代理类不需要事先定义，减少了代码量编写。同时解决了静态代理模式的缺点。
3. 动态代理模式的实现技术：Java的反射机制以及回调方法。
4. 动态代理模式的实现方式：DK提供的动态代理、spring提供的CGlib动态代理。

![screen-capture](b834c5cc419fa98aafa7b2d442399a7a.png)

#### 7.2.2 JDK代理模式

1. **JDK动态代理实现：**

使用了java提供的Proxy类和InvocationHandler接口来完成

2. **JDK动态代理特点：**
   
   1.优点：继承了静态代理的优点；解决了代码重复的问题；动态的生成代理类和
             代理对象。
2. 特点：目标对象和代理对象必须要实现相同的接口。
3. **JDK动态代理实现步骤分析：**

1. 创建一个动态代理的解决方案的类，jdkDynamicProxy
2. 在jdkDynamicProxy类中，添加两个成员变量：目标对象（本职的操作）、事
务控制（额外的操作）
3. 在到jdkDynamicProxy类中，添加构造方法，完成成员变量的初始化。
4. 在jdkDynamicProxy类中，自定义非静态方法getProxy(),使用java.lang.reflect.Proxy类完成动态代理生成代理类和代理对象。
5. 在jdkDynamicProxy类中，实现InvocationHandler接口，添加invoke()回调方
法，回调方法的主要作用是当客户端发起请求时，拦截到该方法，在方法中完成
额外操作和本职操作。

**创建一个spring-14-jdkDynamicProxy的Java项目（基本和上一个一样，删除Proxy类）**

> 在proxy包下创建jdkDynamicProxy类，代码如下：

```java
/**
 * jdk动态代理解决方案类，不是代理类
 * 开发步骤：
 * 1.实现接口InvocationHandler,JDK自带的接口（java.lang.reflect.InvocationHandler）
 * 2.重写invoke方法
 * */
public class jdkDynamicProxy implements InvocationHandler {


    //定义一个目标
    private Object target;
    //额外操作，事务控制模块的添加
    private TransactionManager tx;

    public jdkDynamicProxy(Object target, TransactionManager tx) {
        this.target = target;
        this.tx = tx;
    }

    /**
     *  回调方法 : 将来用于通知JDK自动生成的代理要的任务是什么
     *  1.额外工作
     *  2.本职工作
     *  invoke方法 :
     * 参数1：表示代理对象
     * 参数2：表示要执行方法
     * 参数3：执行的方法参数列表
     */


    @Override
    public Object invoke(Object o, Method method, Object[] objects) throws Throwable {

        //开启事务
        tx.open();
        //本职工作
        Object result = method.invoke(target, objects);
        //提交事务
        tx.commit();
        return result;
    }

    /**
     * 定义一个方法，自动生成代理类和代理对象
     * newProxyInstance(ClassLoader Loader,
     *                  Class<?>[]interfaces,
     *                  InvocationHandler h)
     * ClassLoader loader:类加载器。
     * 理解思路：
     * 1.代理类不存在，所以就没有相应的类加载器
     * 2.可以使其项目中的其他的类获取类加载器
     *
     * Class<?>[]interfaces:表示目标对象的类所实现的所有的接口。
     * 理解思路：
     * 1,为了让代理类看起来和目标对象的类一样，方法完全一样
     * 2,就是实现目标对象的类的所有接口
     *
     * InvocationHandler h:表东代理对象的方法重写，InvocationHandler的实现类。
     * 理解思路：
     * 1.方法的重写主要是为了完成额外的操作（事务开启与事务提交）
     * 2.完成本职工作：调用目标对象的方法
     *
     * */

    public Object getProxy(){
        //本职上最终还是转化成了一个静态代理模式
        Object proxy = Proxy.newProxyInstance(
                target.getClass().getClassLoader(),
                target.getClass().getInterfaces(),
                this);
        return proxy;
    }

}

```

编写测试方法，代码如下：

```java
    @Test
    public void test01(){
        ClassPathXmlApplicationContext context = new
                ClassPathXmlApplicationContext("applicationContext.xml");
        UserServiceImpl userService = context.getBean(UserServiceImpl.class);
        TransactionManager tx = (TransactionManager)context.getBean("tx");
        jdkDynamicProxy proxy = new jdkDynamicProxy(userService, tx);
        //告诉JDK去创建代理类和代理对象  -jdk自动创建的代理类
        UserService proxy1 = (UserService)proxy.getProxy();
        //class com.sun.proxyProxy18
        System.out.println(proxy1.getClass());
        User user = (User) context.getBean("user");
        proxy1.addUser(user);

    }
```

测试结果如下：

```text
当前类创建对象的id是userServiceImpl
class jdk.proxy2.$Proxy18
事务开启
新增一个用户User{name='"??"', age=18}
事务提交
```

**再写一个测试**

> 在service包下创建PersonService接口，代码如下：

```java
public interface PersonService {

    void addPerson(String name);

}
```

> 在service包下创建PersonServiceImpl实现类，代码如下：

```java
@Service
public class PersonServiceImpl implements PersonService{
    @Override
    public void addPerson(String name) {
        System.out.println("新增一个Person:"+name);
    }
}
```

编写测试方法，代码如下：

```java
    @Test
    public void test02(){
        ClassPathXmlApplicationContext context = new
                ClassPathXmlApplicationContext("applicationContext.xml");
        PersonService personService = context.getBean(PersonServiceImpl.class);
        TransactionManager tx = (TransactionManager)context.getBean("tx");
        jdkDynamicProxy proxy = new jdkDynamicProxy(personService, tx);
        //告诉JDK去创建代理类和代理对象  -jdk自动创建的代理类
        PersonService proxy1 = (PersonService)proxy.getProxy();
        //class com.sun.proxyProxy18
        System.out.println(proxy1.getClass());

        proxy1.addPerson("小花");

    }
```

测试结果如下：

```text
当前类创建对象的id是userServiceImpl
class jdk.proxy2.$Proxy18
事务开启
新增一个Person:小花
事务提交
```

### 7.3 CGlib动态代理模式

#### 1. CGlib动态代理实现

使用Spring提供的Enhancer类（增加类，操作二进制文件）和 MethodIntercepter接口来完成。

#### 2. CGlib动态代理特点

CGlib动态代理的特点是目标对象是作为代理对象的父类，没有必要实现接口

#### 3. CGlib动态代理实现步骤分析

1. 创建一个动态代理的解决方案的类CGlibDynamicProxy。

2. 在CGlibDynamicProxy类中，添加两个成员变量：目标对象（本职的操作)事务控制（额外的操作）
3. 在CGlibDynamicProxy类中，添加构造方法完成成员变量的初始化。
4. 在CGlibDynamicProxy类中，自定义非静态的方法getProxy(0,主要使用org.springframework.cglib.proxy.Enhancer类完成目标对象的代理类和代理对象。
5. 在CGlibDynamicProxy类中，添加回调函数，主要完成：当客户端发起请求时
拦截到该方法，进入intercept()方法中，完成额外操作和本职的方法调用。

> 在com.cy.proxy包下创建CGlibDynamicProxy类（删除jdk代理），代码如下：

```java
//CGlib动态代理解决方案类
public class CGlibDynamicProxy implements MethodInterceptor {

    private Object target;
    private TransactionManager tx;

    public CGlibDynamicProxy(Object target, TransactionManager tx) {
        this.target = target;
        this.tx = tx;
    }

    //生成代理类的对象，使用CGlib技术完成
    public Object getProxy(){
        Enhancer enhancer = new Enhancer();
        //在创建代理类的时候，代理类是目标对象的类的子类
        enhancer.setSuperclass(target.getClass());
        //设置一个回调方法
        enhancer.setCallback(this);
        //返回代理类对象
        return enhancer.create();
    }


    @Override
    public Object intercept(Object o, Method method, Object[] objects, MethodProxy methodProxy) throws Throwable {
        //1开启事务
        tx.open();
        //2.执行目标业务
        //objects目标执行的方法的参数列表
        Object result = method.invoke(target,objects);
        //3.提交事务
        tx.commit();
        //返回方法的执行结果
        return result;
    }
}
```

编写测试方法，代码如下：

```java
  @Test
    public void test01(){
        ClassPathXmlApplicationContext context = new
                ClassPathXmlApplicationContext("applicationContext.xml");
        UserServiceImpl userService = context.getBean(UserServiceImpl.class);
        TransactionManager tx = (TransactionManager)context.getBean("tx");
        CGlibDynamicProxy proxy = new CGlibDynamicProxy(userService, tx);
        //告诉JDK去创建代理类和代理对象  -jdk自动创建的代理类
        UserService proxy1 = (UserService)proxy.getProxy();
        //class com.sun.proxyProxy18
        System.out.println(proxy1.getClass());
        User user = (User) context.getBean("user");
        proxy1.addUser(user);

    }
```

<br/>

测试结果如下：

![screen-capture](e112d0329b864326b96dee8d2619403a.png)

## 8. Spring的AOP

> SpringAOP是通过**动态代理**实现的

**介绍：**

```text
1.切面：把与业务逻辑紧密结合的代码抽离出来，放在一个类中，统一的完成各个额外的功能
模块的实现，将这个类称为切面类。主要作用是：完成特定的功能模块（事务模块）的方法。
切面实现的模块主要包括（这些模块与业务逻辑无关）：数据库中的事务/数据库连接池/权
控制/日志分析/安全性的处理。
2.通知：写在切面类中的自定义方法，主要实现额外的操作。
3.切入点：一种匹配规则。比如：在service,层的UserServicelmpl类上加入切入点，就表示该
切面类中的事务控制，对JserServicelmpl中的方法生效了。只有满足了匹配规则的方法，才
能执行通知。
4.连接点：客户端通过代理对象调用的方法（完成本职的操作），主要实现本职方法的操作。
5.目标对象：真实有效的方法所在的对象。
```

**AOP设计方式：**

```text
yan'shi1.把与业务逻辑无关的代码抽离出来，写在一个类中，该就是切面类
2.切面类主要负责完成额外的操作（事务控制）以及本职的方法
3.切面类是对service层的方法进行额外操作的，那么就需要定义一个切入点，该切入点就是指向了service)层的方法
4.在执行service层的方法时，切面类先进行事务控制（事务的开启、事务的提交），那么该方法就是通知
5.在执行完额外通知后，需要进行本职工作的调用；那么本职方法的调用是通过连接点完成的(addUser0方法)。
```

![screen-capture](5bdddcd3895706b31b58c24d13794bf8.png)

**演示：**

创建一个java项目名为spring-16-AOPintroduction（lib保留,proxy包下只留TransactionManager类）。

> 在src包下创建aspect.TXAspect类，代码如下：

```java
/**
 * 切面类：定义事务的管理模块
 * */
@Component("txAspect")
public class TXAspect {

    @Autowired
    private TransactionManager tx;

    //定义一个通知:用来管理额外业务和目标方法调用的一个方法

    /**
     * ProceedingJoinPoint : 是一个接口，作用是可以调用目标的方法（自动调用满足切入点表示的方法）
     * */
    public void around(ProceedingJoinPoint joinPoint) throws Throwable {
        //开启事务
        tx.open();
        //目标方法的调用(本职工作)
        joinPoint.proceed();//连接点
        //提交事务
        tx.commit();
    }
}
```

> applicationContext.xml代码如下：

```xml
<?xml version="1.0" encoding="UTF-8"?>

<!--beans标签中用来配置将来要托管给Spring框架管理的对象，可以看作是一个对象的管理容器。
    配置A0P基础、事务技术、其他框架的整合技术
-->
<!--xmlns : 表示xml的命令空间http:/www.springframework.org,表示Spring的官方配置
    xmlns:xsi : 表示XML的规范XMLSchema-instance来遵循的(即进一步规范)
    xsi:schemaLocation : 表示XML书写的语法格式-->
<beans xmlns="http://www.springframework.org/schema/beans"
       xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
       xmlns:context="http://www.springframework.org/schema/context"
       xmlns:aop="http://www.springframework.org/schema/aop"
       xsi:schemaLocation="http://www.springframework.org/schema/beans
        http://www.springframework.org/schema/beans/spring-beans.xsd
        http://www.springframework.org/schema/context
        http://www.springframework.org/schema/context/spring-context.xsd http://www.springframework.org/schema/aop http://www.springframework.org/schema/aop/spring-aop.xsd">



    <!--开启属性注解扫描的配置
    <context:annotation-config></context:annotation-config>-->
    <!--开启包扫描(含注解扫描)
    base-package:表示要监测哪一个包下的所有类是否开启类类注解的配置
    -->
    <context:component-scan base-package="com.cy"/>

    <!--配置外部文件引入
        location : 表示加载哪一个本地的文件，需要配置文件的路径
        <context:property-placeholder location="data.properties"/>
    -->
    <!--在项目的类路径下寻找，和上面一样-->
    <context:property-placeholder location="classpath:/data.properties"/>

    <!--
    A0P开发步骤：
        1.导入A0P对象jar包
        2.在beans跟标签中引入A0P的标签的约束配置
        3.配置A0P(切面类、通知、切入点) aop:config
    -->
    <aop:config>
        <!--(1)aop:aspect 表示切面类是谁，是哪个对象-->
        <aop:aspect ref="txAspect">
            <!--(2)配置切入点
                    expression:表示切入点表达式，即表示用一个表达式来指定匹配规则(粗粒度表达式，细粒度表达式)
            -->
            <aop:pointcut id="pc" expression="within(com.cy.service.UserServiceImpl)"/>
            <!--(3)配置通知 :在切面类中自定的通知方法  method取值是切面类中某个方法的名称
                            pointcut:配置当前的通知作用哪个切入点上
             -->
            <aop:around method="around" pointcut-ref="pc"/>
        </aop:aspect>
    </aop:config>
</beans>
```

> 创建测试方法，代码如下：

```java
  @Test
    public void test01(){
        ClassPathXmlApplicationContext context = new
                ClassPathXmlApplicationContext("applicationContext.xml");
        UserController userController = context.getBean(UserController.class);
        User user = context.getBean(User.class);
        userController.addUser(user);

    }
```

测试结果如下：

```text
当前类创建对象的id是userServiceImpl
事务开启
新增一个用户User{name='zs', age=18}
事务提交
```

### 8.2 Spring的AOP原理

1. Spring AOP的底层原理是米用动态代理模式，而动态代理模式有两种：JDK的动态代理和CGlib的动态代理。

```text
当业务逻辑层有接口实现时，Spring AOP底层是采用JDK的动态代理
当业务辑层没有接口实现时，Spring AOP底层是采用cG1ib的动态代理
```

2. 修改Spring AOP默认的动态代理模式。proxy-target-class属性值为true表示基于CGlib动态代理，值为false时表示基于刊DK动态代理(默认规则)

```xml
<aop:config proxy-target-class="true">
<!--T0D0-->
</aop:config>
```

3. Spring AOP的调用过程：

```text
1.当客户端发起请求时，先找到切面类的环绕通知方法around;
2.在环绕通知方法内先执行额外的操作，再根据切入点表达式的匹配规则找到需要执行的本职工作的方
法；
3.然后ProceedingJoinPoint接口通过反射机制，找到连接点对应的本职操作方法，并执行本职方
法。
```

**演示：**

编写测试方法，代码如下：

```java
 @Test
    public void test01(){
        ClassPathXmlApplicationContext context = new
                ClassPathXmlApplicationContext("applicationContext.xml");
        UserController userController = context.getBean(UserController.class);
        User user = context.getBean(User.class);
        userController.addUser(user);
        //$$ -CGlib & -jdk
        UserService userService = (UserService) context.getBean(UserService.class);
        System.out.println(userService.getClass());
        
    }
```

测试结果如下：

```text
当前类创建对象的id是userServiceImpl
事务开启
新增一个用户User{name='??', age=18}
事务提交
class jdk.proxy2.$Proxy18
```

> <aop:config proxy-target-class ="">设置Spring AOP的动态代理模式的
   true:CGLib动态代理模式
   false:使用JDK动态代理模式

### 8.3 Spring的切入点表达式

Spring的切入点表达式分为：粗粒度的表达式、细粒度表达式。

#### 8.3.1 粗粒度表达式within()

```xml
<aop:pointcut expression="within(包名.类名)"
```

测试方法代码如下：

```java
 /**
     * within(com.cy.service.UserServiceImpL)·当前类中所有的方法都被作用此通知
     * */
    @Test
    public void test02(){
        ClassPathXmlApplicationContext context = new
                ClassPathXmlApplicationContext("applicationContext.xml");
        UserController userController = context.getBean(UserController.class);
        User user = context.getBean(User.class);
        userController.addUser(user);
        userController.updateUser(user);
        //$$ -CGlib & -jdk
        UserService userService = (UserService) context.getBean(UserService.class);
        System.out.println(userService.getClass());

    }
```

测试结果如下：

```text
当前类创建对象的id是userServiceImpl
事务开启
新增一个用户User{name='??', age=18}
事务提交
事务开启
更新一个用户User{name='??', age=18}
事务提交
class jdk.proxy2.$Proxy18
```

测试代码如下：

```java
 /**
     * within(com.cy.service.*)·当前类中所有的方法都被作用此通知
     * */
    @Test
    public void test03(){
        ClassPathXmlApplicationContext context = new
                ClassPathXmlApplicationContext("applicationContext.xml");
        UserController userController = context.getBean(UserController.class);
        User user = context.getBean(User.class);
        userController.addUser(user);
        userController.updateUser(user);
        userController.addPerson("小花");
        //$$ -CGlib & -jdk
        UserService userService = (UserService) context.getBean(UserService.class);
        System.out.println(userService.getClass());

    }
```

测试结果如下：

```text
当前类创建对象的id是userServiceImpl
事务开启
新增一个用户User{name='??', age=18}
事务提交
事务开启
更新一个用户User{name='??', age=18}
事务提交
新增一个Person:小花
class jdk.proxy2.$Proxy18

```

#### 8.3.2 细粒度表达式execution()

```xml
<aop:pointcut expression="execution(返回值类型  包名.类名.方法名(包名.类名，包名.类名))"
```

环绕通知around方法返回值类型建议设置成Object类型。

修改applicationContext.xml中的配置，如下：

```xml
  <!--<aop:pointcut id="pc" expression="within(com.cy.service.UserServiceImpl)"/>-->
            <aop:pointcut id="pc" expression="execution(void com.cy.service.UserServiceImpl.addUser(com.cy.pojo.User))"/>
```

编写测试方法，代码如下：

```java
 /**
     * execution(void com.cy.service.UserServiceImpl.addUser(com.cy.pojo.User))·当前类中的addUser方法被作用此通知
     * */
    @Test
    public void test04(){
        ClassPathXmlApplicationContext context = new
                ClassPathXmlApplicationContext("applicationContext.xml");
        UserController userController = context.getBean(UserController.class);
        User user = context.getBean(User.class);
        userController.addUser(user);
        userController.updateUser(user);
        userController.addPerson("小花");
        //$$ -CGlib & -jdk
        UserService userService = (UserService) context.getBean(UserService.class);
        System.out.println(userService.getClass());

    }
```

测试结果如下：

```text
当前类创建对象的id是userServiceImpl
事务开启
新增一个用户User{name='??', age=18}
事务提交
更新一个用户User{name='??', age=18}
新增一个Person:小花
class jdk.proxy2.$Proxy18
```

修改applicationContext.xml中的配置，如下：

```xml
 <!--<aop:pointcut id="pc" expression="within(com.cy.service.UserServiceImpl)"/>-->
            <!--<aop:pointcut id="pc" expression="execution(void com.cy.service.UserServiceImpl.addUser(com.cy.pojo.User))"/>-->
            <aop:pointcut id="pc" expression="execution(void com.cy.service.UserServiceImpl.*(com.cy.pojo.User))"/>
```

如果是多个参数，用“..”忽略：

```xml
 <aop:pointcut id="pc" expression="execution(void com.cy.service.UserServiceImpl.*(..))"/>
```

编写测试方法，代码如下：

```java
 /**
     * execution(void com.cy.service.UserServiceImpl.*(com.cy.pojo.User))·当前类中的参数（只有一个参数）是User类的方法被作用此通知
     * */
    @Test
    public void test05(){
        ClassPathXmlApplicationContext context = new
                ClassPathXmlApplicationContext("applicationContext.xml");
        UserController userController = context.getBean(UserController.class);
        User user = context.getBean(User.class);
        userController.addUser(user);
        userController.updateUser(user);
        userController.addPerson("小花");
        //$$ -CGlib & -jdk
        UserService userService = (UserService) context.getBean(UserService.class);
        System.out.println(userService.getClass());

    }
```

测试结果如下：

```text
当前类创建对象的id是userServiceImpl
事务开启
新增一个用户User{name='??', age=18}
事务提交
事务开启
更新一个用户User{name='??', age=18}
事务提交
新增一个Person:小花
class jdk.proxy2.$Proxy18
```

修改applicationContext.xml中的配置，如下：

```xml
 <!--<aop:pointcut id="pc" expression="within(com.cy.service.UserServiceImpl)"/>-->
            <!--<aop:pointcut id="pc" expression="execution(void com.cy.service.UserServiceImpl.addUser(com.cy.pojo.User))"/>-->
            <!--<aop:pointcut id="pc" expression="execution(void com.cy.service.UserServiceImpl.*(com.cy.pojo.User))"/>-->
            <aop:pointcut id="pc" expression="execution(void com.cy.service.*.*(..))"/>
```

```xml
execution(void com.cy.service.*.*(..)) service包下的所有类的所有方法
```

```
execution(void com.cy.service..*.*(..)) service包下的所有包下所有类的所有方法
```

编写测试方法，代码如下：

```java
  /**
     * execution(void com.cy.service.*.*(..))·service层下所有的类的方法被作用此通知
     * */
    @Test
    public void test06(){
        ClassPathXmlApplicationContext context = new
                ClassPathXmlApplicationContext("applicationContext.xml");
        UserController userController = context.getBean(UserController.class);
        User user = context.getBean(User.class);
        userController.addUser(user);
        userController.updateUser(user);
        userController.addPerson("小花");
        //$$ -CGlib & -jdk
        UserService userService = (UserService) context.getBean(UserService.class);
        System.out.println(userService.getClass());

    }
```

测试结果如下：

```text
当前类创建对象的id是userServiceImpl
事务开启
新增一个用户User{name='??', age=18}
事务提交
事务开启
更新一个用户User{name='??', age=18}
事务提交
事务开启
新增一个Person:小花
事务提交
class jdk.proxy2.$Proxy18
```

### 8.3 Spring的AOP注解

#### 介绍

1. 为简化applicationContext.xml核心配置文件AOP的配置，Spring提供了使用注解的形式来开发AOP达到简化的目的。
2. 自定义注解最主要的目的是，精确的控制业务逻辑中的每一个方法，便于开发者根据不同的需求有选择性的添加注解。

**演示：**

创建一个java项目名为spring-18-AOPAnno（复制16，都保留）。

> applicationContext.xml的配置如下：

```xml
<?xml version="1.0" encoding="UTF-8"?>

<!--beans标签中用来配置将来要托管给Spring框架管理的对象，可以看作是一个对象的管理容器。
    配置A0P基础、事务技术、其他框架的整合技术
-->
<!--xmlns : 表示xml的命令空间http:/www.springframework.org,表示Spring的官方配置
    xmlns:xsi : 表示XML的规范XMLSchema-instance来遵循的(即进一步规范)
    xsi:schemaLocation : 表示XML书写的语法格式-->
<beans xmlns="http://www.springframework.org/schema/beans"
       xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
       xmlns:context="http://www.springframework.org/schema/context"
       xmlns:aop="http://www.springframework.org/schema/aop"
       xsi:schemaLocation="http://www.springframework.org/schema/beans
        http://www.springframework.org/schema/beans/spring-beans.xsd
        http://www.springframework.org/schema/context
        http://www.springframework.org/schema/context/spring-context.xsd http://www.springframework.org/schema/aop http://www.springframework.org/schema/aop/spring-aop.xsd">



    <!--开启属性注解扫描的配置
    <context:annotation-config></context:annotation-config>-->
    <!--开启包扫描(含注解扫描)
    base-package:表示要监测哪一个包下的所有类是否开启类类注解的配置
    -->
    <context:component-scan base-package="com.cy"/>

    <!--配置外部文件引入
        location : 表示加载哪一个本地的文件，需要配置文件的路径
        <context:property-placeholder location="data.properties"/>
    -->
    <!--在项目的类路径下寻找，和上面一样-->
    <context:property-placeholder location="classpath:/data.properties"/>

    <!--开启AOP注解扫描-->
    <aop:aspectj-autoproxy/>

</beans>
```

> TXAspect类的配置如下：

```java
/**
 * 切面类：定义事务的管理模块
 * */
@Component("txAspect")
/**
 * 把当前类指定为切面类
 * */
@Aspect
public class TXAspect {

    @Autowired
    private TransactionManager tx;

    //定义一个通知:用来管理额外业务和目标方法调用的一个方法

    /**
     * ProceedingJoinPoint : 是一个接口，作用是可以调用目标的方法（自动调用满足切入点表示的方法）
     * */
    //环绕通知：通过注解的形式来配置当前的通知作用在那个位置上
    @Around("execution(* com.cy.service..*.*(..)) && @annotation(trans)")//参数：参数要求接收的是切入点表达式
    public void around(ProceedingJoinPoint joinPoint , Transactional trans) throws Throwable {
        //开启事务
        tx.open();
        //目标方法的调用(本职工作)
        joinPoint.proceed();//连接点
        //提交事务
        tx.commit();
    }
}
```

> 在src下创建anno.Transactional注解，代码如下：

```java
/**
 * 自定义注解
 */
@Deprecated
@Retention(RetentionPolicy.RUNTIME) //在运行阶段
@Target(ElementType.METHOD) //此注解只修饰方法
public @interface Transactional {
    
}
```

> 在UserServiceImpl类的addUser方法前面加自定义注解，代码如下：

```java
    @Override
    @Transactional
    public void addUser(User user) {
        userDao.addUser(user);
    }
```

运行test06方法，测试结果如下：

```
当前类创建对象的id是userServiceImpl
事务开启
新增一个用户User{name='??', age=18}
事务提交
更新一个用户User{name='??', age=18}
新增一个Person:小花
class jdk.proxy2.$Proxy22
```

### 8.4 Spring的五大通知

#### 1. 环绕通知（Around Advice）

在目标方法执行之前和之后都可以执行额外代码的通知。在环绕通知中必须显式的调用
目标方法，.目标万法才会执行，这个显式调用时通过ProceedingjoinPoInt来实现的，
可以在环绕通知中接收一个此类型的形参，Spring容器会自动将该对象传入，注意这个
参数必须处在环绕通知的第一个形参位置。

> 注意·只有环绕通知可以接收ProeedingJoinPoint作为参数，而具他通知只能接收JoinPoint作为参数.

#### 2. 前置通知（Before Advice）

在目标方法执行之前执行执行的通知。前置通知方法，可以没有参数，也可以额外接收
一个joinPoint作为参数，Spring会自动将该对象传入，代表当前的连接点，通过该对
象可以获取目标对象和目标方法相关的信息。

> 注意，如果前置通知接收joinPoint作为参数，必须保证其为方法的第一个参数
否则会报错。

#### 3. 后置通知（AfterReturning Advice）

在目标方法执行之后执行的通知。在后置通知中也可以选择性的接收一个joinPoint作
为参数，用于获取连接点的额外信息，必须保证其为方法的第一个参数。在后置通知
中，还可以通过配置获取环绕通知的返回值。如果目标方法抛出异常，则后置通知不会
执行。

#### 4. 异常通知（AfterThrowing Advice）

在目标方法抛出异常时执行的通知。在异常通知中也可以选择性的接收一个joinPoint
作为参数，用于获取连接点的额外信息，必须保证其为方法的第一个参数。另外还可以
配置参数，让异常通知可以接收到目标方法抛出的异常对象。

#### 5. 最终通知（After Advice）

是在目标方法执行之后执行的通知。最终通知无论如何都会在目标方法调用过后执行，
即使目标方法没有正常的执行完成。最终通知无法获取到环绕通知的返回值。最终通知
可以接收JoinPoint作为参数，来获取目标对象和目标方法相关信息，但必须保证其为
方法的第一个参数。

**演示：**

创建一个Java项目名为spring-19-around（和上一个一样）。

> TXAspect类代码如下：

```java
y/**
 * 切面类：定义事务的管理模块
 * */
@Component("txAspect")
/**
 * 把当前类指定为切面类
 * */
@Aspect
public class TXAspect {

    @Autowired
    private TransactionManager tx;

    //定义一个通知:用来管理额外业务和目标方法调用的一个方法

    /**
     * ProceedingJoinPoint : 是一个接口，作用是可以调用目标的方法（自动调用满足切入点表示的方法）
     * */
    //环绕通知：通过注解的形式来配置当前的通知作用在那个位置上
    //1.环绕通知
    @yAround("execution(* com.cy.service..*.*(..)) && @annotation(trans)")//参数：参数要求接收的是切入点表达式
    public void around(ProceedingJoinPoint joinPoint , Transactional trans) throws Throwable {
        //开启事务
        tx.open();
        //目标方法的调用(本职工作)
        joinPoint.proceed();//连接点
        //提交事务
        tx.commit();
    }

    //2.前置通知： 被@Before（org.aspectj.lang.annotation.Aspect）修饰
    @Before("execution(* com.cy.service..*.*(..))")
    public void before(JoinPoint joinPoint){
        System.out.println("前置通知执行");
        Class targetClass = joinPoint.getTarget().getClass();//获取目标对象对应的类
        System.out.println("目标对象对应的类"+targetClass);
        //获取该类中方法的签名对象
        MethodSignature methodSignature = (MethodSignature) joinPoint.getSignature();
        //获取目标方法的名称
        String methodName = methodSignature.getName();
        System.out.println("目标方法的名称"+methodName);
    }


    //后置通知：在目标方法执行完成后波执行.如果目标方法有异常后置通知不会被执行
    @AfterReturning("execution(* com.cy.service..*.*(..))")
    public void afterReturning(){
        System.out.println("后置通知执行");
    }

    /**@AfterThrowing:表示异常通知，即目标方法如果产生异常，则会被自动调用的通知
     * throwing:参数表示用来指定当前的这个自定义异常通知在什么类型异常发生才会被触发
     */
    @AfterThrowing(value = "execution(* com.cy.service..*.*(..))",throwing ="throwable" )
    public void afterThrowing(JoinPoint joinPoint,Throwable throwable){
        System.out.println("异常通知"+throwable.getMessage());
    }

    /**
     *@After:表示最终通知、无论程序是否有异常，目标方法执行完后，一定会被调用的通知
     */
    @After("execution(* com.cy.service..*.*(..))" )
    public void after(){
        System.out.println("最终通知");
    }

}
```

运行测试方法test06,结果如下：

```text
当前类创建对象的id是userServiceImpl
事务开启
前置通知执行
目标对象对应的类class com.cy.service.UserServiceImpl
目标方法的名称addUser
新增一个用户User{name='??', age=18}
事务提交
最终通知
后置通知执行
前置通知执行
目标对象对应的类class com.cy.service.UserServiceImpl
目标方法的名称updateUser
更新一个用户User{name='??', age=18}
最终通知
后置通知执行
前置通知执行
目标对象对应的类class com.cy.service.PersonServiceImpl
目标方法的名称addPerson
新增一个Person:小花
最终通知
后置通知执行
class jdk.proxy2.$Proxy26
```

> UserServiceImpl类的addUser方法修改如下：

```java
 @Override
    @Transactional
    public void addUser(User user) {

        //int a=1/0;
        userDao.addUser(user);
    }
```

重新运行测试方法，测试结果如下：

```text
当前类创建对象的id是userServiceImpl
事务开启
前置通知执行
目标对象对应的类class com.cy.service.UserServiceImpl
目标方法的名称addUser
最终通知
异常通知/ by zero
```

> 最终方法无论报不报错都执行，可以在其中加入其他方法执行语句。

**多个切面环绕通知执行流程：**

![screen-capture](74846f83266b36520796f62b30c34426.png)

> 在aspect包下把TXAspect类上的@Aspect注解注释掉，创建AroundA类，代码如下：

```java
@Aspect
@Component
public class AroundA {

    @Around("execution(* com.cy.service.PersonServiceImpl.addPerson(..))")
    public void around(ProceedingJoinPoint joinPoint) throws Throwable {
        System.out.println("切面A环绕开始");
        //调用目标方法
        joinPoint.proceed();
        System.out.println("切面A环绕结束");
    }

}
```

> 在aspect包下创建AroundB类，代码如下：

```java
@Aspect
@Component
public class AroundB {

    @Around("execution(* com.cy.service.PersonServiceImpl.addPerson(..))")
    public void around(ProceedingJoinPoint joinPoint) throws Throwable {
        System.out.println("切面B环绕开始");
        //调用目标方法
        joinPoint.proceed();
        System.out.println("切面B环绕结束");
    }

}
```

编写测试代码如下：

```java
 //多个通知同时作用一个目标方法上，观察执行的流程
    @Test
    public void test07(){
        ClassPathXmlApplicationContext context = new
                ClassPathXmlApplicationContext("applicationContext.xml");
        UserController userController = context.getBean(UserController.class);
        User user = context.getBean(User.class);
        
        userController.addPerson("小花");

    }

```

运行结果如下：

```text
当前类创建对象的id是userServiceImpl
切面A环绕开始
切面B环绕开始
新增一个Person:小花
切面B环绕结束
切面A环绕结束
```

### 8.5 Spring的AOP综合案例

1.项目需求：对业务逻辑层的方法添加权限控制当用户访问相关业务模块首先判断是否有权限，有则执行无则拦截。
2.实现思路：定义一个权限列表类，然后再在类中定义一个静态成员变量LSt集合用于存储用于的权限列表。

创建一个java项目名为spring-20-permission（和上一个一样）。

> 删除aspect包下的所有类，创建一个PermissionAspect类，代码如下：

```java
/**
 * 权限切面类
 */
@Component
@Aspect
public class PermissionAspect {

    @Around("execution(* com.cy.service..*.*(..))")
    public Object around(ProceedingJoinPoint joinPoint) throws Throwable {
        Object result = null;
        //1.获取目标对象的类型（目标类)
        Class targetclass = joinPoint.getTarget().getClass();
        //2.获取目标方法签名对象
        MethodSignature methodSignature = (MethodSignature) joinPoint.getSignature();
        //3.获取方法名称
        String methodName = methodSignature.getName();
        //4.获取方法的参数列表
        Class[] argsCLass = methodSignature.getParameterTypes();
        //5.通过Java的反射完成方法的创建
        Method method = targetclass.getMethod(methodName, argsCLass);
        //6.判断目标方法是有被某个指定的注解修饰
        if (method.isAnnotationPresent(PermissionAnn.class)) {
            //7.获取指定注解
            PermissionAnn permissionAnn =
                    method.getAnnotation(PermissionAnn.class);
            //8,通过注解对象来获取此注解上对应的参数值
            String value = permissionAnn.value();//通过参数名来获取参数的值
            //9.获取到的权限和权限列表中的元素比较，如果列表中存在，则表示用户有这个权限
            List<String> permissionList = PermissionUtil.getPermissionList();
            if (permissionList.contains(value)) {
                System.out.println("恭喜你，有操作权限");
                //则调用目标方法
                result = joinPoint.proceed();
            } else {
                System.out.println("对比起，你没有权限操作");
            }

        }else{
            //调用目标方法
            joinPoint.proceed();
        }
        return result;
    }
}

```

> 在anno包下创建PermissionAnn类，代码如下：

```java
/**
 * 标签权限注解
 */
@Documented
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.METHOD)
public @interface PermissionAnn {

        String value();//用于接收权限的英文单词

}
```

> UserServiceImpl类的addUser方法修改如下：

```java
    @Override
    @Transactional
    @PermissionAnn( value = "add" )//add: 有添加用户数据的权限
    public void addUser(User user) {
      userDao.addUser(user);
    }
```

编写测试方法，代码如下：

```java
 @Test
    public void test08(){
        ClassPathXmlApplicationContext context = new
                ClassPathXmlApplicationContext("applicationContext.xml");
        List<String> list = new ArrayList<>();
        list.add("add");
        list.add("find");
        PermissionUtil.setPermissionList(list);
        UserController userController = context.getBean(UserController.class);
        User user = context.getBean(User.class);

       userController.addUser(user);

    }
```

测试结果如下：

```text
当前类创建对象的id是userServiceImpl
恭喜你，有操作权限
新增一个用户User{name='??', age=18}
```

> UserServiceImpl类的addUser方法修改如下：

```text
    @Override
    @Transactional
    @PermissionAnn( value = "addUser" )//add: 有添加用户数据的权限
    public void addUser(User user) {
      userDao.addUser(user);
    }
```

重启测试方法，测试结果如下：

```text
当前类创建对象的id是userServiceImpl
对比起，你没有权限操作
```
## 1 Spring Security介绍

1.Shrio也是一个权限认证的框架，不介绍。
2.Outh2:针对大型的系统而设计的，金融系统、银行业务。
3.Spring Security:Spring家族对应的官方推荐的安全认证框架。

![screen-capture](d7770a367c6500bf46c470aa98f64cc5.png)

## 2 Spring Security快速入门

Spring Security主要的概念：

- 认证：Authentication

- 授权：Authenrization

### 2.1搭建Spring Security的基础环境

1. 创建-个项目spring.security_demo（选spring web、Thymeleaf）。
2. 导入Spring Securityl的相关依赖。
3. 配置Spring Security的安全管理。

### 2.2搭建安全管理Spring Security测试环境

1. 导入Spring Security的相关依赖：Spring提供了一个Spring Security的启动器。
   > 一旦引入了Spring Security的启动器，Spring Security、WebFlux的相关的安全功能部分已经生效。

2. Spring Security的配置。
   ```text
     <dependency>
               <groupId>org.springframework.boot</groupId>
               <artifactId>spring-boot-starter-security</artifactId>
     </dependency>
   ```

3. 启动项目的主类。
   
   控制台输出：

```text
Using generated security password: 3b409619-2b66-4f46-8926-6549ff9c40c5
```

4. 访问localhost:8080地址的时候，安全框架自动拦截了目标访问的资源，直接跳转
到http:/localhost:8080/login。
5. 默认情况下，安全框架自动生成一个登录页面，还生成一组登录的用户信息

```
用户名：user
密码：3b409619-2b66-4f46-8926-6549ff9c40c5（每次启动主类刷新）
```

## 3 MVC Security介绍

使用Spring Boot与Spring MVC进行Web开发时，如果项目引入spring-boot-starter-security依赖启动器，MVC Security:安全管理功能就会自动生效，其默认的安全配置是在**SecurityAutoConfiguration**和**UserDetailsServiceAutoConfiguration**中实现的。其中，SecurityAutoConfiguration会导入并自动化配置SpringBootWebSecurityConfiguration用于启动Web安全管理，UserDetailsServiceAutoConfiguration.则用于配置用户身份信息。

<br/>

自定义安全管理模块：

- WebSecurityConfigurerAdapter用来管理安全框架的配置，如果开发者想去自定义安全管理，需要实现这个这接口。自定义一个类，然后实现接口或者其他类。配置通常会被@Configration注解修饰。
- 实现抽象方法、或者重写父类或者父接口中的部分方法。

|方法|描述|
|--|--|
|configure(AuthenticationManagerBuilder auth)|定制用户认证管理器来实现用户认证|
|configure(HttpSecurity http)|定制基本HTTP请求的用户访问控制|

<br/>

<br/>

通过自定义WebSecurityConfigurerAdapter类型的Bean组件，可以完全关闭Security提供的Web应用默认安全配置，但是不会关闭UserDetailsService.用户信息自动配置类。如果要关闭UserDetailsService默认用户信息配置可以自定UserDetailsService、AuthenticationProvider或AuthenticationManager类型的Bean组件。另外，可以通过自定义WebSecurityConfigurerAdapter类型的Bean组件覆盖默认访问规则。Spring Boot提供了非常多方便的方法，可用于覆盖请求映射和静态资源的访问规则。

## 4 自定义用户认证

WebSecurityConfigurerAdapter:提供了S中用户自定义认证。使用configure(Authentic

ationManagerBuilderauth)方法来完成用户的自定义认证。

自定义用户认证方式分类见下：学习前三种认证方式。

- 内存身份认证
- JDBC身份认证
- 身份详情服务认证
- LDAP身份认证（了解）
- 身份认证提供商

### 4.1内存身份认证

ln-Memeory Authentication,内存身份认证。基于内存中数据来进行验证，用来体验权限认证配置。

![screen-capture](d3ea17a135ab2172773712e003ffa009.png)

#### 4.1.1自定义WebSecurityConfigurerAdapter

自定义一个类（com.cy.controller.SecurityConfig），去继承WebSecurityConfigurerAdapter。重写configure(AuthenticationManagerBuilder auth)方法即可。

@EnableWebSecurity注解源代码

```text
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.TYPE})
@Documented
@Import({WebSecurityConfiguration.class, SpringWebMvcImportSelector.class, OAuth2ImportSelector.class, HttpSecurityConfiguration.class})
@EnableGlobalAuthentication
@Configuration
public @interface EnableWebSecurity {
    boolean debug() default false;
}

```

 语法解析：

- @Import:表示根据当前的pom.xml文件引入的Web模块的依赖和安全框架的依赖进行自动的配置。
- @EnableGlobalAuthentication:表示用于开启自动的安全的全局配置（表示在项目中任何位置都生效）。
- @Configuration:表示当前被修饰的类是一个配置类。
- @EnableWebSecurity:是一个组合注解。

#### 4.1.2使用内存进行身份认证

重写configure(AuthenticationManagerBuilder auth)方法即可。此方法内部完成认证的自定义配置(5种)。

1.重写了configure(AuthenticationManagerBuilder auth)方法

```
SecurityConfig/**
 *Security安全框架的配置类：
 *1.继承WebSecurityConfigurerAdapter类。
 *2.重写方法configure(AuthenticationManagerBuilder auth)。
 *3.开启Security的安全配置的自定义支持，使用一个注解：@EnableWebSecurity。
 */
@EnableWebSecurity
public class SecurityConfig extends WebSecurityConfigurerAdapter {
    /**自定义用户认证的管理
     * 参数：AuthenticationManagerBuilder,表示配置用户的权限认证方式
     * */
    @Override
    protected void configure(AuthenticationManagerBuilder auth)throws Exception{
    //1.基于内存认证：
    /**
     *默认的登录页面：用户的登录信总，包含用户的名称、密码。
     *1,如何在内存中声明一组用户名车密码？
     *2,将用户内存中的信息关联上AuthenticationManagerBuilder对象上。
     */
        //表示获取指定的密码编码器，必须要指定，否则话启动程序会报错。
        BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
        //1.inMemoryAuthentication()表示基于内存认证，用户的密码必须加密，指定密码的加密方式。
        auth.inMemoryAuthentication().passwordEncoder(encoder)
        //设置用户名、设置按照指定密码器的初始化密码、设置了tom这个用户对应的角色（表示c0mmo目录下的的资源可以被访问）
        .withUser("tom").password(encoder.encode("123456")).roles("common")
         .and()//表示同时声明一组用户信息的初始化配置
         .withUser("李四").password(encoder.encode("123456")).roles("vip");

    }

}

```

2.重启系统，然后访问项目，通过内存中配置的用户信息，进行登录，可以完成对应的登录。
3.当输入错的信息，重定向到http:/ocalhost:8080/login?error。

### 4.2 JDBC身份认证

1.SQL准备

```text
create DATABASE springboot;
use springboot;

#创建表t_customer并插入相关数据
DROP TABLE IF EXISTS 't_customer';
CREATE TABLE t_customer(
id int(20) NOT NULL AUTO_INCREMENT,
username varchar(200) DEFAULT NULL,
password varchar(200) DEFAULT NULL,
valid tinyint(1) NOT NULL DEFAULT '1',#表示当前用户是否过
PRIMARY KEY(`id`)
)ENGINE=InnoDB DEFAULT CHARSET=utf8;
#$2a$10$5000I8dir8jv0/gCalsix.GpzAdIPf6pMqdminz/3ijYziv
INSERT INTO t_customer VALUES (1,'tom','$2a$10$5ooQI8dir8jv0/gCalsix.GpzAdIPf6pMqdminZ/3ijYzivCyPlfK','1'); 
INSERT INTO t_customer VALUES(2,'李四','$2a$10$5ooQI8dir8jv0/gCalsix.GpzAdIPf6pMqdminZ/3ijYzivCyPlfK','1');



#创建表t_authority并插入相关数据
DROP TABLE IF EXISTS t_authority;
CREATE TABLE t_authority(
id int(20) NOT NULL AUTO_INCREMENT,
authority  varchar(20) DEFAULT NULL COMMENT '权限',
PRIMARY KEY (id)
)ENGINE=InnoDB DEFAULT CHARSET=utf8;
INSERT INTO t_authority VALUES
('1','ROLE_common')
INSERT INTO t_authority VALUES ('2','ROLE_vip')
#创建表t_customer_authority并插入相关数据
DROP TABLE IF EXISTS t_customer_authority;
CREATE TABLE t_customer_authority(
id int(11) NOT NULL AUTO_INCREMENT,
`customer_id`int(11) NOT NULL COMMENT '关联的用户id',
`authority_id`int(11) NOT NULL COMMENT'关联的权限id',
PRIMARY KEY (id)
)ENGINE=InnoDB DEFAULT CHARSET=utf8;
INSERT INTO
t_customer_authority VALUES ('1','1','1');
INSERT INTO
t_customer_authority VALUES ('2','2','2');
```

2.依赖

```text
     <!--My5QL数据连接辽动-->
    <dependency>
    <groupId>com.mysql</groupId>
    <artifactId>mysql-connector-j</artifactId>
    <scope>runtime</scope>
    </dependency>
    <!--JDBC数据库连接启动器-->
        <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-jdbc</artifactId>
    </dependency>
```

3.数据库配置

```text
#MySOL数据库连接配置
spring:
  datasource:
    url:jdbc:mysql://localhost:3306/springboot?useUnicode=true&characterEncoding=utf8&useSSL=false&serverTimezone=UTC
    username:root
    password:hsxsdm
```

#### 4.2.3 使用JDBC进行身份认证

在重写的config方法中，去定义新的认证方式

```
package com.cy.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import javax.sql.DataSource;

/**
 *Security安全框架的配置类：
 *1.继承WebSecurityConfigurerAdapter类。
 *2.重写方法configure(AuthenticationManagerBuilder auth)。
 *3.开启Security的安全配置的自定义支持，使用一个注解：@EnableWebSecurity。
 */
@EnableWebSecurity
public class SecurityConfig extends WebSecurityConfigurerAdapter {

    @Autowired
    private DataSource dataSource; //连接目标数据库对象

    /**自定义用户认证的管理
     * 参数：AuthenticationManagerBuilder,表示配置用户的权限认证方式
     * */
    @Override
    protected void configure(AuthenticationManagerBuilder auth)throws Exception{
    //1.基于内存认证：
    /**
     *默认的登录页面：用户的登录信总，包含用户的名称、密码。
     *1,如何在内存中声明一组用户名车密码？
     *2,将用户内存中的信息关联上AuthenticationManagerBuilder对象上。
     */
      /**  //表示获取指定的密码编码器，必须要指定，否则话启动程序会报错。
        BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
        //1.inMemoryAuthentication()表示基于内存认证，用户的密码必须加密，指定密码的加密方式。
        auth.inMemoryAuthentication().passwordEncoder(encoder)
        //设置用户名、设置按照指定密码器的初始化密码、设置了tom这个用户对应的角色（表示c0mmo目录下的的资源可以被访问）
        .withUser("tom").password(encoder.encode("123456")).roles("common")
         .and()//表示同时声明一组用户信息的初始化配置
         .withUser("李四").password(encoder.encode("123456")).roles("vip");
        */

        //2.使用JDBC进行身份认证
        //2.1查询数据库中的数据是否存在
        String userSql = "select username,password,valid from t_customer where username=?";
        //查询用户的权限信息
        String authentySql = "select c.username,a.authority from t_customer c,t_authority a,t_customer_authority ca "+
        "where ca.customer_id=c.id and ca.authority_id=a.id and c.username=?";
        //2.2结合安全框架的AuthenticationManagerBuilder的对象实现JDBC身份认证的判断
        //(1)表示需要声明密码的编码器
        BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
        //(2)构建JDBC认证的自定义配置
        auth.jdbcAuthentication().passwordEncoder(encoder)
                .dataSource(dataSource)//数据源
                .usersByUsernameQuery(userSql)//根据指定的用户名查询用户的数据信息
                .authoritiesByUsernameQuery(authentySql);//根据指定的权限进行查询


    }

}

```

### 4.3 UserDetailsService身份认证

如果编写了登录业务：

- UserController-login(username,password)
- UserService -login(username,password)
- UserMapper-login(username,password)
- UserDetailsService身份认证可以根据项目的MVC分层架构来实现对应的身份认证。

#### 4.3.1搭建持久层

**ORM的编写**

1.导入JPA依赖。

```text
  <!--导入Spring Data JPA的依赖-->
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-data-jpa</artifactId>
        </dependency>
        <!--导入Lombok依赖-->
        <dependency>
            <groupId>org.projectlombok</groupId>
            <artifactId>lombok</artifactId>
        </dependency>
```

<br/>

2.创建实体类。每一张表对应有实体类。

（1）实体类Customer的映射

```text
/**
 * 用户实体类
 * */

@Data
@Entity(name = "t_customer")//表示与数据库中那一张表映射
public class Customer implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    private String username;
    private String password;
    private Boolean Valid;
}
```

（2）实体类autority的映射

```text
@Data
@Entity(name = "t_authority")
public class Authority implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    private String authority;

}
```

**编写Repository接口**

1.需要实现一个接口jspRepository，可以自定义相关CRUD复杂方法

```text
package com.cy.repository;

import com.cy.pojo.Customer;
import org.springframework.data.jpa.repository.JpaRepository;
/**
 * JPA持久层接口
 * */
public interface CustomerRepository extends JpaRepository<Customer,Integer> { //<T,Type> 对应类 主键类型

    //findByXxxx:Xxxx表示查询字段的条件，转化成where条件：where username=?
    Customer findByUsername(String username);

}

```

<br/>

```text
/**
 * 权限认证的接口
 * */
public interface AuthorityRepository extends JpaRepository<Authority,Integer> {

    /**
     *注解@Query:表示给JPA的持久层接口方法来映射一个自定义的SQL语句
     *-valve属性：表示当前的S0L语句是什么
     *-nativeQvery属性：表示开启SQL语句传统的写法
     *动态SQL语句的映射规则：将接口中的方法的参数列表对应的每一个参数通过一个编号来设置，从1开始取值
     */
    @Query(value ="select c.username,a.authority from t_customer c,t_authority a,t_customer_authority ca "+
            "where ca.customer_id=c.id and ca.authority_id=a.id and c.username=?",nativeQuery = true)
    List<Authority> findAuthoritiesByUsername(String username);

}

```

2.自定义一个实现类实现jpaRepository接口

```text
@Service
public class CustomerServiceImpl implements CustomerService {

    @Autowired
    private CustomerRepository customerRepository;
    @Autowired
    private AuthorityRepository authorityRepository;
    //使用唯一的用户名来查询用户的信息
    @Override
    public Customer getCustomer(String username) {

        Customer customer =
        customerRepository.findByUsername(username);
        return customer;
    }

    //使用唯一的用户名查询当前用户的权限信息
    @Override
    public List<Authority> getCustomerAuthority(String username) {

        List<Authority> authorities =
        authorityRepository.findAuthoritiesByUsername(username);
        return authorities;
    }
}

```

编写测试方法

```text
package com.cy.service;

import com.cy.pojo.Authority;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;

@SpringBootTest
public class CustomerServiceTests {

    @Autowired
    private CustomerService customerService;

    @Test
    public void getCustomer(){
        System.out.println(customerService.getCustomer("tom"));
    }

    @Test
    public void getAuthorityRepository(){
        List<Authority> authorityList = customerService.getCustomerAuthority("tom");
        System.out.println(authorityList.get(0));
    }

}

```

#### 4.3.2UserDetailsService身份认证使用

UserDetailsService是Spring安全框架提供的一个接口。用来封装用户的自定义权限信息(Customer、Authority）。

UserDetailsService接口提供了一个方法：loadUserByUsername(String username)通过指定的用户名称来加载对应的用户信息，还可以进行权限的校验。

自定义一个类，然后实现UserDetailsService接口，并重写loadUserByUsername(String username),编写自定义的认证规则。

```text
package com.cy.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;

import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import javax.sql.DataSource;

/**
 *Security安全框架的配置类：
 *1.继承WebSecurityConfigurerAdapter类。
 *2.重写方法configure(AuthenticationManagerBuilder auth)。
 *3.开启Security的安全配置的自定义支持，使用一个注解：@EnableWebSecurity。
 */
@EnableWebSecurity
public class SecurityConfig extends WebSecurityConfigurerAdapter {

    @Autowired
    private DataSource dataSource; //连接目标数据库对象

    //声明一个UserDetailsService对象
    @Autowired
    private UserDetailsService userDetailsService; //byType类型自动装配(UserDetailsServiceImpl)

    /**自定义用户认证的管理
     * 参数：AuthenticationManagerBuilder,表示配置用户的权限认证方式
     * */
    @Override
    protected void configure(AuthenticationManagerBuilder auth)throws Exception{
    //1.基于内存认证：
    /**
     *默认的登录页面：用户的登录信总，包含用户的名称、密码。
     *1,如何在内存中声明一组用户名车密码？
     *2,将用户内存中的信息关联上AuthenticationManagerBuilder对象上。
     */
      /**  //表示获取指定的密码编码器，必须要指定，否则话启动程序会报错。
        BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
        //1.inMemoryAuthentication()表示基于内存认证，用户的密码必须加密，指定密码的加密方式。
        auth.inMemoryAuthentication().passwordEncoder(encoder)
        //设置用户名、设置按照指定密码器的初始化密码、设置了tom这个用户对应的角色（表示c0mmo目录下的的资源可以被访问）
        .withUser("tom").password(encoder.encode("123456")).roles("common")
         .and()//表示同时声明一组用户信息的初始化配置
         .withUser("李四").password(encoder.encode("123456")).roles("vip");
        */


        /***
        //2.使用JDBC进行身份认证
        //2.1查询数据库中的数据是否存在
        String userSql = "select username,password,valid from t_customer where username=?";
        //查询用户的权限信息
        String authentySql = "select c.username,a.authority from t_customer c,t_authority a,t_customer_authority ca "+
        "where ca.customer_id=c.id and ca.authority_id=a.id and c.username=?";
        //2.2结合安全框架的AuthenticationManagerBuilder的对象实现JDBC身份认证的判断
        //(1)表示需要声明密码的编码器
        BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
        //(2)构建JDBC认证的自定义配置
        auth.jdbcAuthentication().passwordEncoder(encoder)
                .dataSource(dataSource)//数据源
                .usersByUsernameQuery(userSql)//根据指定的用户名查询用户的数据信息
                .authoritiesByUsernameQuery(authentySql);//根据指定的权限进行查询

        */


        //3.使用UserDetailsService权限认证
        //3.1构建一个密码的编码器
        BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
        //3.2设置认证方式为UserDetailsService的方式
        auth.userDetailsService(userDetailsService).passwordEncoder(encoder);
    }

}

```

## 5 自定义用户授权管理

### 5.1 自定义用户访问控制

重写WebSecurityConfigurerAdapter类中的configure(HttpSecurity http)方法。此方法是基于HTTP请求的协议来进行权限控制（就是判断当前的请求地址是否可以被放行处理）

方法中可以控制权限、Session管理配置、CSRF跨站的问题...

HttpSecurity类的主要方法及说明:

![screen-capture](b7d33920425505f2632ed43a2a540298.png)

用户请求控制相关的主要方法及说明:

![screen-capture](eb0a84b1d0ee168a108bcc8c0d81e754.png)

### 5.2 自定义用户登录

1.将登录页面方到项目(Templates/login/login.html)中，构建了一个自定义的用户登录页面。

```text
<!DOCTYPE html>
<html
        xmlns:th="http://www.thymeleaf.org">
<head>
    <meta http-equiv="Content-Type"content="text/html;charset=UTF-8">
    <title>用户登录界面</title>

</head>
<body >
<form th:action="@{/userLogin}" th:method="post">

    <h1 >请登录<h1>
        <!-·用户登录错误信息提示框·->
        <div th:if="${param.error}" style="...">
           <p>用户名或密码错误，请重新登录！</p>
        </div>
        <input type="text" name="name" placeholder="" required="" autofocus="">
        <input type="password" name="pwd" placeholder="" required="">
        <div >
            <label>
                <input type="checkbox" name="rememberme">记住我
            </label>
        </div>
        <button type="submit"></button>
        <p >Copyrighte 2020-2030</p>
</form>
</body>
</html>
```

导入依赖

```text
  <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-thymeleaf</artifactId>
        </dependency>
```

编写配置信息

```text
#MySOL数据库连接配置
spring:
  datasource:
    driver-class-name: com.mysql.cj.jdbc.Driver
    url: jdbc:mysql://localhost:3306/springboot?useUnicode=true&characterEncoding=utf8&useSSL=false&serverTimezone=UTC
    username: root
    password: hsxsdm

  thymeleaf:
    cache: false #关闭Thymeleaf缓存
```

在FileController中编写方法

```text
    @GetMapping("/userLogin")
    public String toLoginPage(){
        //向静态页面目录下的Login文件夹下的Login.html页面进行跳转
        return"login/login";//login.html文件的后缀是不需要声明
    }
```

2.Spring Security安全框架默认会拦截自定义的请求url。

```text
输入localhost:8080/userLogin会跳转到localhost:8080/login页面
```

3.自定义用户登录控制配置。重写了configure(HttpSecurity http)方法。

```
  //2.自定义用户登录的控制
        http.formLogin()//表示基于表单的用户登录验证开启
        //表示用户的登录页面
                .loginPage("/userLogin").permitAll()//放行当前请求
        //默认情况下，表单中的用户username、密码password,如果按照默认规则编写表单，会将参数自动传递给后台安全框架
                .usernameParameter("name")
                .passwordParameter("pwd")
                .defaultSuccessUrl("/")//如果用户和密码验证成功，则打开那一个页面
        //默认如果登录失败"/1ogin?error"地址打开登录页面
        //在表单中需要使用baram.error来获取默认封装的错误信息
                .failureUrl("/userLogin?error");//如果登录的用户或密码输出错误，则打开登录页面
```

4.静态资源需要配置放行处理。

```text
 //自定义用户的授权管理的配置
        http.authorizeRequests()//表示开启基于HttpServletRequest请求的访问认证权限控制
                //表示基于Ant的请求风格的UrL都要进行权限的验证
                .antMatchers("/").permitAll()//无条件对请求放行

                //需要对static目录的静态资源进行放行的处理，无条件可以访问
                .antMatchers("/login/**").permitAll()

                //hasRole.方法：用来判断指定的UrL请求是否有指定的权限，如果有则放行该请求
                .antMatchers("/detail/common/*").hasRole ("common")
                .antMatchers("/detail/vip/**").hasRole("vip")
                //anyRequest()表示获取到所有的请求
                .anyRequest().authenticated();//authenticated()表示必须在登录的状态下
```

SecurityConfig代码

```text
package com.cy.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;

import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import javax.sql.DataSource;

/**
 *Security安全框架的配置类：
 *1.继承WebSecurityConfigurerAdapter类。
 *2.重写方法configure(AuthenticationManagerBuilder auth)。
 *3.开启Security的安全配置的自定义支持，使用一个注解：@EnableWebSecurity。
 */
@EnableWebSecurity
public class SecurityConfig extends WebSecurityConfigurerAdapter {

    @Autowired
    private DataSource dataSource; //连接目标数据库对象

    //声明一个UserDetailsService对象
    @Autowired
    private UserDetailsService userDetailsService; //byType类型自动装配(UserDetailsServiceImpl)

    /**自定义用户认证的管理
     * 参数：AuthenticationManagerBuilder,表示配置用户的权限认证方式
     * */
    @Override
    protected void configure(AuthenticationManagerBuilder auth)throws Exception{
    //1.基于内存认证：
    /**
     *默认的登录页面：用户的登录信总，包含用户的名称、密码。
     *1,如何在内存中声明一组用户名车密码？
     *2,将用户内存中的信息关联上AuthenticationManagerBuilder对象上。
     */
      /**  //表示获取指定的密码编码器，必须要指定，否则话启动程序会报错。
        BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
        //1.inMemoryAuthentication()表示基于内存认证，用户的密码必须加密，指定密码的加密方式。
        auth.inMemoryAuthentication().passwordEncoder(encoder)
        //设置用户名、设置按照指定密码器的初始化密码、设置了tom这个用户对应的角色（表示c0mmo目录下的的资源可以被访问）
        .withUser("tom").password(encoder.encode("123456")).roles("common")
         .and()//表示同时声明一组用户信息的初始化配置
         .withUser("李四").password(encoder.encode("123456")).roles("vip");
        */


        /***
        //2.使用JDBC进行身份认证
        //2.1查询数据库中的数据是否存在
        String userSql = "select username,password,valid from t_customer where username=?";
        //查询用户的权限信息
        String authentySql = "select c.username,a.authority from t_customer c,t_authority a,t_customer_authority ca "+
        "where ca.customer_id=c.id and ca.authority_id=a.id and c.username=?";
        //2.2结合安全框架的AuthenticationManagerBuilder的对象实现JDBC身份认证的判断
        //(1)表示需要声明密码的编码器
        BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
        //(2)构建JDBC认证的自定义配置
        auth.jdbcAuthentication().passwordEncoder(encoder)
                .dataSource(dataSource)//数据源
                .usersByUsernameQuery(userSql)//根据指定的用户名查询用户的数据信息
                .authoritiesByUsernameQuery(authentySql);//根据指定的权限进行查询

        */


        //3.使用UserDetailsService权限认证
        //3.1构建一个密码的编码器
        BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
        //3.2设置认证方式为UserDetailsService的方式
        auth.userDetailsService(userDetailsService).passwordEncoder(encoder);
    }

    @Override
    protected void configure(HttpSecurity http)throws Exception{
       /** //自定义用户的授权管理的配置
        http.authorizeRequests()//表示开启基于HttpServletRequest请求的访问认证权限控制
        //表示基于Ant的请求风格的UrL都要进行权限的验证
        .antMatchers("/").permitAll()//无条件对请求放行
        //hasRole.方法：用来判断指定的UrL请求是否有指定的权限，如果有则放行该请求
        .antMatchers("/detail/common/*").hasRole ("common")
        .antMatchers("/detail/vip/**").hasRole("vip")
        //anyRequest()表示获取到所有的请求
        .anyRequest().authenticated()//authenticated()表示必须在登录的状态下
        .and()//功能连接符号
        .formLogin();//开启基于表单的用户登录认证
        */

        //自定义用户的授权管理的配置
        http.authorizeRequests()//表示开启基于HttpServletRequest请求的访问认证权限控制
                //表示基于Ant的请求风格的UrL都要进行权限的验证
                .antMatchers("/").permitAll()//无条件对请求放行

                //需要对static目录的静态资源进行放行的处理，无条件可以访问
                .antMatchers("/login/**").permitAll()

                //hasRole.方法：用来判断指定的UrL请求是否有指定的权限，如果有则放行该请求
                .antMatchers("/detail/common/*").hasRole ("common")
                .antMatchers("/detail/vip/**").hasRole("vip")
                //anyRequest()表示获取到所有的请求
                .anyRequest().authenticated();//authenticated()表示必须在登录的状态下
               // .and()//功能连接符号
              //.formLogin();//开启基于表单的用户登录认证

        //2.自定义用户登录的控制
        http.formLogin()//表示基于表单的用户登录验证开启
        //表示用户的登录页面
                .loginPage("/userLogin").permitAll()//放行当前请求
        //默认情况下，表单中的用户username、密码password,如果按照默认规则编写表单，会将参数自动传递给后台安全框架
                .usernameParameter("name")
                .passwordParameter("pwd")
                .defaultSuccessUrl("/")//如果用户和密码验证成功，则打开那一个页面
        //默认如果登录失败"/1ogin?error"地址打开登录页面
        //在表单中需要使用baram.error来获取默认封装的错误信息
                .failureUrl("/userLogin?error");//如果登录的用户或密码输出错误，则打开登录页面
    }

}

```

### 5.3 自定义退出登录

HttpSecrity对象中提供一个logout()方法，用来处理用户的退出登录的相关自定义以及设置。
logout()方法中涉及用户退出的主要方法及说明见下表。

![screen-capture](2b90b901f8e6eeef6384d7bc0dfdebd4.png)

![screen-capture](9d286305be2bc1a27dfeb64cf15818de.png)

2.打开configure()理退出登录的请求业务。

```text
 //3.自定义用户退出登录
        http.logout()//表示自定义用户的退出功能
        .logoutUrl("/mylogout")//表示什么样Un海求会触发退出登录
                .logoutSuccessUrl("/userLogin");//表示如果用户退出登录操作成功，跳转到指定的页面(login.htmL页面)
```

### 5.4 登录用户信息的获取

#### 5.4.1 使用HttpSession方式获取

通过访问HttpSession对象可以获取到用户的相关信息，例如：用户名、用户的权限信息登录在Controller层中编写一个请求处理方法，方法的参数是HttpSession对象。
CSRF:跨站请求（网络的攻击），CSCF_TOKEN。

```text
/*使用SecurityContextHolder获取用户信息*/
    @GetMapping("/sch")o
    public void getUserBySecurityContextHolder() {
        
        //1,上下文对象：SecurityContext--保存有用户的信息
        SecurityContext context = SecurityContextHolder.getContext();
        //2.获取用户的认证信息
        Authentication authentication = context.getAuthentication();//获取用户的认证信息
        //3.通过Authentication对象来获取用户的详情信息(UserDetailsService)
        UserDetails userDetails = (UserDetails) authentication.getPrincipal();
        System.out.println("userDetails=" + userDetails);
        System.out.println("username=" + userDetails.getUsername());
        System.out.println("password=" + userDetails.getPassword());

    }
```

#### 5.4.2 使用SecurityContextHolder 获取用户

使用SecurityContextHolder获取用户的名称、用户的权限、用户的密码等信息

<br/>

### 5.5 记住我功能

提供了一个可以勾选复选框，如果用户勾选了“记住我/自动登录”，在指定的时间范围内，用户即便关闭了客户
端，再次访问系统内部资源，可以免登录直接进入系统。
rememberMe()记住我功能相关涉及记住我的主要方法及说明如下表所示。

![screen-capture](1c26774d6c4928c1d744e9f07d405ab4.png)

<br/>

**1.基于简单加密Token实现**
1.登录的表单中，定义一个复选框按钮，需要指定name属性的取值“remeberme”。如果没有指定name属性的
取值，安全默认记住的name属性的取值"remeber-.me"。
2.匹配权限。需要在confrigure(HttpSecurity http)方法中配置开启记住我的功能。

```text
  //4.自定义记住我的功能
        http.rememberMe()//开启自定义记住我的功能
        //表示表单中"记住我"复选框对应name属性的取值。<input type="checkbox"name="rememberme">记住我
                .rememberMeParameter("rememberme")
                .tokenValiditySeconds(20);//记住我的时间单位为秒，如果超过此时间，下次访问需要登录
```

**2.基于持久化Token的方式**
1.在数据库中，需要去建立一张表，用来保存用户的Token的信息。

```text
#:创建表pers1 stent_logins
CREATE TABLE persistent_logins(
series varchar(64)PRIMARY KEY, #存储一个随机生成序列化
username varchar(64)NOT NULL, #登陆的用户名
token varchar(64)NOT NULL, #存储每次访问的最新Token
last_used timestamp NOT NULL #表示Token最后使用时间（最后一次登录的时间）
)
```

> 注意：官网推荐的使用是persistent_logins表，来管理Token的信息。所以不需要去编写操作改变的SQL语句。

2.需要在confrigure(HttpSecurity http)方法中配置基于持久化Token的加载方式。

- 当用户退出当前的登录（注销），persistent_logins表中当前维护的此用户对应的Token数据会被自动清
空。

- 当前用户在有效期内，如果二次登录，Token:会自动的刷新（每次登录都会生成新的Token)。
- 基于持久化的Token是可以实现记住我功能的。

```text
package com.cy.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;

import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.web.authentication.rememberme.JdbcTokenRepositoryImpl;
import org.springframework.web.bind.annotation.GetMapping;

import javax.servlet.http.HttpSession;
import javax.sql.DataSource;
import java.util.Enumeration;

/**
 *Security安全框架的配置类：
 *1.继承WebSecurityConfigurerAdapter类。
 *2.重写方法configure(AuthenticationManagerBuilder auth)。
 *3.开启Security的安全配置的自定义支持，使用一个注解：@EnableWebSecurity。
 */
@EnableWebSecurity
public class SecurityConfig extends WebSecurityConfigurerAdapter {

    @Autowired
    private DataSource dataSource; //连接目标数据库对象

    //声明一个UserDetailsService对象
    @Autowired
    private UserDetailsService userDetailsService; //byType类型自动装配(UserDetailsServiceImpl)

    /**
     * 自定义用户认证的管理
     * 参数：AuthenticationManagerBuilder,表示配置用户的权限认证方式
     */
    @Override
    protected void configure(AuthenticationManagerBuilder auth) throws Exception {
        //1.基于内存认证：
        /**
         *默认的登录页面：用户的登录信总，包含用户的名称、密码。
         *1,如何在内存中声明一组用户名车密码？
         *2,将用户内存中的信息关联上AuthenticationManagerBuilder对象上。
         */
        /**  //表示获取指定的密码编码器，必须要指定，否则话启动程序会报错。
         BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
         //1.inMemoryAuthentication()表示基于内存认证，用户的密码必须加密，指定密码的加密方式。
         auth.inMemoryAuthentication().passwordEncoder(encoder)
         //设置用户名、设置按照指定密码器的初始化密码、设置了tom这个用户对应的角色（表示c0mmo目录下的的资源可以被访问）
         .withUser("tom").password(encoder.encode("123456")).roles("common")
         .and()//表示同时声明一组用户信息的初始化配置
         .withUser("李四").password(encoder.encode("123456")).roles("vip");
         */


        /***
         //2.使用JDBC进行身份认证
         //2.1查询数据库中的数据是否存在
         String userSql = "select username,password,valid from t_customer where username=?";
         //查询用户的权限信息
         String authentySql = "select c.username,a.authority from t_customer c,t_authority a,t_customer_authority ca "+
         "where ca.customer_id=c.id and ca.authority_id=a.id and c.username=?";
         //2.2结合安全框架的AuthenticationManagerBuilder的对象实现JDBC身份认证的判断
         //(1)表示需要声明密码的编码器
         BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
         //(2)构建JDBC认证的自定义配置
         auth.jdbcAuthentication().passwordEncoder(encoder)
         .dataSource(dataSource)//数据源
         .usersByUsernameQuery(userSql)//根据指定的用户名查询用户的数据信息
         .authoritiesByUsernameQuery(authentySql);//根据指定的权限进行查询

         */


        //3.使用UserDetailsService权限认证
        //3.1构建一个密码的编码器
        BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
        //3.2设置认证方式为UserDetailsService的方式
        auth.userDetailsService(userDetailsService).passwordEncoder(encoder);
    }

    @Override
    protected void configure(HttpSecurity http) throws Exception {
        /** //自定义用户的授权管理的配置
         http.authorizeRequests()//表示开启基于HttpServletRequest请求的访问认证权限控制
         //表示基于Ant的请求风格的UrL都要进行权限的验证
         .antMatchers("/").permitAll()//无条件对请求放行
         //hasRole.方法：用来判断指定的UrL请求是否有指定的权限，如果有则放行该请求
         .antMatchers("/detail/common/*").hasRole ("common")
         .antMatchers("/detail/vip/**").hasRole("vip")
         //anyRequest()表示获取到所有的请求
         .anyRequest().authenticated()//authenticated()表示必须在登录的状态下
         .and()//功能连接符号
         .formLogin();//开启基于表单的用户登录认证
         */

        //自定义用户的授权管理的配置
        http.authorizeRequests()//表示开启基于HttpServletRequest请求的访问认证权限控制
                //表示基于Ant的请求风格的UrL都要进行权限的验证
                .antMatchers("/").permitAll()//无条件对请求放行

                //需要对static目录的静态资源进行放行的处理，无条件可以访问
                .antMatchers("/login/**").permitAll()

                //hasRole.方法：用来判断指定的UrL请求是否有指定的权限，如果有则放行该请求
                .antMatchers("/detail/common/*").hasRole("common")
                .antMatchers("/detail/vip/**").hasRole("vip")
                //anyRequest()表示获取到所有的请求
                .anyRequest().authenticated();//authenticated()表示必须在登录的状态下
        // .and()//功能连接符号
        //.formLogin();//开启基于表单的用户登录认证

        //2.自定义用户登录的控制
        http.formLogin()//表示基于表单的用户登录验证开启
                //表示用户的登录页面
                .loginPage("/userLogin").permitAll()//放行当前请求
                //默认情况下，表单中的用户username、密码password,如果按照默认规则编写表单，会将参数自动传递给后台安全框架
                .usernameParameter("name")
                .passwordParameter("pwd")
                .defaultSuccessUrl("/")//如果用户和密码验证成功，则打开那一个页面
                //默认如果登录失败"/1ogin?error"地址打开登录页面
                //在表单中需要使用baram.error来获取默认封装的错误信息
                .failureUrl("/userLogin?error");//如果登录的用户或密码输出错误，则打开登录页面


        //3.自定义用户退出登录
        http.logout()//表示自定义用户的退出功能
                .logoutUrl("/mylogout")//表示什么样Un海求会触发退出登录
                .logoutSuccessUrl("/userLogin");//表示如果用户退出登录操作成功，跳转到指定的页面(login.htmL页面)


        /** //4.自定义记住我的功能
        http.rememberMe()//开启自定义记住我的功能
        //表示表单中"记住我"复选框对应name属性的取值。<input type="checkbox"name="rememberme">记住我
                .rememberMeParameter("rememberme")
                .tokenValiditySeconds(20);//记住我的时间单位为秒，如果超过此时间，下次访问需要登录
         */
        //5.自定义记住我的功能~基于持久化Token的加密方式
        http.rememberMe()
                .rememberMeParameter("rememberme")
                .tokenValiditySeconds(300)
                .tokenRepository(tokenRepository());//对Token进行持久化处理


    }

    //持久化Token的存储II
    @Bean//表示将方法的返回值对应的Java对象，交给Spring容器管理
    public JdbcTokenRepositoryImpl tokenRepository(){
        //创建一个使用JDBC来持久化Token到数据库的一个实现类对象
        JdbcTokenRepositoryImpl jtri = new JdbcTokenRepositoryImpl();
        jtri.setDataSource(dataSource);//在JdbcTokenRepositoryImpl对象上绑定数据源对象
        return jtri;
    }


    //只要请求处理方法参数列表上有HttpSession对象，则会自动传递session数据给到参数上
    @GetMapping("/getUserByHttpSession")
    public void getUserByHttpSession(HttpSession session) {
        //获取session对象中所有的key的集合(session保存的数据是key-valve结构)
        //Properties类型返回值(key-valve)
        Enumeration<String> names = session.getAttributeNames();
        while (names.hasMoreElements()) {//判断Enumeration中是否有key,如果有则返回trUe
            //获取key,将来通过key才能获取到对应valve
            String element = names.nextElement();
            System.out.println("element=" + element);
            //依据key值来获取对应valve
            session.getAttribute(element);

        }

    }
}

```

### 5.6 CSRF

CSRF:Cross--site request forgery,跨站请求伪造。需要限制伪造请求，需进行防范。
推荐防止CSRF的方式：

- 在请求中添加Token的验证。
- 基于HTTP请求（在请求头中添加约束的字段）。
- 在HTTP请求头中自定义属性(csrf="sdhdsd.2=sde8w87")。

#### 5.6.1CSRF防护功能关闭

提供有方法：disable()用于关闭防护功能。

#### 5.6.2针对Form表单数据修改的CSRF Token配置

在表单中自定义个控件(input)，去Token的数据内容。将这个控件的可见性设置为隐藏。

csf是一个对象，在此对象中包含两部数据内容。

- token,属性：表示安全框架传递给客户端Token的取值(jshdk12978sdyw8e784)。
- parameterName属性：表示此Token的name属性名称。
- csrf_token=jshdk12978sdjyw8e784

将表单的属性action设置成Thymeleaf模版的方式来提交请求。

```text
<form class="form-signin"th:action="@(/updateUser}"method="post">

</form>
```

## 6 Security控制页面

1.导入依赖：

```text
<!--Security与Thymeleaf整合实现前端页面安全访问控制-->
<dependency>
    <groupId>org.thymeleaf.extras</groupId>
    <artifactId>thymeleaf-extras-springsecurity5</artifactId>
</dependency>
```
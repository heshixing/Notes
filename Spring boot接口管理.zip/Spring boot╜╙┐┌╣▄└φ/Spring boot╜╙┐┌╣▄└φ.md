## 非JSON格式：

**1.参数与传入的名称相同,自动匹配。**

**2..参数与传入的名称不一致：**

当前端提交的参数名称和后端的服务器请求处理方法的参数名称不一致的时候，需要使用注解@RequestParam来完成参数的映射。

```java
@RequestMapping("add2")
public String add2(@RequestParam("user")String username,@RequestParam("pwd")String password){
        System.out.println("username:"username +"password:"password);
        return "success";
}
```

**3.传入的参数多，请求的参数名称和pojo实体类的属性相同时(或者实体类属性更多),用实体类接受传入的参数。**

```java
@RequestMapping("add3")
public String add3(User user){
System.out.println(user);
return "success";
}
```

**4.RestFul风格。**

- 在后端设置请求需要使用（变量名）的方式进行占位。
- 注解@PathVariable作用：用来指定请求地址中参数值和处理请求的方法匹配映射关系
  ```text
  http://localhost:8080/users/add4/tom/123456
  
  ```

```java
@RequestMapping("add4/{username}/{password}")
public String add4(@PathVariable("username") String username,
                   @PathVariable("password") String password){
  
}
```

- 当请求变量名称和处理请求方法的参数名称相同时可以省略。
  ```java
  @RequestMapping("add4/{username}/{password}")
  public String add4(@PathVariable String username,
                     @PathVariable String password){
    
  }
  ```

**5.通过HttpServletRequest对象接受请求的数据。**

```java
@RequestMapping("add5")
Public String add5(HttpServletRequest req){
  String username = req.getParamter("username");
  String password = req.getParamter("password");
}
```

***

## Springboot接受前端数据

**SpringBoot接收数据方式分为两类：**

- 传非SON格式数擂
- 传SON格式数据

***

### 传JSON格式数据

@RequestBody注解：用了接受前端交给后端服务器JSON格式的数据使用,添加接收JSO    N数据的参数上来修饰。

**1.单个实体类接收参数**

```java
{
  "id"：1，
  "username":"何世兴",
  "password":"123"
  
}
```

直接用实体类接受:

```java
@RequestMapping("add6")
Public String add5( @RequestBody User user){
  //这里不写@RequestBody会报错,因为后端默N认使用HttpServletRequest接收数据,
  //但是你传入的格式是JSON，用HttpServletRequest接受都为空。
  System.out.println(user);
  return "success";
}
```

2.**嵌套引用实体类类型**，(前端的的JSOW参数名称和后端的自定引用的属性名称相同)。

有自定义引用类型时：

```java
@Data    //LomBok提供的set,get
@ToString //LomBok提供的ToString方法
@AllArgsConstructor //LomBok提供的全参构造方法
@NoArgsConstructor //LomBok提供的无参构造方法
public class User implements Serializable{
private String username;
private Cat cat;
}
```

```

```

```java
@Data    //LomBok提供的set,get
@ToString //LomBok提供的ToString方法
@AllArgsConstructor //LomBok提供的全参构造方法
@NoArgsConstructor //LomBok提供的无参构造方法
public class Cat implements Serializable{
  private  String Integer id;
  private  String name;
}
```

发送的数据:

```json
{
  "username":"何世兴"
  "cat':{
    id:2,
    name:"花"
  }
}
```

可以正常输出。

**3.前端传入实体List集合接收数据**

```java
@Data    //LomBok提供的set,get
@ToString //LomBok提供的ToString方法
@AllArgsConstructor //LomBok提供的全参构造方法
@NoArgsConstructor //LomBok提供的无参构造方法
public class Course implements Serializable{
private Integer id;
private String courseName;
private String lecturer;
}
```

在user实体类中定义一个集合,接收实体类。

```java
ce'shi@Data    //LomBok提供的set,get
@ToString //LomBok提供的ToString方法
@AllArgsConstructor //LomBok提供的全参构造方法
@NoArgsConstructor //LomBok提供的无参构造方法
public class User implements Serializable{
private String username;
private Cat cat;

private List<Course> courses;
}
```

传入的集合：

```json
{
"username":"何世兴",
"cat':{
    id:2,
    name:"花"
  },
"courses":[
          {  id:1001,
            courseName:"Java基础"，
            1 ecthrer:"李老师
          },
          {  id:1002,
             courseName:"Javaweh"
             lecturer:"张老师"
          },
          { id:1003,
            courseName:"Java框架"，
            lecturer:"袁老师"
          }
        ]
}
```

```

```

测试:

```java
@RequestMapping("add8")
public String add8(@RequestBody User user){
    System.out.println(user);
    return "success";
}
```

结果:

![screen-capture](fb01511b525a0030f6919bac20356d25.png)

<br/>

**4.Map集合接收参数**

请求处理方法的参数列表声明 为Map<String,Object>类型。

传入的集合：

```json
{
"username":"何世兴",
"cat':{
    id:2,
    name:"花"
  },
"courses":[
          {  id:1001,
            courseName:"Java基础"，
            1 ecthrer:"李老师
          },
          {  id:1002,
             courseName:"Javaweh"
             lecturer:"张老师"
          },
          { id:1003,
            courseName:"Java框架"，
            lecturer:"袁老师"
          }
        ]
}
```

测试 ：

```java
@RequestMapping("add9")
public String add9(@RequestBody Map<string,Object>map){
  
String username (String)map.get("username");
System.out.println("username="+username);

//获取自定义对象的集合Map
Map<String,Object>catMap (Map<String,Object>)map.get("cat");
Set<Map.Entry<String,Object>>catSet=catMap.entrySet();//Map集合转化成了Set集合
for(Map.Entry<String,Object>entry:catSet){/entry对象：表示-组key:valve的映射
//getKey获取键、getValue获取值
String key  = entry.getKey();
Object value = entry.getvalue();
System.out.println("cat,key:"key +"value:"value);

List<Map<String,Object>>courseMapList = (List<Map<String,Object>>)map.get("courses");
for (Map<String,Object>courseMap : courseMapList){
    //循环遍历Map集合中每一组key和value的值
    Set<Map.Entry<String,Object>>courseSet = courseMap.entrySet();
    //遍历此Set集合
    for (Map.Entry<String,Object>entry : courseSet){
        String key entry.getKey();
        Object value entry.getValve();
        System.out.println("course:key:"key +"value:"value);
      }
}
  return "success"
}
}
```

结果:

![screen-capture](bcbbe340035dad36baff138ada33421c.png)

***
- 熟悉Thymeleaf模板引擎基本使用的语法
- SpringBoot整和Thymeleaf模板引擎使用
- Thymelaef模板引擎国际化处理

通过Thymeleaf模版引擎可以实现分离，前端开发和后端开发，便于项目的分工协作。

## 1 SpringBoot支持的视图技术

- FreeMarker视图解析技术
- Groovy视图解析技术
- 3JSP视图解析技术（不用）
- 4.Thymeleaf视图解析技术

### 1.2视图解析技术实现

以jsp为例：

1.EL表达式： 解析传递给jsp页面的数据

2.JSTL标签库： 循环标签,自定义标签，条件标签...

## 2 SpringBoot整合Thymeleaf

### 2.1环境搭建

1.创建SpringBoot项目。

2.导入 Spring Web 和Thymeleaf依赖(创建时直接导入)。

3.static目录：用来存放静态模板文件，可直接访问。

4.Template目录：用来存放动态模板文件,动态模板只有在项目内部才可以访问。无法之间访问。

5.static和Template都是根目录，”\“ ，

	例如：访问login下的css文件 ==》 "\login\css"

![screen-capture](abc5f18cb675f13650d344a03d4a9861.png)

这时候创建Controller类不能使用@RestController注解,该注解返回的是json字符串。

应该使用@Controller。

例如：创建一个LoginController :

```java
public class LoginController{
  @GetMapping("/toLoginPage")
  public String toLoginPage(Model model){ //Model可以绑定数据，传递给目标页面。
    //将当前的系统时间传递给login.html页面。
    int currentYear = Calender.getInstance().get(Calander.Year);
    return "login";//返回为html文件的名称: login.html;
  }
}
```

### 2.2Themelaef使用

在html中引入Themaleaf模板约束：

```java
<html Lang="en" xmlns:th="http://www.thymeleaf.org">
```

使用Themaleaf表达式时,注意"/"的使用：

![screen-capture](1320ecd180b66e324698356617b38bda.png)